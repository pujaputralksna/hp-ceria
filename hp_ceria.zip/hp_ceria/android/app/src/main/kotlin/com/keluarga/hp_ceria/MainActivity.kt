package com.keluarga.hp_ceria

import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Activity utama. Selain menjalankan Flutter, kelas ini menyediakan "Mode Anak" (kiosk):
 *
 * 1. Mode Sematkan Layar (Screen Pinning) — tanpa pengaturan khusus. Android akan meminta
 *    konfirmasi satu kali, lalu tombol Home / Recent / notifikasi terkunci.
 * 2. Mode Kiosk Penuh (Device Owner) — bila aplikasi dijadikan Device Owner lewat ADB,
 *    penguncian berjalan otomatis tanpa konfirmasi, status bar dimatikan, dan aplikasi
 *    menjadi layar utama (Home) sampai orang tua memasukkan kode.
 */
class MainActivity : FlutterActivity() {
    private val channelName = "hp_ceria/kiosk"

    private val dpm by lazy { getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    private val admin by lazy { ComponentName(this, KidsDeviceAdminReceiver::class.java) }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "startKidsMode" -> result.success(startKidsMode())
                    "stopKidsMode" -> { stopKidsMode(); result.success(true) }
                    "isLocked" -> result.success(isLocked())
                    "isDeviceOwner" -> result.success(isDeviceOwner())
                    "removeDeviceOwner" -> { removeDeviceOwner(); result.success(true) }
                    "openHomeSettings" -> { openSettings(Settings.ACTION_HOME_SETTINGS); result.success(true) }
                    "openSecuritySettings" -> { openSettings(Settings.ACTION_SECURITY_SETTINGS); result.success(true) }
                    "exitApp" -> { finishAndRemoveTask(); result.success(true) }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("KIOSK_ERROR", e.message, null)
            }
        }
    }

    private fun isDeviceOwner(): Boolean = dpm.isDeviceOwnerApp(packageName)

    private fun isLocked(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
    }

    /** Mengembalikan "full" (kiosk penuh), "pinned" (sematkan layar), atau "already". */
    private fun startKidsMode(): String {
        if (isLocked()) return "already"
        if (isDeviceOwner()) {
            dpm.setLockTaskPackages(admin, arrayOf(packageName))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // Tidak ada tombol Home, Recent, notifikasi, maupun menu daya global.
                dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE)
            }
            dpm.setStatusBarDisabled(admin, true)
            // Jadikan aplikasi ini sebagai layar Home selama Mode Anak aktif.
            val filter = IntentFilter(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
            }
            dpm.addPersistentPreferredActivity(admin, filter, ComponentName(this, MainActivity::class.java))
            startLockTask()
            return "full"
        }
        startLockTask()
        return "pinned"
    }

    private fun stopKidsMode() {
        if (isDeviceOwner()) {
            dpm.clearPackagePersistentPreferredActivities(admin, packageName)
            dpm.setStatusBarDisabled(admin, false)
        }
        if (isLocked()) stopLockTask()
    }

    /** Melepas status Device Owner agar aplikasi bisa di-uninstall seperti biasa. */
    @Suppress("DEPRECATION")
    private fun removeDeviceOwner() {
        stopKidsMode()
        if (isDeviceOwner()) {
            dpm.setLockTaskPackages(admin, arrayOf())
            dpm.clearDeviceOwnerApp(packageName)
        }
    }

    private fun openSettings(action: String) {
        startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
