package com.keluarga.hp_ceria

import android.app.admin.DeviceAdminReceiver

/** Diperlukan agar aplikasi dapat dijadikan Device Owner (mode kiosk penuh). */
class KidsDeviceAdminReceiver : DeviceAdminReceiver()
