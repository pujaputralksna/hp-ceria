package com.keluarga.hp_ceria

import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/**
 * Pemulihan darurat bila PIN orang tua lupa. Hanya bisa dipicu dari komputer lewat ADB
 * (dilindungi izin DUMP yang tidak dimiliki aplikasi biasa):
 *
 *   adb shell am broadcast -a com.keluarga.hp_ceria.DARURAT -n com.keluarga.hp_ceria/.RescueReceiver
 *
 * Efek: PIN dihapus (aplikasi akan meminta PIN baru) dan Mode Kiosk Penuh dilepas.
 */
class RescueReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            .edit().remove("flutter.parentPin").commit()
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isDeviceOwnerApp(context.packageName)) {
            val admin = ComponentName(context, KidsDeviceAdminReceiver::class.java)
            dpm.clearPackagePersistentPreferredActivities(admin, context.packageName)
            dpm.setStatusBarDisabled(admin, false)
            dpm.setLockTaskPackages(admin, arrayOf())
            dpm.clearDeviceOwnerApp(context.packageName)
        }
    }
}
