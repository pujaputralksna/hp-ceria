# Memeriksa apakah semua bahan untuk membangun HP Ceria sudah terpasang.
# Cara pakai (PowerShell):
#   powershell -ExecutionPolicy Bypass -File D:\Puja\cek_instalasi.ps1
# Hasil disimpan ke D:\Puja\laporan_cek.txt

param([string]$Folder = "D:\Puja")

$laporan = Join-Path $Folder "laporan_cek.txt"
$hasil = New-Object System.Collections.Generic.List[string]

function Tulis($teks) { Write-Host $teks; $hasil.Add($teks) }
function Status($ok, $nama, $info) {
    $tanda = if ($ok) { "[OK]   " } else { "[BELUM]" }
    Tulis ("{0} {1}  {2}" -f $tanda, $nama, $info)
}
function Cari($pola, $maks = 3) {
    Get-ChildItem -Path $Folder -Filter $pola -Recurse -ErrorAction SilentlyContinue -Depth 6 |
        Select-Object -First $maks -ExpandProperty FullName
}
function Jalankan($perintah, $argumen) {
    try { (& $perintah @argumen 2>&1 | Out-String).Trim() } catch { "" }
}

Tulis "=== Laporan cek instalasi HP Ceria ($(Get-Date -Format 'yyyy-MM-dd HH:mm')) ==="
Tulis "Windows: $((Get-CimInstance Win32_OperatingSystem).Caption)"
Tulis "RAM    : $([math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)) GB"
foreach ($d in 'C', 'D') {
    $drv = Get-PSDrive $d -ErrorAction SilentlyContinue
    if ($drv) { Tulis ("Drive {0}: sisa {1:N1} GB" -f $d, ($drv.Free / 1GB)) }
}

Tulis ""
Tulis "--- Isi $Folder (2 tingkat) ---"
if (-not (Test-Path $Folder)) {
    Tulis "Folder $Folder tidak ditemukan!"
} else {
    Get-ChildItem $Folder -ErrorAction SilentlyContinue | ForEach-Object {
        Tulis ("  {0}{1}" -f $_.Name, $(if ($_.PSIsContainer) { "\" } else { "" }))
        if ($_.PSIsContainer) {
            Get-ChildItem $_.FullName -ErrorAction SilentlyContinue | Select-Object -First 15 |
                ForEach-Object { Tulis ("      {0}{1}" -f $_.Name, $(if ($_.PSIsContainer) { "\" } else { "" })) }
        }
    }
}

Tulis ""
Tulis "--- Alat ---"

# Git
$git = Get-Command git -ErrorAction SilentlyContinue
Status ($null -ne $git) "Git" $(if ($git) { Jalankan git @('--version') } else { "tidak ada di PATH" })

# VS Code + ekstensi
$code = Get-Command code -ErrorAction SilentlyContinue
Status ($null -ne $code) "VS Code" $(if ($code) { $code.Source } else { "perintah 'code' tidak ada di PATH" })
if ($code) {
    $ext = Jalankan code @('--list-extensions')
    Status ($ext -match 'Dart-Code.flutter') "  Ekstensi Flutter" ""
    Status ($ext -match 'Dart-Code.dart-code') "  Ekstensi Dart" ""
}

# Flutter
$flutter = Get-Command flutter -ErrorAction SilentlyContinue
$flutterDiPuja = Cari "flutter.bat"
Status ($null -ne $flutter) "Flutter di PATH" $(if ($flutter) { $flutter.Source } else { "tidak ada di PATH" })
if ($flutterDiPuja) { Tulis "        flutter.bat ditemukan di: $($flutterDiPuja -join '; ')" }
if ($flutter) { Tulis ("        " + ((Jalankan flutter @('--version')) -split "`n")[0]) }

# Android SDK
$kandidatSdk = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, "$env:LOCALAPPDATA\Android\Sdk") +
    (Cari "adb.exe" | ForEach-Object { Split-Path (Split-Path $_) })
$sdk = $kandidatSdk | Where-Object { $_ -and (Test-Path "$_\platform-tools\adb.exe") } | Select-Object -First 1
Status ($null -ne $sdk) "Android SDK" $(if ($sdk) { $sdk } else { "tidak ditemukan" })
if ($sdk) {
    Status (Test-Path "$sdk\platform-tools\adb.exe") "  Platform-Tools (adb)" ""
    $bt = Get-ChildItem "$sdk\build-tools" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
    Status ($bt.Count -gt 0) "  Build-Tools" ($bt -join ', ')
    $pf = Get-ChildItem "$sdk\platforms" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name
    Status ($pf.Count -gt 0) "  SDK Platforms" ($pf -join ', ')
    $cl = Test-Path "$sdk\cmdline-tools\latest\bin\sdkmanager.bat"
    Status $cl "  Command-line Tools (latest)" ""
    Status (Test-Path "$sdk\licenses\android-sdk-license") "  Lisensi Android disetujui" ""
}

# Android Studio & Java
$studio = @("$env:ProgramFiles\Android\Android Studio") + (Cari "studio64.exe" | ForEach-Object { Split-Path (Split-Path $_) }) |
    Where-Object { $_ -and (Test-Path "$_\bin\studio64.exe") } | Select-Object -First 1
Status ($null -ne $studio) "Android Studio" $(if ($studio) { $studio } else { "tidak ditemukan" })
$java = if ($studio -and (Test-Path "$studio\jbr\bin\java.exe")) { "$studio\jbr\bin\java.exe" } else { (Get-Command java -ErrorAction SilentlyContinue).Source }
Status ($null -ne $java) "Java (JDK)" $(if ($java) { $java } else { "tidak ditemukan" })

# Proyek HP Ceria
$pubspec = Cari "pubspec.yaml" 10 | Where-Object { (Get-Content $_ -Raw) -match 'name:\s*hp_ceria' } | Select-Object -First 1
Status ($null -ne $pubspec) "Proyek hp_ceria" $(if ($pubspec) { Split-Path $pubspec } else { "belum diekstrak di $Folder" })
if ($pubspec) {
    $proj = Split-Path $pubspec
    if ($proj -match ' ') { Tulis "        PERINGATAN: path proyek mengandung spasi" }
    if ($proj -match 'OneDrive') { Tulis "        PERINGATAN: proyek berada di dalam OneDrive" }
    Status (Test-Path "$proj\.dart_tool") "  flutter pub get sudah dijalankan" ""
    Status (Test-Path "$proj\build\app\outputs\flutter-apk\app-release.apk") "  APK release sudah dibuat" ""
}

# HP terhubung
if ($sdk) {
    $dev = Jalankan "$sdk\platform-tools\adb.exe" @('devices')
    $ada = ($dev -split "`n" | Where-Object { $_ -match "`tdevice$" }).Count
    Status ($ada -gt 0) "HP Android terhubung (USB debugging)" "$ada perangkat"
}

# flutter doctor
if ($flutter) {
    Tulis ""
    Tulis "--- flutter doctor -v ---"
    Tulis (Jalankan flutter @('doctor', '-v'))
}

$hasil | Out-File -FilePath $laporan -Encoding utf8
Write-Host ""
Write-Host "Laporan disimpan di: $laporan  (salin isinya ke chat)" -ForegroundColor Green
