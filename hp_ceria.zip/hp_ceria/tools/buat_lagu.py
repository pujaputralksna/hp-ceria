"""Membuat melodi lagu anak (melodi domain publik, lirik Bahasa Indonesia orisinal).

Jalankan:  python tools/buat_lagu.py
Hasil   :  assets/songs/*.mp3  dan  lib/data/songs_data.dart
Butuh   :  numpy + ffmpeg (opsional, bila tidak ada akan disimpan sebagai .wav)
"""
import json, math, os, shutil, subprocess, wave
import numpy as np

SR = 22050
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_AUDIO = os.path.join(ROOT, "assets", "songs")
OUT_DART = os.path.join(ROOT, "lib", "data", "songs_data.dart")

NOTE_IDX = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def freq(name):
    acc = 0
    if "#" in name:
        acc = 1
        name = name.replace("#", "")
    if "b" in name[1:]:
        acc = -1
        name = name[0] + name[2:]
    n = NOTE_IDX[name[0]] + acc + (int(name[1:]) + 1) * 12
    return 440.0 * 2 ** ((n - 69) / 12)


def tone(f, dur, timbre):
    n = int(SR * dur)
    t = np.arange(n) / SR
    if timbre == "musicbox":
        w = np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 2 * f * t) + 0.12 * np.sin(2 * np.pi * 4.02 * f * t)
        env = np.exp(-t * 3.2)
    elif timbre == "flute":
        vib = 1 + 0.004 * np.sin(2 * np.pi * 5 * t)
        w = np.sin(2 * np.pi * f * vib * t) + 0.18 * np.sin(2 * np.pi * 2 * f * t) + 0.06 * np.sin(2 * np.pi * 3 * f * t)
        env = np.minimum(1, t / 0.04) * np.minimum(1, (dur - t) / 0.06 + 0.02)
    else:  # piano lembut
        w = np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t * 4) + 0.2 * np.sin(2 * np.pi * 3 * f * t) * np.exp(-t * 6)
        env = np.exp(-t * 2.2)
    attack = np.minimum(1, t / 0.008)
    release = np.clip((dur - t) / 0.03, 0, 1)
    return (w * env * attack * release).astype(np.float32)


def noise_hit(dur, decay, hp=True):
    n = int(SR * dur)
    t = np.arange(n) / SR
    x = np.random.uniform(-1, 1, n).astype(np.float32)
    if hp:
        x = np.diff(np.concatenate([[0], x])).astype(np.float32)
    return x * np.exp(-t * decay).astype(np.float32)


def kick(dur=0.18):
    n = int(SR * dur)
    t = np.arange(n) / SR
    f = 110 * np.exp(-t * 18) + 45
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 14)).astype(np.float32)


def parse(notes):
    out = []
    for tok in notes.split():
        name, beats = tok.split(":") if ":" in tok else (tok, "1")
        out.append((name, float(beats)))
    return out


def render(song):
    bpm = song["bpm"]
    spb = 60.0 / bpm
    bpb = song.get("beats_per_bar", 4)
    lines = []
    total_beats = 4 + sum(sum(b for _, b in parse(l[1])) for l in song["lines"])
    buf = np.zeros(int(SR * (total_beats * spb + 2.5)), dtype=np.float32)

    def add(sig, at, gain):
        i = int(at * SR)
        j = min(len(buf), i + len(sig))
        buf[i:j] += sig[: j - i] * gain

    # hitungan awal: 4 ketukan "tik"
    for k in range(4):
        add(noise_hit(0.05, 60), k * spb, 0.25)
    beat = 4.0
    for text, notes in song["lines"]:
        lines.append({"text": text, "ms": int(beat * spb * 1000)})
        for name, beats in parse(notes):
            at = beat * spb
            if name == "R":
                pass
            elif name == "CLAP":
                add(noise_hit(0.12, 35, hp=False), at, 0.45)
            else:
                add(tone(freq(name), max(beats * spb * 1.15, 0.25), song["timbre"]), at, 0.42)
                # nada bas lembut satu oktaf di bawah, agar terdengar lebih "penuh"
                add(tone(freq(name) / 2, max(beats * spb, 0.2), "flute"), at, 0.08)
            beat += beats
    # ritme ringan sepanjang lagu
    b = 4
    while b < beat:
        add(kick(), b * spb, 0.35 if (b - 4) % bpb == 0 else 0.0)
        add(noise_hit(0.04, 90), b * spb, 0.07)
        b += 1
    peak = np.max(np.abs(buf)) or 1
    buf = buf / peak * 0.85
    end = int((beat * spb + 1.5) * SR)
    return buf[:end], lines, int(beat * spb * 1000)


def save(name, data):
    wav_path = os.path.join(OUT_AUDIO, name + ".wav")
    pcm = (data * 32767).astype(np.int16)
    with wave.open(wav_path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    if shutil.which("ffmpeg"):
        mp3 = os.path.join(OUT_AUDIO, name + ".mp3")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav_path, "-b:a", "64k", mp3], check=True)
        os.remove(wav_path)
        return name + ".mp3"
    return name + ".wav"


TWINKLE = [
    "C4 C4 G4 G4 A4 A4 G4:2", "F4 F4 E4 E4 D4 D4 C4:2",
    "G4 G4 F4 F4 E4 E4 D4:2", "G4 G4 F4 F4 E4 E4 D4:2",
    "C4 C4 G4 G4 A4 A4 G4:2", "F4 F4 E4 E4 D4 D4 C4:2",
]
MARY = ["E4 D4 C4 D4 E4 E4 E4:2", "D4 D4 D4:2 E4 G4 G4:2", "E4 D4 C4 D4 E4 E4 E4 E4", "D4 D4 E4 D4 C4:4"]
MAC_A = "C4 C4 C4 G3 A3 A3 G3:2"
MAC_B = "E4 E4 D4 D4 C4:3 G3"
MAC_C = "C4:0.5 C4:0.5 C4 G3 C4:0.5 C4:0.5 C4 R:2"
MAC_D = "C4:0.5 C4:0.5 C4 C4:0.5 C4:0.5 C4 C4:0.5 C4:0.5 C4:0.5 C4:0.5 C4 C4"

SONGS = [
    {
        "id": "bintang", "title": "Bintang Berkelip", "emoji": "⭐", "color": 0xFF7E57C2,
        "bpm": 96, "timbre": "musicbox",
        "lines": list(zip([
            "Bintang kecil berkelip", "Terang indah di langit",
            "Saat malam kau datang", "Temani aku tidur",
            "Bintang kecil berkelip", "Selamat malam bintang",
        ], TWINKLE)),
    },
    {
        "id": "abc", "title": "Lagu A B C", "emoji": "🔤", "color": 0xFF29B6F6,
        "bpm": 100, "timbre": "piano",
        "lines": [
            ("A  B  C  D  E  F  G", "C4 C4 G4 G4 A4 A4 G4:2"),
            ("H  I  J  K  L-M-N-O  P", "F4 F4 E4 E4 D4:0.5 D4:0.5 D4:0.5 D4:0.5 C4:2"),
            ("Q  R  S ... T  U  V", "G4 G4 F4:2 E4 E4 D4:2"),
            ("W  X ... Y  dan  Z", "G4 G4 F4:2 E4 E4 D4:2"),
            ("Sekarang aku sudah tahu", "C4 C4 G4 G4 A4 A4 G4:2"),
            ("Ayo nyanyi bersamaku!", "F4 F4 E4 E4 D4 D4 C4:2"),
        ],
    },
    {
        "id": "kebun", "title": "Kebun Pak Tani", "emoji": "🐮", "color": 0xFF66BB6A,
        "bpm": 120, "timbre": "piano",
        "lines": [
            ("Pak Tani punya kebun", MAC_A), ("I-A I-A O", MAC_B),
            ("Di kebun ada sapi", MAC_A), ("I-A I-A O", MAC_B),
            ("Moo moo di sini, moo moo di sana", MAC_C + " " + MAC_C.replace("R:2", "R:0")),
            ("Sini moo, sana moo, mana-mana moo moo", MAC_D),
            ("Pak Tani punya kebun", MAC_A), ("I-A I-A O", MAC_B),
            ("Di kebun ada bebek", MAC_A), ("I-A I-A O", MAC_B),
            ("Kwek kwek di sini, kwek kwek di sana", MAC_C + " " + MAC_C.replace("R:2", "R:0")),
            ("Sini kwek, sana kwek, mana-mana kwek kwek", MAC_D),
            ("Pak Tani punya kebun", MAC_A), ("I-A I-A O", MAC_B),
        ],
    },
    {
        "id": "domba", "title": "Dombaku Kecil", "emoji": "🐑", "color": 0xFFFFA726,
        "bpm": 110, "timbre": "flute",
        "lines": list(zip([
            "Dombaku kecil putih", "Bulunya... lembutnya...", "Ke mana pun aku pergi", "Dombaku ikut",
            "Dombaku bilang mbeek", "Mbeek mbeek... mbeek mbeek...", "Ayo main bersamaku", "Mbeek mbeek mbeek!",
        ], MARY + MARY)),
    },
    {
        "id": "perahu", "title": "Kayuh Perahu", "emoji": "⛵", "color": 0xFF26C6DA,
        # satuan ketukan = seperdelapan (irama 6/8)
        "bpm": 220, "timbre": "musicbox", "beats_per_bar": 6,
        "lines": [
            ("Kayuh, kayuh perahu", "C4:3 C4:3 C4:2 D4:1 E4:3"),
            ("Di atas sungai", "E4:2 D4:1 E4:2 F4:1 G4:6"),
            ("Senangnya hatiku, senangnya hatiku", "C5 C5 C5 G4 G4 G4 E4 E4 E4 C4 C4 C4"),
            ("Ayo berlayar!", "G4:2 F4:1 E4:2 D4:1 C4:6"),
            ("Kayuh, kayuh perahu", "C4:3 C4:3 C4:2 D4:1 E4:3"),
            ("Ikan pun menari", "E4:2 D4:1 E4:2 F4:1 G4:6"),
            ("Senangnya hatiku, senangnya hatiku", "C5 C5 C5 G4 G4 G4 E4 E4 E4 C4 C4 C4"),
            ("Sampai di tepi!", "G4:2 F4:1 E4:2 D4:1 C4:6"),
        ],
    },
    {
        "id": "ultah", "title": "Selamat Ulang Tahun", "emoji": "🎂", "color": 0xFFEC407A,
        "bpm": 100, "timbre": "piano", "beats_per_bar": 3,
        "lines": [
            ("Selamat ulang tahun", "G4:0.75 G4:0.25 A4 G4 C5 B4:2"),
            ("Selamat ulang tahun", "G4:0.75 G4:0.25 A4 G4 D5 C5:2"),
            ("Selamat ulang tahun, {nama}", "G4:0.75 G4:0.25 G5 E5 C5 B4 A4:2"),
            ("Selamat ulang tahun!", "F5:0.75 F5:0.25 E5 C5 D5 C5:3"),
        ],
    },
    {
        "id": "senang", "title": "Kalau Senang Hati", "emoji": "👏", "color": 0xFFFFCA28,
        "bpm": 120, "timbre": "piano",
        "lines": [
            ("Kalau senang hati, tepuk tangan (prok prok)", "G4:0.5 G4:0.5 C5 C5 C5 C5:0.5 C5:0.5 B4 C5 D5:2 CLAP:1 CLAP:1"),
            ("Kalau senang hati, tepuk tangan (prok prok)", "G4:0.5 G4:0.5 D5 D5 D5 D5:0.5 D5:0.5 C5 D5 E5:2 CLAP:1 CLAP:1"),
            ("Kalau senang hati, mari kita tunjukkan", "E5:0.5 E5:0.5 F5 F5 F5 F5:0.5 A4:0.5 A4 F5 E5 E5 E5:0.5 D5:0.5 C5:2"),
            ("Kalau senang hati, tepuk tangan (prok prok)", "C5:0.5 C5:0.5 B4 B4 B4 A4:0.5 A4:0.5 G4 B4 C5:2 CLAP:1 CLAP:1"),
            ("Kalau senang hati, hentak kaki (dug dug)", "G4:0.5 G4:0.5 C5 C5 C5 C5:0.5 C5:0.5 B4 C5 D5:2 CLAP:1 CLAP:1"),
            ("Kalau senang hati, hentak kaki (dug dug)", "G4:0.5 G4:0.5 D5 D5 D5 D5:0.5 D5:0.5 C5 D5 E5:2 CLAP:1 CLAP:1"),
            ("Kalau senang hati, mari kita tunjukkan", "E5:0.5 E5:0.5 F5 F5 F5 F5:0.5 A4:0.5 A4 F5 E5 E5 E5:0.5 D5:0.5 C5:2"),
            ("Kalau senang hati, hentak kaki (dug dug)", "C5:0.5 C5:0.5 B4 B4 B4 A4:0.5 A4:0.5 G4 B4 C5:2 CLAP:1 CLAP:1"),
        ],
    },
    {
        "id": "tidur", "title": "Lagu Tidur", "emoji": "🌙", "color": 0xFF5C6BC0,
        "bpm": 84, "timbre": "musicbox", "beats_per_bar": 3,
        "lines": [
            ("Tidurlah, tidurlah", "E4:0.5 E4:0.5 G4:2 E4:0.5 E4:0.5 G4:2"),
            ("Anak manis sayangku", "E4:0.5 G4:0.5 C5 B4:1.5 A4:0.5 A4 G4"),
            ("Bintang bulan menjaga", "D4:0.5 E4:0.5 F4 D4 D4:0.5 E4:0.5 F4:2"),
            ("Mimpi indah malam ini", "D4:0.5 F4:0.5 B4:0.5 A4:0.5 G4 B4 C5:3"),
            ("Bunda ada di sini", "C4:0.5 C4:0.5 C5:2 A4:0.5 F4:0.5 G4:2"),
            ("Memeluk dirimu", "E4:0.5 C4:0.5 F4 G4 A4 G4:2"),
            ("Tidurlah, tidurlah", "C4:0.5 C4:0.5 C5:2 A4:0.5 F4:0.5 G4:2"),
            ("Sampai pagi tiba", "E4:0.5 C4:0.5 F4 E4 D4 C4:3"),
        ],
    },
]


def main():
    os.makedirs(OUT_AUDIO, exist_ok=True)
    np.random.seed(7)
    entries = []
    for s in SONGS:
        data, lines, dur = render(s)
        fname = save(s["id"], data)
        entries.append({"id": s["id"], "title": s["title"], "emoji": s["emoji"], "color": s["color"],
                        "file": "songs/" + fname, "durationMs": dur, "lines": lines})
        print("dibuat:", fname, f"{dur/1000:.0f} detik")
    d = ["// FILE INI DIBUAT OTOMATIS oleh tools/buat_lagu.py — jangan diedit manual.", "",
         "import 'song.dart';", "", "const List<Song> songs = ["]
    for e in entries:
        d.append("  Song(")
        d.append(f"    id: {json.dumps(e['id'])},")
        d.append(f"    title: {json.dumps(e['title'], ensure_ascii=False)},")
        d.append(f"    emoji: {json.dumps(e['emoji'], ensure_ascii=False)},")
        d.append(f"    color: 0x{e['color']:08X},")
        d.append(f"    asset: {json.dumps(e['file'])},")
        d.append(f"    durationMs: {e['durationMs']},")
        d.append("    lines: [")
        for l in e["lines"]:
            text = json.dumps(l["text"], ensure_ascii=False).replace("$", "\\$")
            d.append(f"      LyricLine({l['ms']}, {text}),")
        d.append("    ],")
        d.append("  ),")
    d.append("];")
    os.makedirs(os.path.dirname(OUT_DART), exist_ok=True)
    with open(OUT_DART, "w", encoding="utf-8") as f:
        f.write("\n".join(d) + "\n")


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------- efek suara
def make_sfx():
    out = os.path.join(ROOT, "assets", "sfx")
    os.makedirs(out, exist_ok=True)
    global OUT_AUDIO
    saved = OUT_AUDIO
    OUT_AUDIO = out

    def seq(notes, timbre="musicbox", gap=0.0):
        parts = []
        for f, d in notes:
            parts.append(tone(f, d, timbre) * 0.6)
            if gap:
                parts.append(np.zeros(int(SR * gap), dtype=np.float32))
        return np.concatenate(parts)

    # dering telepon: dua nada bergantian, lalu jeda
    t = np.arange(int(SR * 1.0)) / SR
    trill = (np.sin(2 * np.pi * 880 * t) * (np.sin(2 * np.pi * 20 * t) > 0) +
             np.sin(2 * np.pi * 660 * t) * (np.sin(2 * np.pi * 20 * t) <= 0)) * 0.35
    ring = np.concatenate([trill.astype(np.float32), np.zeros(int(SR * 0.6), dtype=np.float32)])
    save("ring", ring)
    # pop balon
    pop = noise_hit(0.12, 45, hp=False) * 0.9 + tone(500, 0.12, "piano") * 0.3
    save("pop", pop)
    # benar
    save("benar", seq([(freq("C5"), 0.12), (freq("E5"), 0.12), (freq("G5"), 0.12), (freq("C6"), 0.35)]))
    # coba lagi
    save("coba", seq([(freq("E4"), 0.18), (freq("C4"), 0.35)], "flute"))
    # pesan masuk
    save("pesan", seq([(freq("A5"), 0.1), (freq("E6"), 0.25)]))
    # kamera cekrek
    save("cekrek", noise_hit(0.08, 60) * 0.8)
    # tepuk tangan meriah
    claps = np.zeros(int(SR * 1.6), dtype=np.float32)
    rng = np.random.default_rng(3)
    for _ in range(40):
        i = int(rng.uniform(0, 1.4) * SR)
        c = noise_hit(0.08, 50, hp=False) * rng.uniform(0.2, 0.5)
        claps[i:i + len(c)] += c[: len(claps) - i]
    save("tepuk", claps / np.max(np.abs(claps)) * 0.8)
    OUT_AUDIO = saved
    print("efek suara dibuat")


make_sfx()
