"""Membuat ikon aplikasi HP Ceria (android/app/src/main/res/mipmap-*/ic_launcher.png)."""
import os
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EMOJI_FONT = "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf"
S = 512

img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
bg = Image.new("RGBA", (S, S))
top, bottom = (255, 140, 198), (167, 123, 243)
for y in range(S):
    t = y / S
    c = tuple(int(top[i] * (1 - t) + bottom[i] * t) for i in range(3)) + (255,)
    ImageDraw.Draw(bg).line([(0, y), (S, y)], fill=c)
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=120, fill=255)
img.paste(bg, (0, 0), mask)

d = ImageDraw.Draw(img)
# badan HP putih
d.rounded_rectangle([150, 70, 362, 442], radius=40, fill=(255, 255, 255, 255))
d.rounded_rectangle([170, 110, 342, 392], radius=16, fill=(255, 228, 241, 255))
d.ellipse([240, 404, 272, 436], fill=(255, 140, 198, 255))


def emoji(ch, center, size):
    f = ImageFont.truetype(EMOJI_FONT, 109)
    tmp = Image.new("RGBA", (160, 160), (0, 0, 0, 0))
    ImageDraw.Draw(tmp).text((80, 80), ch, font=f, embedded_color=True, anchor="mm")
    tmp = tmp.crop(tmp.getbbox()).resize((size, size), Image.LANCZOS)
    img.alpha_composite(tmp, (center[0] - size // 2, center[1] - size // 2))


emoji("🐱", (256, 220), 130)
emoji("🎀", (256, 330), 90)

for folder, px in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
    out = os.path.join(ROOT, "android", "app", "src", "main", "res", f"mipmap-{folder}", "ic_launcher.png")
    img.resize((px, px), Image.LANCZOS).save(out)
img.save(os.path.join(ROOT, "tools", "ikon.png"))
# ikon web (PWA)
web = os.path.join(ROOT, "web")
img.resize((32, 32), Image.LANCZOS).save(os.path.join(web, "favicon.png"))
for px in (192, 512):
    img.resize((px, px), Image.LANCZOS).save(os.path.join(web, "icons", f"Icon-{px}.png"))
    # versi "maskable": isi penuh tanpa sudut transparan
    full = Image.new("RGBA", (S, S), (255, 140, 198, 255))
    full.alpha_composite(img)
    full.resize((px, px), Image.LANCZOS).save(os.path.join(web, "icons", f"Icon-maskable-{px}.png"))
print("ikon dibuat")
