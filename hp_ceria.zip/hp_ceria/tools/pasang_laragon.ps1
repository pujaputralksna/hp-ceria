# Build versi web HP Ceria lalu salin ke Laragon (http://localhost/hpceria/).
# Jalankan dari folder proyek:  powershell -ExecutionPolicy Bypass -File tools\pasang_laragon.ps1
param([string]$Www = "D:\Puja\laragon\www")

$ErrorActionPreference = "Stop"
$proyek = Split-Path $PSScriptRoot
Set-Location $proyek

Write-Host "1/2 Membuat versi web (1-3 menit)..." -ForegroundColor Cyan
flutter build web --release --no-web-resources-cdn --base-href /hpceria/
if ($LASTEXITCODE -ne 0) { throw "Build gagal" }

Write-Host "2/2 Menyalin ke $Www\hpceria ..." -ForegroundColor Cyan
$tujuan = Join-Path $Www "hpceria"
if (Test-Path $tujuan) { Remove-Item $tujuan -Recurse -Force }
Copy-Item "$proyek\build\web" $tujuan -Recurse

Write-Host ""
Write-Host "Selesai! Pastikan Laragon sudah 'Start All', lalu buka: http://localhost/hpceria/" -ForegroundColor Green
