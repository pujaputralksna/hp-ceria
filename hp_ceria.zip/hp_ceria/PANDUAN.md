# Panduan Lengkap HP Ceria — dari Nol sampai Berjalan di HP Android

Panduan ini untuk **laptop Windows 11** dan **Visual Studio Code (VS Code)**.
Ikuti langkah-langkahnya secara berurutan. Instalasi pertama butuh sekitar 1–2 jam, sebagian besar untuk menunggu unduhan selesai.

---

## Daftar Isi

1. [Yang perlu disiapkan](#1-yang-perlu-disiapkan)
2. [Instal Git](#2-instal-git)
3. [Instal Visual Studio Code + ekstensi Flutter](#3-instal-visual-studio-code--ekstensi-flutter)
4. [Instal Flutter SDK](#4-instal-flutter-sdk)
5. [Instal Android Studio (Android SDK)](#5-instal-android-studio-android-sdk)
6. [Cek semuanya dengan `flutter doctor`](#6-cek-semuanya-dengan-flutter-doctor)
7. [Buka proyek HP Ceria di VS Code](#7-buka-proyek-hp-ceria-di-vs-code)
8. [Siapkan HP Android (USB debugging)](#8-siapkan-hp-android-usb-debugging)
9. [Jalankan aplikasi dari VS Code](#9-jalankan-aplikasi-dari-vs-code)
10. [Buat file APK final](#10-buat-file-apk-final)
11. [Pengaturan di HP anak (suara, mikrofon, sematkan layar)](#11-pengaturan-di-hp-anak)
12. [Pemakaian pertama & area orang tua](#12-pemakaian-pertama--area-orang-tua)
13. [OPSIONAL: Mode Kiosk Penuh (penguncian paling kuat)](#13-opsional-mode-kiosk-penuh-device-owner)
14. [Darurat: lupa PIN](#14-darurat-lupa-pin)
15. [Mengubah isi aplikasi](#15-mengubah-isi-aplikasi)
16. [Masalah umum & solusinya](#16-masalah-umum--solusinya)
17. [Batasan yang perlu diketahui](#17-batasan-yang-perlu-diketahui)

---

## 1. Yang perlu disiapkan

| Kebutuhan | Keterangan |
|---|---|
| Laptop Windows 11 | RAM minimal 8 GB, ruang kosong minimal **20 GB** |
| Internet | Unduhan total sekitar 5–8 GB |
| HP Android | **Android 7.0 atau lebih baru** (lebih baik Android 10+), ada kamera depan |
| Kabel USB data | Kabel yang bisa transfer data, bukan kabel khusus charger |
| File proyek | Folder `hp_ceria` (dari file zip yang diberikan) |

> 💡 Simpan proyek di folder yang **tidak mengandung spasi**, misalnya `C:\proyek\hp_ceria`.
> Jangan taruh di dalam folder OneDrive karena bisa mengganggu proses build.

---

## 2. Instal Git

Flutter membutuhkan Git.

1. Buka https://git-scm.com/download/win lalu unduh **64-bit Git for Windows Setup**.
2. Jalankan installer, lalu tekan **Next** terus (pengaturan bawaan sudah benar).
3. Setelah selesai, buka **PowerShell** (tekan tombol Windows, ketik `PowerShell`, Enter), lalu ketik:
   ```powershell
   git --version
   ```
   Kalau muncul misalnya `git version 2.xx`, berarti Git sudah terpasang.

---

## 3. Instal Visual Studio Code + ekstensi Flutter

1. Unduh VS Code dari https://code.visualstudio.com, lalu instal. Saat instalasi, centang:
   - ✅ *Add "Open with Code" action to Windows Explorer file context menu*
   - ✅ *Add to PATH*
2. Buka VS Code, lalu klik ikon **Extensions** di sisi kiri (ikon empat kotak) atau tekan `Ctrl+Shift+X`.
3. Cari **Flutter** (penerbit: *Dart Code*), lalu klik **Install**. Ekstensi **Dart** ikut terpasang otomatis.

---

## 4. Instal Flutter SDK

Proyek ini dibuat dan diuji dengan **Flutter 3.47.x (stable)**. Gunakan versi stable 3.47 atau yang lebih baru.

### Cara A (disarankan): lewat VS Code

1. Di VS Code tekan `Ctrl+Shift+P`, ketik **`Flutter: New Project`**, lalu Enter.
2. VS Code akan memberi tahu bahwa Flutter SDK belum ada. Klik **Download SDK**.
3. Pilih folder, misalnya `C:\src` (**jangan** `C:\Program Files`). Tunggu proses clone selesai (sekitar 5–15 menit).
4. Saat muncul tawaran **Add SDK to PATH**, klik **Add SDK to PATH**.
5. **Tutup lalu buka kembali** VS Code dan PowerShell.

### Cara B: manual

1. Buka https://docs.flutter.dev/install/archive lalu unduh file zip **Windows, Stable** versi terbaru.
2. Ekstrak ke `C:\src\flutter`, sehingga ada file `C:\src\flutter\bin\flutter.bat`.
3. Tambahkan ke PATH:
   - Tekan tombol Windows, ketik **"environment"**, lalu pilih **Edit environment variables for your account**.
   - Pilih **Path**, klik **Edit…**, klik **New**, isi `C:\src\flutter\bin`, lalu tekan OK.
4. Tutup lalu buka kembali PowerShell.

Cek hasilnya:
```powershell
flutter --version
```

---

## 5. Instal Android Studio (Android SDK)

Android Studio hanya dipakai untuk memasang **Android SDK** dan **Java (JDK)**. Kodenya tetap ditulis dan dijalankan dari VS Code.

1. Unduh dari https://developer.android.com/studio, lalu instal dengan pengaturan bawaan (*Standard*).
2. Buka Android Studio. Pada *Setup Wizard*, pilih **Standard** lalu tekan **Next** sampai selesai, dan tunggu unduhan SDK selesai.
3. Di halaman awal, klik **More Actions → SDK Manager**.
4. Tab **SDK Platforms**: centang versi Android terbaru (misalnya *Android 16 / API 36*).
5. Tab **SDK Tools**: pastikan semua ini tercentang:
   - ✅ Android SDK Build-Tools
   - ✅ **Android SDK Command-line Tools (latest)** ← penting
   - ✅ Android SDK Platform-Tools
6. Klik **Apply → OK**, lalu tunggu sampai selesai.
7. Kembali ke PowerShell, lalu setujui lisensi Android:
   ```powershell
   flutter doctor --android-licenses
   ```
   Ketik `y` lalu Enter untuk setiap pertanyaan.

---

## 6. Cek semuanya dengan `flutter doctor`

```powershell
flutter doctor
```

Hasil yang diharapkan:

```
[✓] Flutter (Channel stable, 3.47.x ...)
[✓] Windows Version
[✓] Android toolchain - develop for Android devices
[✓] VS Code
[✓] Connected device   (setelah HP terhubung, langkah 8)
```

- Tanda ✗ pada **Chrome** atau **Visual Studio** boleh diabaikan karena tidak dibutuhkan untuk Android.
- Kalau **Android toolchain** bertanda ✗, ulangi langkah 5.5 dan 5.7.

---

## 7. Buka proyek HP Ceria di VS Code

1. Ekstrak `hp_ceria.zip` ke `C:\proyek\`, sehingga ada folder `C:\proyek\hp_ceria\pubspec.yaml`.
2. Di VS Code: **File → Open Folder…**, lalu pilih `C:\proyek\hp_ceria`.
3. Kalau VS Code bertanya *"Do you trust the authors…"*, klik **Yes, I trust**.
4. Buka Terminal di VS Code (**Terminal → New Terminal**, atau `` Ctrl+` ``), lalu ketik:
   ```powershell
   flutter pub get
   ```
   Perintah ini mengunduh semua paket yang dipakai (suara, kamera, pendeteksi wajah, pemutar video, dll).

Struktur proyek:

```
hp_ceria/
├─ lib/
│  ├─ main.dart                 ← titik awal; pengunci Mode Anak & batas waktu
│  ├─ core/                     ← suara (TTS), pendengar (mikrofon), pengaturan, kiosk
│  ├─ data/
│  │  ├─ animals.dart           ← teman hewan (telepon/chat/video call)
│  │  ├─ learning_data.dart     ← materi belajar
│  │  └─ songs_data.dart        ← lirik lagu (dibuat otomatis)
│  └─ screens/                  ← semua layar: phone, messages, camera, video, songs, learn, games, parent
├─ assets/songs/  assets/sfx/   ← file lagu & efek suara (mp3)
├─ android/app/src/main/kotlin/ ← kode Android untuk penguncian layar (kiosk)
├─ tools/                       ← skrip pembuat lagu & ikon (opsional)
└─ test/                        ← tes otomatis
```

---

## 8. Siapkan HP Android (USB debugging)

1. Di HP: **Pengaturan → Tentang ponsel**, lalu ketuk **Nomor versi / Build number** sebanyak **7 kali** sampai muncul tulisan *"Anda sekarang adalah developer"*.
   - Samsung: *Pengaturan → Tentang ponsel → Informasi perangkat lunak → Nomor versi*
   - Xiaomi: *Pengaturan → Tentang ponsel → Versi MIUI/HyperOS* (ketuk 7×)
2. Kembali ke **Pengaturan → Sistem → Opsi pengembang** (Xiaomi: *Pengaturan tambahan → Opsi pengembang*).
3. Aktifkan **USB debugging**.
   - Xiaomi: aktifkan juga **Instal via USB** dan **USB debugging (Pengaturan keamanan)**.
4. Sambungkan HP ke laptop dengan kabel USB. Di HP akan muncul *"Izinkan USB debugging?"*. Centang **Selalu izinkan**, lalu tekan **Izinkan**.
5. Cek dari terminal VS Code:
   ```powershell
   flutter devices
   ```
   Nama HP harus muncul di daftar.

> Kalau HP tidak terdeteksi: ganti kabel atau port USB, ubah mode USB di notifikasi HP menjadi **Transfer file**, lalu instal driver USB dari produsen HP (Samsung: *Samsung USB Driver*).

---

## 9. Jalankan aplikasi dari VS Code

1. Di pojok kanan bawah VS Code, klik nama perangkat lalu pilih HP Anda.
2. Tekan **F5** (atau menu **Run → Start Debugging**), lalu pilih **HP Ceria (debug)**.
3. Build pertama butuh **5–15 menit** karena Gradle mengunduh komponen Android. Build berikutnya jauh lebih cepat.
4. Aplikasi akan terbuka di HP. Saat aplikasi berjalan, perubahan kode bisa langsung dilihat dengan menyimpan file (**Hot Reload**).

Atau lewat terminal:
```powershell
flutter run
```

> ⚠️ Mode **debug** lebih lambat dan menampilkan pesan debug. Untuk dipakai anak sehari-hari, gunakan APK **release** (langkah 10).

---

## 10. Buat file APK final

```powershell
flutter build apk --release
```

Hasilnya ada di:
```
C:\proyek\hp_ceria\build\app\outputs\flutter-apk\app-release.apk
```

Cara memasang APK ke HP:
- **Lewat kabel** (HP masih terhubung): `flutter install --release`
- **Tanpa kabel**: salin `app-release.apk` ke HP (lewat WhatsApp ke diri sendiri, Google Drive, atau kabel), buka file di HP, lalu izinkan *"Instal aplikasi tidak dikenal"*.

> 💡 Ukuran APK bisa diperkecil dengan `flutter build apk --release --split-per-abi`. Gunakan file `app-arm64-v8a-release.apk` untuk HP modern.

### (Opsional) Tanda tangan APK sendiri

APK saat ini ditandatangani dengan *debug key*. Ini cukup untuk dipasang di HP sendiri. Kalau ingin kunci sendiri (misalnya untuk dibagikan), ikuti https://docs.flutter.dev/deployment/android#sign-the-app.

---

## 11. Pengaturan di HP anak

Lakukan sekali di HP yang akan dipakai anak:

### a. Suara Bahasa Indonesia (supaya hewan bisa bicara)
1. Pastikan **Google Speech Services** (*Layanan Ucapan oleh Google*) terpasang. Kalau belum, instal dari Play Store.
2. **Pengaturan → Sistem → Bahasa & masukan → Output text-to-speech**.
3. Mesin pilihan: **Layanan Ucapan oleh Google**. Klik ⚙️ → **Instal data suara → Bahasa Indonesia**, lalu unduh.

### b. Pengenalan suara (supaya hewan "mendengar" anak)
1. Pastikan aplikasi **Google** terpasang dan sudah diperbarui.
2. Supaya tetap berfungsi tanpa internet: buka aplikasi Google → Profil → **Setelan → Suara → Pengenalan ucapan offline**, lalu unduh **Bahasa Indonesia**.

### c. Sematkan aplikasi (pengunci layar bawaan Android)
1. **Pengaturan → Keamanan (atau Keamanan & privasi) → Setelan lainnya → Sematkan aplikasi** (*App pinning / Screen pinning*), lalu **aktifkan**.
2. Aktifkan juga **"Minta PIN/pola sebelum melepas sematan"**.
3. Pastikan HP **memakai kunci layar** (PIN/pola), karena itulah yang diminta saat seseorang mencoba keluar.

> Lokasi menu berbeda di tiap merek. Cari kata **"sematkan"** atau **"pin"** di kolom pencarian Pengaturan.
> HP Ceria juga punya tombol pintas ke menu ini di **Pengaturan Orang Tua → Buka pengaturan Keamanan Android**.

### d. Izin aplikasi
Saat pertama kali membuka **Kamera** dan **Telepon**, HP Ceria akan meminta izin **Kamera** dan **Mikrofon**. Pilih **Izinkan**.

---

## 12. Pemakaian pertama & area orang tua

1. Buka **HP Ceria**. Halaman awal meminta **nama panggilan anak** dan **PIN orang tua 4 angka**.
2. Setelah itu Mode Anak aktif. Android akan menampilkan *"Aplikasi disematkan"* atau bertanya *"Sematkan aplikasi?"*. Pilih **Ya/Mengerti**.
3. Mulai sekarang tombol Home, Recent, dan notifikasi tidak bisa dipakai, dan tombol Kembali tidak bisa menutup aplikasi.

### Masuk ke Pengaturan Orang Tua
- **Tekan dan tahan ikon gembok 🔒** di pojok kanan atas layar beranda selama **3 detik**, lalu masukkan PIN.
- Kalau PIN salah 5 kali, akses terkunci selama 60 detik.

### Isi Pengaturan Orang Tua
| Menu | Fungsi |
|---|---|
| Nama anak | Dipakai saat hewan menyapa dan di lagu "Selamat Ulang Tahun" |
| Ganti PIN | Mengganti PIN |
| Batas waktu main per hari | 15–120 menit. Setelah habis, muncul layar "Waktunya istirahat" yang hanya bisa ditutup dengan PIN |
| Kelola daftar video | Tambah video dari **link YouTube** (buka YouTube → Bagikan → Salin link → tempel) atau dari **file video di HP** (bisa ditonton offline). Urutan bisa diubah dengan menyeret, dan video bisa dihapus |
| Keluar dari Mode Anak | Membuka kunci dan menutup aplikasi. Saat HP Ceria dibuka lagi, Mode Anak otomatis aktif kembali |

> 🎬 **Tentang video:** aplikasi **tidak** menyertakan daftar video bawaan. Orang tua yang memilih, supaya isinya terjamin aman.
> Ide pencarian: *"lagu anak indonesia balita"*, *"Cocomelon Bahasa Indonesia"*, *"Super Simple Songs"*, *"Pinkfong Bahasa Indonesia"*, *"dongeng anak"*.
> Tonton dulu sebelum menambahkannya. Di dalam pemutar, anak **tidak bisa** mengetuk tautan atau video lain dari YouTube.

---

## 13. (OPSIONAL) Mode Kiosk Penuh (Device Owner)

Mode "Sematkan aplikasi" sudah cukup untuk balita. Tapi orang yang tahu caranya tetap bisa mencoba keluar (dengan menahan tombol Kembali + Recent, lalu diminta PIN HP).
Kalau HP **khusus untuk anak**, Anda bisa menjadikan HP Ceria **Device Owner**. Hasilnya:
- penguncian langsung aktif tanpa pertanyaan,
- status bar, tombol Home/Recent, dan menu daya global dimatikan,
- HP Ceria menjadi layar utama, dan terbuka otomatis setelah HP dinyalakan ulang.

**Syarat:** Android melarang Device Owner kalau masih ada akun (Google, Samsung, Xiaomi, dll) di HP.

1. Pasang HP Ceria (langkah 9 atau 10).
2. Di HP: **Pengaturan → Akun**, lalu **hapus semua akun sementara**. Atau gunakan HP yang baru di-reset pabrik dan lewati login Google.
3. Di terminal VS Code (HP terhubung lewat USB):
   ```powershell
   cd $env:LOCALAPPDATA\Android\Sdk\platform-tools
   .\adb shell dpm set-device-owner com.keluarga.hp_ceria/.KidsDeviceAdminReceiver
   ```
   Kalau berhasil, muncul `Success: Device owner set to package ...`
4. Akun Google boleh ditambahkan lagi setelah ini.
5. Buka HP Ceria. Menu **Pengaturan Orang Tua** sekarang menampilkan **"Mode Kiosk Penuh aktif"**.

**Mematikan / sebelum uninstall:** Pengaturan Orang Tua → **Matikan Mode Kiosk Penuh (lepas Device Owner)**.
Aplikasi Device Owner **tidak bisa di-uninstall** sebelum status ini dilepas.

> Pesan error umum:
> - `Not allowed to set the device owner because there are already some accounts` → masih ada akun di HP (lihat langkah 2).
> - `java.lang.SecurityException` di Xiaomi → aktifkan **USB debugging (Pengaturan keamanan)**.

---

## 14. Darurat: lupa PIN

Hubungkan HP ke laptop (USB debugging harus masih aktif), lalu jalankan:

```powershell
cd $env:LOCALAPPDATA\Android\Sdk\platform-tools
.\adb shell am broadcast -a com.keluarga.hp_ceria.DARURAT -n com.keluarga.hp_ceria/.RescueReceiver
.\adb shell am force-stop com.keluarga.hp_ceria
```

Perintah ini menghapus PIN dan melepas Mode Kiosk Penuh. Buka lagi HP Ceria, lalu buat PIN baru.
Perintah ini hanya bisa dijalankan dari komputer lewat ADB. Aplikasi lain di HP tidak bisa memicunya.

Pada mode Sematkan biasa: tahan tombol **Kembali + Recent** (atau usap ke atas lalu tahan, kalau HP memakai navigasi gestur), lalu masukkan PIN layar HP untuk melepas sematan.

---

## 15. Mengubah isi aplikasi

Semua teks bisa diubah langsung di VS Code. Simpan file, lalu tekan **Hot Reload** (`Ctrl+F5` / ikon ⚡) saat aplikasi berjalan.

| Ingin mengubah | File |
|---|---|
| Kartu belajar (hewan, warna, huruf, dll) | `lib/data/learning_data.dart` |
| Teman hewan: nama, sapaan, pertanyaan, bunyi | `lib/data/animals.dart` |
| Balasan bot chat/telepon | `FriendBrain.reply` di `lib/data/animals.dart` |
| Warna tema | `lib/core/theme.dart` |
| Ikon di beranda | `_apps` di `lib/screens/home_screen.dart` |
| Kecepatan/tinggi suara | `lib/core/speaker.dart` (`setSpeechRate`, `setPitch`) |
| Filter wajah | `lib/screens/camera/face_filters.dart` |
| Lagu (melodi & lirik) | `tools/buat_lagu.py` |

**Mengubah lagu:** lagu dibuat oleh skrip Python. Instal **Python 3** dan **ffmpeg**, lalu:
```powershell
pip install numpy
python tools\buat_lagu.py
```
Skrip ini membuat ulang `assets/songs/*.mp3`, `assets/sfx/*.mp3`, dan `lib/data/songs_data.dart`.
Anda juga bisa mengganti file mp3 dengan rekaman sendiri (misalnya Bunda yang bernyanyi), lalu menyesuaikan waktu lirik (`LyricLine(ms, teks)`) di `songs_data.dart`.

**Tes otomatis:**
```powershell
flutter analyze
flutter test
```

---

## 16. Masalah umum & solusinya

| Masalah | Solusi |
|---|---|
| `flutter` tidak dikenali | PATH belum benar (langkah 4). Tutup lalu buka lagi terminal/VS Code |
| `Android license status unknown` | `flutter doctor --android-licenses` |
| `cmdline-tools component is missing` | SDK Manager → SDK Tools → centang **Android SDK Command-line Tools** |
| Build Gradle sangat lama/gagal unduh | Periksa internet, lalu jalankan `flutter clean` dan `flutter run` lagi |
| `Execution failed for task ... minSdk` | HP terlalu lama; minimal Android 7.0 |
| Hewan tidak bersuara | Langkah 11a. Pastikan volume media tidak nol |
| Hewan tidak "mendengar" | Langkah 11b dan izin mikrofon. Kalau tetap tidak bisa, percakapan tetap berjalan otomatis |
| Kamera hitam / "belum diizinkan" | Pengaturan HP → Aplikasi → HP Ceria → Izin → Kamera: Izinkan |
| Filter wajah tidak muncul | Butuh cahaya cukup dan wajah menghadap kamera, dengan jarak sekitar 30–60 cm |
| Video YouTube tidak jalan | Butuh internet. Beberapa video melarang diputar di aplikasi lain (*embed*); ganti video lain |
| Layar tidak terkunci | Langkah 11c. Pastikan "Sematkan aplikasi" aktif |
| Emoji tampil berbeda | Bentuk emoji bergantung versi Android/merek HP; ini normal |
| Lupa PIN | Langkah 14 |

---

## 17. Batasan yang perlu diketahui

- **Telepon, SMS, dan kamera video call semuanya pura-pura.** Tidak ada panggilan atau SMS sungguhan, dan tidak ada data yang dikirim ke luar HP. Foto disimpan di folder pribadi aplikasi.
- **Pengenalan suara balita tidak sempurna.** Ucapan anak 2–3 tahun sering tidak dikenali. Karena itu percakapan dirancang agar tetap menyenangkan: hewan selalu merespons dengan ramah, apa pun yang terdengar.
- **Lagu berupa melodi instrumental + lirik karaoke**, karena suara robot (TTS) tidak bisa bernyanyi. Melodinya domain publik (*Twinkle Twinkle*, *Old MacDonald*, *Mary Had a Little Lamb*, *Row Your Boat*, *Happy Birthday*, *If You're Happy*, *Brahms' Lullaby*) dengan lirik Bahasa Indonesia yang ditulis khusus. Orang tua bisa ikut bernyanyi.
- **Mode Sematkan** bisa dilepas oleh orang yang tahu caranya dan tahu PIN layar HP. Untuk penguncian penuh gunakan langkah 13.
- **Video YouTube** butuh internet, dan beberapa video tidak bisa diputar di aplikasi pihak ketiga. Untuk offline, tambahkan file video dari HP.
- Batasi waktu layar: rekomendasi umum untuk anak 2–3 tahun adalah **maksimal ±1 jam per hari dengan didampingi orang tua**. Gunakan fitur *Batas waktu main per hari*.

Selamat mencoba! 🎀
