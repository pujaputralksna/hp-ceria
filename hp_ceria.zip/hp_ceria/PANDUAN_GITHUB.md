# Membuat APK HP Ceria Tanpa Laptop (GitHub Actions)

APK dibuat oleh server GitHub (gratis), lalu diunduh langsung ke HP. Semua langkah bisa dilakukan dari **Chrome di HP**.

## 1. Buat akun & repository
1. Buka https://github.com/signup lalu daftar (lewati kalau sudah punya akun).
2. Buka https://github.com/new
   - **Repository name:** `hp-ceria`
   - Pilih **Private**
   - Klik **Create repository**

## 2. Unggah file proyek
1. Di halaman repository, klik **uploading an existing file** (atau **Add file → Upload files**).
2. Pilih file **`hp_ceria.zip`** dari HP (biasanya di folder *Download*). **Jangan diekstrak.**
3. Klik **Commit changes**.

## 3. Buat file workflow
1. Klik **Add file → Create new file**.
2. Di kolom nama file ketik persis: `.github/workflows/build-apk.yml`
   (garis miring `/` otomatis membuat folder).
3. Tempel isi file `build-apk.yml` (dari chat / dari zip) ke kotak isi.
4. Klik **Commit changes** → **Commit changes**.

## 4. Tunggu build (± 10–15 menit)
- Buka tab **Actions**. Akan ada proses berlabel **Build APK HP Ceria** dengan ikon kuning berputar.
- Selesai bila ikonnya menjadi ✅ hijau. (Kalau ❌ merah, buka prosesnya, salin pesan error-nya ke chat.)

## 5. Unduh & pasang APK
1. Kembali ke halaman utama repository → bagian **Releases** (di kanan / bawah) → **HP Ceria build …**
2. Ketuk **hp-ceria.apk** untuk mengunduh.
3. Buka file yang sudah diunduh → izinkan **Instal aplikasi tidak dikenal** untuk Chrome → **Instal**.

Setelah itu lanjutkan dengan **PANDUAN.md langkah 11–12** (suara Indonesia, sematkan aplikasi, PIN).

## Membuat APK versi baru
Setiap kali ada perubahan (mengunggah `hp_ceria.zip` baru, atau mengedit file apa pun), GitHub otomatis membuat APK baru di **Releases**. Bisa juga dijalankan manual: **Actions → Build APK HP Ceria → Run workflow**.
