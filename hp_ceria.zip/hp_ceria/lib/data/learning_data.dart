import 'package:flutter/material.dart';

enum ShapeKind { lingkaran, segitiga, persegi, persegiPanjang, bintang, hati, oval, belahKetupat }

/// Satu kartu belajar.
class LearnItem {
  const LearnItem(this.name, {this.emoji, this.say, this.swatch, this.shape, this.count, this.inQuiz = true});

  final String name;
  final String? emoji;

  /// Kalimat yang diucapkan saat kartu disentuh. Default: nama kartu.
  final String? say;

  /// Untuk kategori Warna.
  final Color? swatch;

  /// Untuk kategori Bentuk.
  final ShapeKind? shape;

  /// Untuk kategori Angka: jumlah [emoji] yang ditampilkan.
  final int? count;

  /// false = kartu ini tidak dipakai di kuis "Tebak".
  final bool inQuiz;

  String get speech => say ?? name;
}

class LearnCategory {
  const LearnCategory(this.title, this.emoji, this.color, this.items);
  final String title;
  final String emoji;
  final Color color;
  final List<LearnItem> items;
}

const learnCategories = <LearnCategory>[
  LearnCategory('Hewan', '🐮', Color(0xFF66BB6A), [
    LearnItem('Kucing', emoji: '🐱', say: 'Kucing. Kucing bilang, meong meong!'),
    LearnItem('Anjing', emoji: '🐶', say: 'Anjing. Anjing bilang, guk guk!'),
    LearnItem('Sapi', emoji: '🐮', say: 'Sapi. Sapi bilang, mooo!'),
    LearnItem('Ayam', emoji: '🐔', say: 'Ayam. Ayam bilang, kukuruyuuuk!'),
    LearnItem('Bebek', emoji: '🦆', say: 'Bebek. Bebek bilang, kwek kwek!'),
    LearnItem('Kambing', emoji: '🐐', say: 'Kambing. Kambing bilang, mbeeek!'),
    LearnItem('Kuda', emoji: '🐴', say: 'Kuda. Kuda bilang, hiiiik!'),
    LearnItem('Katak', emoji: '🐸', say: 'Katak. Katak bilang, kuak kuak!'),
    LearnItem('Singa', emoji: '🦁', say: 'Singa. Singa bilang, aum!'),
    LearnItem('Gajah', emoji: '🐘', say: 'Gajah. Gajah punya belalai panjang!'),
    LearnItem('Monyet', emoji: '🐵', say: 'Monyet. Monyet bilang, uuu aaa!'),
    LearnItem('Burung', emoji: '🐦', say: 'Burung. Burung bilang, cuit cuit!'),
    LearnItem('Ikan', emoji: '🐟', say: 'Ikan. Ikan berenang di air. Blub blub!'),
    LearnItem('Kelinci', emoji: '🐰', say: 'Kelinci. Kelinci suka makan wortel.'),
    LearnItem('Lebah', emoji: '🐝', say: 'Lebah. Lebah bilang, nguuung!'),
    LearnItem('Kupu-kupu', emoji: '🦋', say: 'Kupu-kupu. Sayapnya cantik sekali!'),
  ]),
  LearnCategory('Warna', '🎨', Color(0xFFEF5350), [
    LearnItem('Merah', swatch: Color(0xFFE53935), emoji: '🍎', say: 'Merah. Apel warnanya merah.'),
    LearnItem('Kuning', swatch: Color(0xFFFDD835), emoji: '🍌', say: 'Kuning. Pisang warnanya kuning.'),
    LearnItem('Biru', swatch: Color(0xFF1E88E5), emoji: '🐳', say: 'Biru. Langit warnanya biru.'),
    LearnItem('Hijau', swatch: Color(0xFF43A047), emoji: '🍃', say: 'Hijau. Daun warnanya hijau.'),
    LearnItem('Oranye', swatch: Color(0xFFFB8C00), emoji: '🍊', say: 'Oranye. Jeruk warnanya oranye.'),
    LearnItem('Ungu', swatch: Color(0xFF8E24AA), emoji: '🍇', say: 'Ungu. Anggur warnanya ungu.'),
    LearnItem('Merah Muda', swatch: Color(0xFFF06292), emoji: '🌸', say: 'Merah muda. Bunga ini merah muda.'),
    LearnItem('Cokelat', swatch: Color(0xFF6D4C41), emoji: '🧸', say: 'Cokelat. Boneka beruang warnanya cokelat.'),
    LearnItem('Hitam', swatch: Color(0xFF212121), emoji: '🐈‍⬛', say: 'Hitam. Kucing ini warnanya hitam.'),
    LearnItem('Putih', swatch: Color(0xFFFFFFFF), emoji: '🥛', say: 'Putih. Susu warnanya putih.'),
  ]),
  LearnCategory('Bentuk', '🔷', Color(0xFF42A5F5), [
    LearnItem('Lingkaran', shape: ShapeKind.lingkaran, say: 'Lingkaran. Bulat seperti bola.'),
    LearnItem('Segitiga', shape: ShapeKind.segitiga, say: 'Segitiga. Punya tiga sisi.'),
    LearnItem('Persegi', shape: ShapeKind.persegi, say: 'Persegi. Kotak, punya empat sisi sama panjang.'),
    LearnItem('Persegi Panjang', shape: ShapeKind.persegiPanjang, say: 'Persegi panjang. Seperti pintu.'),
    LearnItem('Bintang', shape: ShapeKind.bintang, say: 'Bintang. Berkelip di langit malam.'),
    LearnItem('Hati', shape: ShapeKind.hati, say: 'Hati. Tanda sayang.'),
    LearnItem('Oval', shape: ShapeKind.oval, say: 'Oval. Seperti telur.'),
    LearnItem('Belah Ketupat', shape: ShapeKind.belahKetupat, say: 'Belah ketupat. Seperti layang-layang.'),
  ]),
  LearnCategory('Angka', '🔢', Color(0xFFFFA726), [
    LearnItem('1', emoji: '🍎', count: 1, say: 'Satu. Satu apel.'),
    LearnItem('2', emoji: '🍌', count: 2, say: 'Dua. Satu, dua. Dua pisang.'),
    LearnItem('3', emoji: '🐥', count: 3, say: 'Tiga. Satu, dua, tiga. Tiga anak ayam.'),
    LearnItem('4', emoji: '🌸', count: 4, say: 'Empat. Satu, dua, tiga, empat. Empat bunga.'),
    LearnItem('5', emoji: '⭐', count: 5, say: 'Lima. Satu, dua, tiga, empat, lima. Lima bintang.'),
    LearnItem('6', emoji: '🎈', count: 6, say: 'Enam. Enam balon.'),
    LearnItem('7', emoji: '🍓', count: 7, say: 'Tujuh. Tujuh stroberi.'),
    LearnItem('8', emoji: '🦋', count: 8, say: 'Delapan. Delapan kupu-kupu.'),
    LearnItem('9', emoji: '🐟', count: 9, say: 'Sembilan. Sembilan ikan.'),
    LearnItem('10', emoji: '🧁', count: 10, say: 'Sepuluh. Sepuluh kue.'),
  ]),
  LearnCategory('Huruf', '🔤', Color(0xFF26A69A), [
    LearnItem('A', emoji: '🍎', say: 'A. A untuk Apel.'),
    LearnItem('B', emoji: '⚽', say: 'B. B untuk Bola.'),
    LearnItem('C', emoji: '🐛', say: 'C. C untuk Cacing.'),
    LearnItem('D', emoji: '🍃', say: 'D. D untuk Daun.'),
    LearnItem('E', emoji: '🦅', say: 'E. E untuk Elang.'),
    LearnItem('F', emoji: '📷', say: 'F. F untuk Foto.'),
    LearnItem('G', emoji: '🐘', say: 'G. G untuk Gajah.'),
    LearnItem('H', emoji: '💖', say: 'H. H untuk Hati.'),
    LearnItem('I', emoji: '🐟', say: 'I. I untuk Ikan.'),
    LearnItem('J', emoji: '🍊', say: 'J. J untuk Jeruk.'),
    LearnItem('K', emoji: '🐱', say: 'K. K untuk Kucing.'),
    LearnItem('L', emoji: '🐝', say: 'L. L untuk Lebah.'),
    LearnItem('M', emoji: '🚗', say: 'M. M untuk Mobil.'),
    LearnItem('N', emoji: '🍚', say: 'N. N untuk Nasi.'),
    LearnItem('O', emoji: '🦧', say: 'O. O untuk Orang utan.'),
    LearnItem('P', emoji: '🍌', say: 'P. P untuk Pisang.'),
    LearnItem('Q', emoji: '📖', say: 'Q. Q untuk Quran.'),
    LearnItem('R', emoji: '🏠', say: 'R. R untuk Rumah.'),
    LearnItem('S', emoji: '🐄', say: 'S. S untuk Sapi.'),
    LearnItem('T', emoji: '🎩', say: 'T. T untuk Topi.'),
    LearnItem('U', emoji: '🦐', say: 'U. U untuk Udang.'),
    LearnItem('V', emoji: '🎻', say: 'V. V untuk Violin.'),
    LearnItem('W', emoji: '🥕', say: 'W. W untuk Wortel.'),
    LearnItem('X', emoji: '🎼', say: 'X. X untuk Xilofon.'),
    LearnItem('Y', emoji: '🪀', say: 'Y. Y untuk Yoyo.'),
    LearnItem('Z', emoji: '🦓', say: 'Z. Z untuk Zebra.'),
  ]),
  LearnCategory('Buah', '🍓', Color(0xFFEC407A), [
    LearnItem('Apel', emoji: '🍎'),
    LearnItem('Pisang', emoji: '🍌'),
    LearnItem('Jeruk', emoji: '🍊'),
    LearnItem('Anggur', emoji: '🍇'),
    LearnItem('Semangka', emoji: '🍉'),
    LearnItem('Stroberi', emoji: '🍓'),
    LearnItem('Mangga', emoji: '🥭'),
    LearnItem('Nanas', emoji: '🍍'),
    LearnItem('Kelapa', emoji: '🥥'),
    LearnItem('Pir', emoji: '🍐'),
    LearnItem('Ceri', emoji: '🍒'),
    LearnItem('Alpukat', emoji: '🥑'),
  ]),
  LearnCategory('Kendaraan', '🚗', Color(0xFF5C6BC0), [
    LearnItem('Mobil', emoji: '🚗', say: 'Mobil. Brum brum!'),
    LearnItem('Bus', emoji: '🚌', say: 'Bus. Bus membawa banyak orang.'),
    LearnItem('Kereta', emoji: '🚂', say: 'Kereta api. Tut tut tuuut!'),
    LearnItem('Pesawat', emoji: '🛫', say: 'Pesawat. Terbang tinggi di langit. Ngeeeng!'),
    LearnItem('Sepeda', emoji: '🚲', say: 'Sepeda. Kring kring!'),
    LearnItem('Motor', emoji: '🏍️', say: 'Motor. Bremm bremm!'),
    LearnItem('Kapal', emoji: '🚢', say: 'Kapal. Berlayar di laut. Tuuut!'),
    LearnItem('Pemadam Kebakaran', emoji: '🚒', say: 'Mobil pemadam kebakaran. Nguing nguing!'),
    LearnItem('Ambulans', emoji: '🚑', say: 'Ambulans. Menolong orang sakit.'),
    LearnItem('Helikopter', emoji: '🚁', say: 'Helikopter. Baling-balingnya berputar!'),
  ]),
  LearnCategory('Tubuhku', '👀', Color(0xFFAB47BC), [
    LearnItem('Mata', emoji: '👀', say: 'Mata. Untuk melihat. Tunjuk matamu!'),
    LearnItem('Hidung', emoji: '👃', say: 'Hidung. Untuk mencium bau. Tunjuk hidungmu!'),
    LearnItem('Mulut', emoji: '👄', say: 'Mulut. Untuk makan dan bicara.'),
    LearnItem('Telinga', emoji: '👂', say: 'Telinga. Untuk mendengar. Tunjuk telingamu!'),
    LearnItem('Tangan', emoji: '✋', say: 'Tangan. Ayo tepuk tangan!'),
    LearnItem('Kaki', emoji: '🦶', say: 'Kaki. Untuk berjalan dan melompat.'),
    LearnItem('Gigi', emoji: '🦷', say: 'Gigi. Jangan lupa sikat gigi ya!'),
    LearnItem('Rambut', emoji: '💇‍♀️', say: 'Rambut. Rambutmu cantik!'),
    LearnItem(
      'Tubuhku Berharga',
      emoji: '🛡️',
      inQuiz: false,
      say:
          'Tubuhku milikku. Bagian tubuh yang tertutup baju dalam tidak boleh disentuh orang lain. '
          'Kalau ada yang mau menyentuh, bilang TIDAK, lalu cerita ke Bunda dan Ayah.',
    ),
  ]),
  LearnCategory('Keluarga', '👨‍👩‍👧', Color(0xFFFF7043), [
    LearnItem('Bunda', emoji: '👩', say: 'Bunda. Bunda sayang kamu.'),
    LearnItem('Ayah', emoji: '👨', say: 'Ayah. Ayah sayang kamu.'),
    LearnItem('Kakak', emoji: '👧', say: 'Kakak.'),
    LearnItem('Adik Bayi', emoji: '👶', say: 'Adik bayi. Kecil dan lucu.'),
    LearnItem('Nenek', emoji: '👵', say: 'Nenek.'),
    LearnItem('Kakek', emoji: '👴', say: 'Kakek.'),
  ]),
  LearnCategory('Perasaan', '😊', Color(0xFFFFCA28), [
    LearnItem('Senang', emoji: '😊', say: 'Senang. Kalau senang, kita tersenyum!'),
    LearnItem('Sedih', emoji: '😢', say: 'Sedih. Kalau sedih, boleh menangis dan minta peluk Bunda.'),
    LearnItem('Marah', emoji: '😠', say: 'Marah. Kalau marah, tarik napas pelan-pelan. Huuuu.'),
    LearnItem('Takut', emoji: '😨', say: 'Takut. Kalau takut, peluk Ayah atau Bunda.'),
    LearnItem('Mengantuk', emoji: '😴', say: 'Mengantuk. Waktunya tidur.'),
    LearnItem('Terkejut', emoji: '😲', say: 'Terkejut. Wah!'),
    LearnItem('Sayang', emoji: '🥰', say: 'Sayang. Aku sayang Bunda dan Ayah.'),
  ]),
  LearnCategory('Kebiasaan Baik', '🪥', Color(0xFF29B6F6), [
    LearnItem('Bangun Tidur', emoji: '🌞', say: 'Bangun tidur, berdoa dulu, lalu bilang selamat pagi!'),
    LearnItem('Pipis di Toilet', emoji: '🚽', say: 'Kalau mau pipis, bilang ke Bunda, lalu pipis di toilet. Pintar!'),
    LearnItem('Cuci Tangan', emoji: '🧼', say: 'Cuci tangan pakai sabun. Gosok gosok, bilas, bersih!'),
    LearnItem('Sikat Gigi', emoji: '🪥', say: 'Sikat gigi pagi dan malam. Gosok gosok gosok!'),
    LearnItem('Mandi', emoji: '🛁', say: 'Mandi supaya badan bersih dan wangi.'),
    LearnItem('Pakai Baju', emoji: '👗', say: 'Pakai baju sendiri. Masukkan tangan, lalu kepala. Hebat!'),
    LearnItem('Sisir Rambut', emoji: '🎀', say: 'Sisir rambut supaya rapi dan cantik.'),
    LearnItem('Makan Sendiri', emoji: '🍽️', say: 'Berdoa sebelum makan, lalu makan sendiri pakai sendok.'),
    LearnItem('Berbagi', emoji: '🤝', say: 'Berbagi mainan dengan teman. Teman jadi senang.'),
    LearnItem('Bereskan Mainan', emoji: '🧸', say: 'Selesai main, mainan dibereskan ke tempatnya.'),
    LearnItem('Terima Kasih', emoji: '🙏', say: 'Kalau diberi sesuatu, bilang terima kasih.'),
    LearnItem('Tidur Siang', emoji: '😴', say: 'Tidur siang supaya badan segar.'),
  ]),
];
