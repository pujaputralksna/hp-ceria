import 'dart:math';

import 'package:flutter/material.dart';

/// Teman-teman hewan yang bisa ditelepon, dikirimi pesan, dan diajak video call.
class AnimalFriend {
  const AnimalFriend({
    required this.id,
    required this.name,
    required this.emoji,
    required this.color,
    required this.sound,
    required this.pitch,
    required this.intro,
    required this.questions,
    required this.facts,
    required this.status,
  });

  final String id;
  final String name;
  final String emoji;
  final Color color;

  /// Bunyi khas, mis. "Meong meong!"
  final String sound;

  /// Tinggi-rendah suara TTS (1.0 normal).
  final double pitch;
  final String intro;
  final List<String> questions;
  final List<String> facts;

  /// Status singkat yang tampil di daftar kontak / chat.
  final String status;
}

const animalFriends = <AnimalFriend>[
  AnimalFriend(
    id: 'kucing',
    name: 'Mimi Kucing',
    emoji: '🐱',
    color: Color(0xFFFFB74D),
    sound: 'Meong, meong!',
    pitch: 1.6,
    intro: 'Halo {nama}! Ini Mimi Kucing. Meong meong!',
    questions: [
      'Kamu sudah makan belum?',
      'Mimi suka minum susu. Kamu suka susu juga?',
      'Ayo kita main bola benang! Kamu mau?',
      'Kamu sedang apa sekarang?',
    ],
    facts: ['Mimi suka tidur di tempat yang hangat.', 'Kalau senang, Mimi mendengkur, rrrr rrrr.'],
    status: 'Sedang main bola benang 🧶',
  ),
  AnimalFriend(
    id: 'anjing',
    name: 'Bobo Anjing',
    emoji: '🐶',
    color: Color(0xFF8D6E63),
    sound: 'Guk, guk, guk!',
    pitch: 1.0,
    intro: 'Guk guk! Halo {nama}! Ini Bobo Anjing!',
    questions: [
      'Ayo kita lari-lari! Kamu bisa lompat?',
      'Bobo suka tulang. Kamu suka makan apa?',
      'Kamu sudah mandi belum hari ini?',
      'Coba tepuk tangan! Prok prok prok!',
    ],
    facts: ['Bobo pandai menjaga rumah.', 'Kalau senang, ekor Bobo bergoyang-goyang.'],
    status: 'Menggoyangkan ekor 🦴',
  ),
  AnimalFriend(
    id: 'kelinci',
    name: 'Cici Kelinci',
    emoji: '🐰',
    color: Color(0xFFF48FB1),
    sound: 'Hop, hop, hop!',
    pitch: 1.8,
    intro: 'Hai {nama}! Aku Cici Kelinci. Hop hop hop!',
    questions: [
      'Cici suka wortel. Wortel warnanya apa ya?',
      'Ayo melompat seperti kelinci! Hop hop!',
      'Kamu punya boneka kesayangan?',
      'Kamu sudah sikat gigi belum?',
    ],
    facts: ['Telinga Cici panjang sekali.', 'Cici suka makan sayur supaya sehat.'],
    status: 'Makan wortel 🥕',
  ),
  AnimalFriend(
    id: 'bebek',
    name: 'Kiki Bebek',
    emoji: '🦆',
    color: Color(0xFFFFD54F),
    sound: 'Kwek, kwek, kwek!',
    pitch: 1.5,
    intro: 'Kwek kwek! Halo {nama}! Ini Kiki Bebek!',
    questions: [
      'Kiki suka berenang. Kamu suka main air?',
      'Ayo jalan seperti bebek! Kwek kwek!',
      'Kamu suka warna kuning?',
      'Hari ini kamu senang tidak?',
    ],
    facts: ['Kiki berenang di kolam bersama teman-teman.', 'Kaki Kiki berbentuk seperti dayung.'],
    status: 'Berenang di kolam 💦',
  ),
  AnimalFriend(
    id: 'gajah',
    name: 'Gugu Gajah',
    emoji: '🐘',
    color: Color(0xFF90A4AE),
    sound: 'Prooot, prooot!',
    pitch: 0.6,
    intro: 'Halo {nama}! Ini Gugu Gajah. Badanku besar sekali!',
    questions: [
      'Belalai Gugu panjang. Coba tunjuk hidung kamu!',
      'Gugu suka pisang. Kamu suka pisang?',
      'Ayo jalan pelan-pelan seperti gajah. Dum dum dum!',
      'Kamu sudah minum air putih?',
    ],
    facts: ['Gugu menyemprot air dengan belalainya.', 'Gajah adalah hewan darat yang paling besar.'],
    status: 'Mandi pakai belalai 🛁',
  ),
  AnimalFriend(
    id: 'singa',
    name: 'Leo Singa',
    emoji: '🦁',
    color: Color(0xFFFFA726),
    sound: 'Aum, aum!',
    pitch: 0.75,
    intro: 'Aum! Halo {nama}! Ini Leo Singa. Jangan takut ya, aku baik!',
    questions: [
      'Coba kamu mengaum seperti Leo! Aum!',
      'Rambut Leo lebat. Rambut kamu panjang atau pendek?',
      'Kamu berani tidak?',
      'Leo suka tidur siang. Kamu tidur siang juga?',
    ],
    facts: ['Leo disebut raja hutan.', 'Suara aum Leo bisa terdengar jauh sekali.'],
    status: 'Tidur siang 😴',
  ),
  AnimalFriend(
    id: 'panda',
    name: 'Pipi Panda',
    emoji: '🐼',
    color: Color(0xFF9E9E9E),
    sound: 'Hmm, nyam nyam!',
    pitch: 1.1,
    intro: 'Halo {nama}! Aku Pipi Panda. Mau peluk?',
    questions: [
      'Pipi suka makan bambu. Kamu sudah makan sayur?',
      'Bulu Pipi warna hitam dan putih. Baju kamu warna apa?',
      'Ayo berguling-guling!',
      'Kamu sayang Bunda?',
    ],
    facts: ['Panda suka memanjat pohon.', 'Panda makan bambu setiap hari.'],
    status: 'Makan bambu 🎋',
  ),
  AnimalFriend(
    id: 'unicorn',
    name: 'Lala Unicorn',
    emoji: '🦄',
    color: Color(0xFFBA68C8),
    sound: 'Hiiik! Bling bling!',
    pitch: 1.5,
    intro: 'Hai Putri {nama}! Aku Lala Unicorn dari negeri pelangi!',
    questions: [
      'Pelangi itu banyak warnanya. Kamu suka warna apa?',
      'Ayo kita menari! Putar-putar!',
      'Kamu mau jadi putri yang baik hati?',
      'Sudah bilang terima kasih ke Bunda hari ini?',
    ],
    facts: ['Lala punya tanduk yang berkilau.', 'Lala suka berbagi dengan teman.'],
    status: 'Terbang di atas pelangi 🌈',
  ),
];

/// Otak sederhana untuk membalas ucapan / pesan anak.
class FriendBrain {
  FriendBrain(this.friend);
  final AnimalFriend friend;
  final _rand = Random();
  int _q = 0;

  String fill(String s, String childName) => s.replaceAll('{nama}', childName);

  String nextQuestion() {
    final q = friend.questions[_q % friend.questions.length];
    _q++;
    return q;
  }

  /// Membalas [heard] (teks dari anak). Bila kosong, tetap memberi respon yang hangat.
  String reply(String heard, String childName) {
    final h = heard.toLowerCase();
    String? r;
    if (_has(h, ['halo', 'hai', 'hallo', 'hi'])) {
      r = 'Halo juga $childName! Senang sekali dengar suaramu!';
    } else if (_has(h, ['sudah', 'udah', 'iya', 'ya', 'mau', 'suka'])) {
      r = 'Wah, hebat sekali! Pintar!';
    } else if (_has(h, ['belum', 'tidak', 'nggak', 'gak', 'enggak', 'ndak'])) {
      r = 'Oh begitu. Tidak apa-apa, nanti dicoba ya!';
    } else if (_has(h, ['makan', 'nasi', 'susu', 'kue', 'buah'])) {
      r = 'Nyam nyam! Makan yang banyak supaya sehat dan kuat ya!';
    } else if (_has(h, ['nyanyi', 'lagu'])) {
      r = 'La la la! Suaramu bagus sekali!';
    } else if (_has(h, ['sayang', 'cinta', 'love'])) {
      r = '${friend.name.split(' ').first} juga sayang $childName!';
    } else if (_has(h, ['dadah', 'bye', 'sampai jumpa', 'dah'])) {
      r = 'Dadah $childName! Sampai jumpa lagi!';
    } else if (_has(h, ['nama', 'siapa'])) {
      r = 'Namaku ${friend.name}. ${friend.sound}';
    } else if (_has(h, ['main', 'bermain'])) {
      r = 'Ayo main! Main itu seru sekali!';
    } else if (h.contains('❤️') || h.contains('💖') || h.contains('🥰')) {
      r = 'Aww, terima kasih peluknya! ${friend.name.split(' ').first} sayang kamu!';
    }
    return r ??
        _pick([
          'Wah, begitu ya! Seru sekali!',
          'Hihihi, kamu lucu sekali!',
          friend.sound,
          _pick(friend.facts),
          'Kamu pintar sekali, $childName!',
        ]);
  }

  bool _has(String h, List<String> words) =>
      words.any((w) => RegExp('(^|\\s)${RegExp.escape(w)}(\\s|\$|[!?.,])').hasMatch(h));

  T _pick<T>(List<T> l) => l[_rand.nextInt(l.length)];
}
