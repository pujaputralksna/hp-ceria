class LyricLine {
  const LyricLine(this.ms, this.text);
  final int ms;
  final String text;
}

class Song {
  const Song({
    required this.id,
    required this.title,
    required this.emoji,
    required this.color,
    required this.asset,
    required this.durationMs,
    required this.lines,
  });

  final String id;
  final String title;
  final String emoji;
  final int color;
  final String asset;
  final int durationMs;
  final List<LyricLine> lines;
}
