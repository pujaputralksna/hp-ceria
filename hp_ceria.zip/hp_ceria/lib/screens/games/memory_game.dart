import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';

const _pool = ['🐱', '🐶', '🐰', '🦄', '🐥', '🐼', '🍓', '🌸', '🦋', '🐟'];
const _names = {
  '🐱': 'kucing',
  '🐶': 'anjing',
  '🐰': 'kelinci',
  '🦄': 'unicorn',
  '🐥': 'anak ayam',
  '🐼': 'panda',
  '🍓': 'stroberi',
  '🌸': 'bunga',
  '🦋': 'kupu-kupu',
  '🐟': 'ikan',
};

/// Permainan mencari pasangan gambar. Dimulai 2 pasang, bertambah setelah menang (maks. 6).
class MemoryGame extends StatefulWidget {
  const MemoryGame({super.key});

  @override
  State<MemoryGame> createState() => _MemoryGameState();
}

class _MemoryGameState extends State<MemoryGame> {
  int _pairs = 2;
  late List<String> _cards;
  final _open = <int>{};
  final _done = <int>{};
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _deal();
  }

  void _deal() {
    final pick = ([..._pool]..shuffle()).take(_pairs).toList();
    _cards = [...pick, ...pick]..shuffle(Random());
    _open.clear();
    _done.clear();
    setState(() {});
  }

  Future<void> _tap(int i) async {
    if (_busy || _open.contains(i) || _done.contains(i)) return;
    setState(() => _open.add(i));
    Speaker.instance.say(_names[_cards[i]] ?? '');
    if (_open.length < 2) return;
    _busy = true;
    final [a, b] = _open.toList();
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (_cards[a] == _cards[b]) {
      _done.addAll([a, b]);
      Sfx.play('benar');
    }
    _open.clear();
    _busy = false;
    setState(() {});
    if (_done.length == _cards.length) {
      Sfx.play('tepuk');
      await Speaker.instance.say('Hore! Semua ketemu! Pintar sekali!');
      _pairs = min(_pairs + 1, 6);
      if (mounted) _deal();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cols = _cards.length <= 4 ? 2 : 3;
    return KidScaffold(
      title: 'Cari Pasangan',
      color: const Color(0xFF42A5F5),
      body: Center(
        child: GridView.count(
          shrinkWrap: true,
          padding: const EdgeInsets.all(20),
          crossAxisCount: cols,
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          children: [
            for (var i = 0; i < _cards.length; i++)
              Bouncy(
                onTap: () => _tap(i),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
                  child: (_open.contains(i) || _done.contains(i))
                      ? Container(
                          key: const ValueKey('front'),
                          decoration: BoxDecoration(
                            color: _done.contains(i) ? const Color(0xFFC8E6C9) : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: const Color(0xFF42A5F5), width: 4),
                          ),
                          alignment: Alignment.center,
                          child: FittedBox(
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Text(_cards[i], style: const TextStyle(fontSize: 64)),
                            ),
                          ),
                        )
                      : Container(
                          key: const ValueKey('back'),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [Color(0xFF42A5F5), Color(0xFFAB47BC)]),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          alignment: Alignment.center,
                          child: const Text('❓', style: TextStyle(fontSize: 44)),
                        ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
