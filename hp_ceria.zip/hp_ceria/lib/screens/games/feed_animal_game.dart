import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';

const _pairs = <(String, String, String, String)>[
  // (hewan, nama, makanan, nama makanan)
  ('🐰', 'kelinci', '🥕', 'wortel'),
  ('🐵', 'monyet', '🍌', 'pisang'),
  ('🐱', 'kucing', '🐟', 'ikan'),
  ('🐶', 'anjing', '🦴', 'tulang'),
  ('🐼', 'panda', '🎋', 'bambu'),
  ('🐮', 'sapi', '🌿', 'rumput'),
  ('🐭', 'tikus', '🧀', 'keju'),
  ('🐻', 'beruang', '🍯', 'madu'),
];

/// Seret makanan ke mulut hewan yang lapar.
class FeedAnimalGame extends StatefulWidget {
  const FeedAnimalGame({super.key});

  @override
  State<FeedAnimalGame> createState() => _FeedAnimalGameState();
}

class _FeedAnimalGameState extends State<FeedAnimalGame> {
  final _rand = Random();
  late (String, String, String, String) _target;
  late List<(String, String, String, String)> _foods;
  bool _happy = false;
  bool _hover = false;

  @override
  void initState() {
    super.initState();
    _round();
  }

  void _round() {
    final list = [..._pairs]..shuffle(_rand);
    _target = list.first;
    _foods = list.take(3).toList()..shuffle(_rand);
    _happy = false;
    setState(() {});
    Speaker.instance.say('${_target.$2[0].toUpperCase()}${_target.$2.substring(1)} lapar. Kasih makan ya!');
  }

  Future<void> _feed((String, String, String, String) f) async {
    if (f == _target) {
      setState(() => _happy = true);
      Sfx.play('benar');
      await Speaker.instance.say('Nyam nyam! ${_target.$2} suka ${_target.$4}! Terima kasih!');
      await Future<void>.delayed(const Duration(milliseconds: 500));
      if (mounted) _round();
    } else {
      Sfx.play('coba');
      await Speaker.instance.say('${_target.$2} tidak makan ${f.$4}. Coba yang lain!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Beri Makan',
      color: const Color(0xFF66BB6A),
      body: Column(
        children: [
          Expanded(
            child: DragTarget<(String, String, String, String)>(
              onWillAcceptWithDetails: (_) {
                setState(() => _hover = true);
                return true;
              },
              onLeave: (_) => setState(() => _hover = false),
              onAcceptWithDetails: (d) {
                setState(() => _hover = false);
                _feed(d.data);
              },
              builder: (_, _, _) => Center(
                child: AnimatedScale(
                  scale: _hover ? 1.15 : 1,
                  duration: const Duration(milliseconds: 200),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_happy ? '😋' : '🍽️', style: const TextStyle(fontSize: 48)),
                      WigglingEmoji(_target.$1, size: 170),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const Text('Seret makanannya ke atas 👆', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 32),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                for (final f in _foods)
                  Draggable<(String, String, String, String)>(
                    data: f,
                    feedback: Material(
                      color: Colors.transparent,
                      child: Text(f.$3, style: const TextStyle(fontSize: 96)),
                    ),
                    childWhenDragging: Opacity(opacity: 0.3, child: _food(f)),
                    onDragStarted: () => Speaker.instance.say(f.$4),
                    child: _food(f),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _food((String, String, String, String) f) => Container(
    width: 100,
    height: 100,
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
    alignment: Alignment.center,
    child: Text(f.$3, style: const TextStyle(fontSize: 64)),
  );
}
