import 'package:flutter/material.dart';

import '../../core/speaker.dart';
import '../../core/widgets.dart';

class _Stroke {
  _Stroke(this.color, this.width);
  final Color color;
  final double width;
  final points = <Offset>[];
}

class _Stamp {
  _Stamp(this.emoji, this.at);
  final String emoji;
  final Offset at;
}

const _palette = <(Color, String)>[
  (Color(0xFFE53935), 'merah'),
  (Color(0xFFFB8C00), 'oranye'),
  (Color(0xFFFDD835), 'kuning'),
  (Color(0xFF43A047), 'hijau'),
  (Color(0xFF1E88E5), 'biru'),
  (Color(0xFF8E24AA), 'ungu'),
  (Color(0xFFF06292), 'merah muda'),
  (Color(0xFF6D4C41), 'cokelat'),
  (Color(0xFF212121), 'hitam'),
];

const _stamps = ['⭐', '💖', '🌸', '🦋', '🐱', '🌈', '🌞', '🎀'];

/// Melukis dengan jari + stempel emoji.
class PaintGame extends StatefulWidget {
  const PaintGame({super.key});

  @override
  State<PaintGame> createState() => _PaintGameState();
}

class _PaintGameState extends State<PaintGame> {
  final _strokes = <_Stroke>[];
  final _stampsPlaced = <_Stamp>[];
  final _order = <Object>[]; // urutan untuk tombol "batal"
  Color _color = _palette.first.$1;
  String? _stamp;

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Melukis',
      color: const Color(0xFFAB47BC),
      actions: [
        IconButton(
          iconSize: 34,
          icon: const Icon(Icons.undo_rounded),
          onPressed: () => setState(() {
            if (_order.isEmpty) return;
            final last = _order.removeLast();
            _strokes.remove(last);
            _stampsPlaced.remove(last);
          }),
        ),
        IconButton(
          iconSize: 34,
          icon: const Icon(Icons.delete_sweep_rounded),
          onPressed: () => setState(() {
            _strokes.clear();
            _stampsPlaced.clear();
            _order.clear();
          }),
        ),
      ],
      body: Column(
        children: [
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: GestureDetector(
                  onPanStart: (d) {
                    if (_stamp != null) return;
                    final s = _Stroke(_color, 18)..points.add(d.localPosition);
                    setState(() {
                      _strokes.add(s);
                      _order.add(s);
                    });
                  },
                  onPanUpdate: (d) {
                    if (_stamp != null || _strokes.isEmpty) return;
                    setState(() => _strokes.last.points.add(d.localPosition));
                  },
                  onTapDown: (d) {
                    final st = _stamp;
                    if (st == null) return;
                    final s = _Stamp(st, d.localPosition);
                    setState(() {
                      _stampsPlaced.add(s);
                      _order.add(s);
                    });
                  },
                  child: CustomPaint(painter: _CanvasPainter(_strokes, _stampsPlaced), size: Size.infinite),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 64,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              children: [
                for (final (c, name) in _palette)
                  Bouncy(
                    onTap: () {
                      setState(() {
                        _color = c;
                        _stamp = null;
                      });
                      Speaker.instance.say(name);
                    },
                    child: Container(
                      width: 52,
                      margin: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: c,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _stamp == null && _color == c ? Colors.white : Colors.transparent,
                          width: 5,
                        ),
                        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          SizedBox(
            height: 72,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
              children: [
                for (final e in _stamps)
                  Bouncy(
                    onTap: () => setState(() => _stamp = e),
                    child: Container(
                      width: 56,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        color: _stamp == e ? Colors.white : Colors.white54,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      alignment: Alignment.center,
                      child: Text(e, style: const TextStyle(fontSize: 34)),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CanvasPainter extends CustomPainter {
  _CanvasPainter(this.strokes, this.stamps);
  final List<_Stroke> strokes;
  final List<_Stamp> stamps;

  @override
  void paint(Canvas canvas, Size size) {
    for (final s in strokes) {
      final p = Paint()
        ..color = s.color
        ..strokeWidth = s.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke;
      if (s.points.length == 1) {
        canvas.drawCircle(s.points.first, s.width / 2, p..style = PaintingStyle.fill);
        continue;
      }
      final path = Path()..moveTo(s.points.first.dx, s.points.first.dy);
      for (final pt in s.points.skip(1)) {
        path.lineTo(pt.dx, pt.dy);
      }
      canvas.drawPath(path, p);
    }
    for (final st in stamps) {
      final tp = TextPainter(
        text: TextSpan(text: st.emoji, style: const TextStyle(fontSize: 56)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, st.at - Offset(tp.width / 2, tp.height / 2));
    }
  }

  @override
  bool shouldRepaint(_CanvasPainter old) => true;
}
