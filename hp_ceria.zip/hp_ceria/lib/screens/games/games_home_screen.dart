import 'package:flutter/material.dart';

import '../../core/speaker.dart';
import '../../core/widgets.dart';
import 'balloon_game.dart';
import 'dress_up_game.dart';
import 'feed_animal_game.dart';
import 'memory_game.dart';
import 'paint_game.dart';
import 'sound_guess_game.dart';

class GamesHomeScreen extends StatelessWidget {
  const GamesHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final games = <(String, String, Color, WidgetBuilder)>[
      ('🎈', 'Pecah Balon', const Color(0xFFEF5350), (_) => const BalloonGame()),
      ('🥕', 'Beri Makan', const Color(0xFF66BB6A), (_) => const FeedAnimalGame()),
      ('🃏', 'Cari Pasangan', const Color(0xFF42A5F5), (_) => const MemoryGame()),
      ('👂', 'Suara Siapa?', const Color(0xFFFFA726), (_) => const SoundGuessGame()),
      ('🖍️', 'Melukis', const Color(0xFFAB47BC), (_) => const PaintGame()),
      ('👗', 'Dandan Boneka', const Color(0xFFEC407A), (_) => const DressUpGame()),
    ];
    return KidScaffold(
      title: 'Main',
      color: const Color(0xFF26A69A),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        children: [
          for (final (emoji, label, color, builder) in games)
            BigTile(
              emoji: emoji,
              label: label,
              color: color,
              onTap: () {
                Speaker.instance.say(label);
                Navigator.push(context, MaterialPageRoute(builder: builder));
              },
            ),
        ],
      ),
    );
  }
}
