import 'package:flutter/material.dart';

import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';

class _Slot {
  const _Slot(this.title, this.icon, this.options);
  final String title;
  final String icon;

  /// (emoji, nama yang diucapkan)
  final List<(String, String)> options;
}

const _slots = <_Slot>[
  _Slot('Rambut', '🎀', [('', 'tanpa hiasan'), ('🎀', 'pita'), ('👑', 'mahkota'), ('👒', 'topi'), ('🌸', 'bunga')]),
  _Slot('Kacamata', '🕶️', [('', 'tanpa kacamata'), ('🕶️', 'kacamata hitam'), ('👓', 'kacamata')]),
  _Slot('Baju', '👗', [('👗', 'gaun'), ('👚', 'kaus'), ('🥋', 'baju putih'), ('🧥', 'jaket'), ('👘', 'kimono')]),
  _Slot('Sepatu', '🩰', [
    ('🩰', 'sepatu balet'),
    ('👟', 'sepatu olahraga'),
    ('🥿', 'sepatu flat'),
    ('👢', 'sepatu bot'),
  ]),
  _Slot('Teman', '🐱', [
    ('', 'tanpa teman'),
    ('🐱', 'kucing'),
    ('🐶', 'anjing'),
    ('🐰', 'kelinci'),
    ('🧸', 'boneka beruang'),
  ]),
  _Slot('Bawa', '👜', [('', 'tidak bawa apa-apa'), ('👜', 'tas'), ('🎈', 'balon'), ('🍭', 'permen'), ('🌂', 'payung')]),
];

/// Mendandani boneka: pilih hiasan rambut, baju, sepatu, dll.
class DressUpGame extends StatefulWidget {
  const DressUpGame({super.key});

  @override
  State<DressUpGame> createState() => _DressUpGameState();
}

class _DressUpGameState extends State<DressUpGame> {
  final _choice = List<int>.filled(_slots.length, 0);
  int _slot = 2;
  String _face = '👧';

  String _e(int slot) => _slots[slot].options[_choice[slot]].$1;

  @override
  Widget build(BuildContext context) {
    final s = _slots[_slot];
    return KidScaffold(
      title: 'Dandan Boneka',
      color: const Color(0xFFEC407A),
      background: const Color(0xFFFFF0F6),
      actions: [
        IconButton(
          iconSize: 34,
          icon: const Icon(Icons.auto_awesome),
          onPressed: () {
            Sfx.play('tepuk');
            Speaker.instance.say('Wah, cantik sekali!');
          },
        ),
      ],
      body: Column(
        children: [
          // Boneka
          Expanded(
            child: FittedBox(
              child: SizedBox(
                width: 320,
                height: 460,
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Positioned(
                      top: 100,
                      child: GestureDetector(
                        onTap: () => setState(() => _face = _face == '👧' ? '👧🏻' : (_face == '👧🏻' ? '👧🏽' : '👧')),
                        child: Text(_face, style: const TextStyle(fontSize: 120)),
                      ),
                    ),
                    if (_e(0).isNotEmpty) Positioned(top: 54, child: Text(_e(0), style: const TextStyle(fontSize: 82))),
                    if (_e(1).isNotEmpty)
                      Positioned(top: 146, child: Text(_e(1), style: const TextStyle(fontSize: 64))),
                    Positioned(top: 232, child: Text(_e(2), style: const TextStyle(fontSize: 120))),
                    Positioned(
                      top: 392,
                      child: Row(
                        children: [
                          Text(_e(3), style: const TextStyle(fontSize: 44)),
                          const SizedBox(width: 12),
                          Transform.flip(flipX: true, child: Text(_e(3), style: const TextStyle(fontSize: 44))),
                        ],
                      ),
                    ),
                    if (_e(4).isNotEmpty)
                      Positioned(left: 4, bottom: 4, child: Text(_e(4), style: const TextStyle(fontSize: 78))),
                    if (_e(5).isNotEmpty)
                      Positioned(right: 18, top: 250, child: Text(_e(5), style: const TextStyle(fontSize: 64))),
                  ],
                ),
              ),
            ),
          ),
          // Tab bagian
          SizedBox(
            height: 64,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              children: [
                for (var i = 0; i < _slots.length; i++)
                  Padding(
                    padding: const EdgeInsets.all(4),
                    child: ChoiceChip(
                      label: Text('${_slots[i].icon} ${_slots[i].title}', style: const TextStyle(fontSize: 18)),
                      selected: _slot == i,
                      onSelected: (_) {
                        setState(() => _slot = i);
                        Speaker.instance.say(_slots[i].title);
                      },
                    ),
                  ),
              ],
            ),
          ),
          // Pilihan
          Container(
            height: 110,
            color: Colors.white,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.all(10),
              children: [
                for (var i = 0; i < s.options.length; i++)
                  Bouncy(
                    onTap: () {
                      setState(() => _choice[_slot] = i);
                      Speaker.instance.say(s.options[i].$2);
                    },
                    child: Container(
                      width: 86,
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      decoration: BoxDecoration(
                        color: _choice[_slot] == i ? const Color(0xFFFFC1DD) : const Color(0xFFF5F5F5),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        s.options[i].$1.isEmpty ? '🚫' : s.options[i].$1,
                        style: const TextStyle(fontSize: 48),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
