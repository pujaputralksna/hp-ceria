import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';

const _animals = <(String, String, String)>[
  ('🐱', 'kucing', 'Meong, meong'),
  ('🐶', 'anjing', 'Guk guk, guk guk'),
  ('🐮', 'sapi', 'Mooo, mooo'),
  ('🐔', 'ayam', 'Kukuruyuuuk'),
  ('🦆', 'bebek', 'Kwek kwek kwek'),
  ('🐐', 'kambing', 'Mbeeek, mbeeek'),
  ('🐸', 'katak', 'Kuak kuak'),
  ('🦁', 'singa', 'Aum, aum'),
  ('🐵', 'monyet', 'Uuu aaa, uuu aaa'),
  ('🐝', 'lebah', 'Nguuuung'),
];

/// Mendengar bunyi hewan, lalu memilih hewan yang benar.
class SoundGuessGame extends StatefulWidget {
  const SoundGuessGame({super.key});

  @override
  State<SoundGuessGame> createState() => _SoundGuessGameState();
}

class _SoundGuessGameState extends State<SoundGuessGame> {
  final _rand = Random();
  late List<(String, String, String)> _opts;
  late (String, String, String) _ans;
  String? _wrong;
  bool _right = false;

  @override
  void initState() {
    super.initState();
    _round();
  }

  void _round() {
    _opts = ([..._animals]..shuffle(_rand)).take(3).toList();
    _ans = _opts[_rand.nextInt(3)];
    _wrong = null;
    _right = false;
    setState(() {});
    _play();
  }

  Future<void> _play() async {
    await Speaker.instance.say('Dengar ya. ${_ans.$3}! Suara siapa itu?');
  }

  Future<void> _pick((String, String, String) a) async {
    if (_right) return;
    if (a == _ans) {
      setState(() => _right = true);
      Sfx.play('benar');
      await Speaker.instance.say('Betul! Itu suara ${a.$2}! ${a.$3}!');
      if (mounted) _round();
    } else {
      setState(() => _wrong = a.$1);
      Sfx.play('coba');
      await Speaker.instance.say('Itu ${a.$2}. Coba lagi!');
    }
  }

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Suara Siapa?',
      color: const Color(0xFFFFA726),
      body: Column(
        children: [
          const SizedBox(height: 20),
          Bouncy(
            onTap: _play,
            child: const CircleAvatar(
              radius: 64,
              backgroundColor: Color(0xFFFFA726),
              child: Icon(Icons.hearing_rounded, size: 80, color: Colors.white),
            ),
          ),
          const SizedBox(height: 8),
          const Text('Sentuh telinga untuk mendengar lagi', style: TextStyle(fontSize: 16)),
          Expanded(
            child: Row(
              children: [
                for (final a in _opts)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Bouncy(
                        onTap: () => _pick(a),
                        child: AspectRatio(
                          aspectRatio: 0.8,
                          child: Container(
                            decoration: BoxDecoration(
                              color: _right && a == _ans
                                  ? Colors.lightGreenAccent
                                  : (_wrong == a.$1 ? Colors.red.shade100 : Colors.white),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            alignment: Alignment.center,
                            child: FittedBox(child: Text(a.$1, style: const TextStyle(fontSize: 80))),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
