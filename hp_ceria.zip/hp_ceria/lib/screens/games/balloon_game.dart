import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';

class _Balloon {
  _Balloon(this.x, this.color, this.name, this.speed, this.size);
  final double x;
  final Color color;
  final String name;
  final double speed;
  final double size;
  double y = 1.15;
  bool popped = false;
  double popT = 0;
}

const _colors = <(Color, String)>[
  (Color(0xFFE53935), 'merah'),
  (Color(0xFFFDD835), 'kuning'),
  (Color(0xFF1E88E5), 'biru'),
  (Color(0xFF43A047), 'hijau'),
  (Color(0xFF8E24AA), 'ungu'),
  (Color(0xFFF06292), 'merah muda'),
  (Color(0xFFFB8C00), 'oranye'),
];

/// Balon melayang naik — sentuh untuk memecahkannya.
class BalloonGame extends StatefulWidget {
  const BalloonGame({super.key});

  @override
  State<BalloonGame> createState() => _BalloonGameState();
}

class _BalloonGameState extends State<BalloonGame> with SingleTickerProviderStateMixin {
  final _rand = Random();
  final _balloons = <_Balloon>[];
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  double _spawn = 0;
  int _score = 0;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_tick)..start();
  }

  void _tick(Duration now) {
    final dt = (now - _last).inMicroseconds / 1e6;
    _last = now;
    if (dt <= 0 || dt > 0.2) return;
    _spawn -= dt;
    if (_spawn <= 0 && _balloons.length < 7) {
      final c = _colors[_rand.nextInt(_colors.length)];
      _balloons.add(
        _Balloon(
          0.08 + _rand.nextDouble() * 0.84,
          c.$1,
          c.$2,
          0.08 + _rand.nextDouble() * 0.07,
          90 + _rand.nextDouble() * 40,
        ),
      );
      _spawn = 0.9 + _rand.nextDouble();
    }
    for (final b in _balloons) {
      if (b.popped) {
        b.popT += dt;
      } else {
        b.y -= b.speed * dt;
      }
    }
    _balloons.removeWhere((b) => b.y < -0.25 || b.popT > 0.4);
    setState(() {});
  }

  void _pop(_Balloon b) {
    if (b.popped) return;
    b.popped = true;
    _score++;
    Sfx.play('pop');
    if (_score % 5 == 0) {
      Sfx.play('tepuk');
      Speaker.instance.say('Hore! $_score balon!');
    } else {
      Speaker.instance.say(b.name);
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Pecah Balon  🎈 $_score',
      color: const Color(0xFFEF5350),
      background: const Color(0xFFB3E5FC),
      body: LayoutBuilder(
        builder: (_, box) => Stack(
          children: [
            const Positioned(
              left: 20,
              top: 30,
              child: Text('☁️', style: TextStyle(fontSize: 70, color: Colors.white)),
            ),
            const Positioned(
              right: 30,
              top: 140,
              child: Text('☁️', style: TextStyle(fontSize: 50, color: Colors.white)),
            ),
            const Positioned(right: 20, top: 10, child: Text('🌞', style: TextStyle(fontSize: 60))),
            for (final b in _balloons)
              Positioned(
                left: b.x * box.maxWidth - b.size / 2,
                top: b.y * box.maxHeight,
                child: GestureDetector(
                  onTapDown: (_) => _pop(b),
                  child: b.popped
                      ? Opacity(
                          opacity: (1 - b.popT / 0.4).clamp(0, 1),
                          child: Text('💥', style: TextStyle(fontSize: b.size * (0.7 + b.popT))),
                        )
                      : _BalloonShape(color: b.color, size: b.size),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _BalloonShape extends StatelessWidget {
  const _BalloonShape({required this.color, required this.size});
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size * 1.6,
      child: Column(
        children: [
          Container(
            width: size,
            height: size * 1.2,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.all(Radius.elliptical(size, size * 1.2)),
              gradient: RadialGradient(
                center: const Alignment(-0.4, -0.5),
                radius: 0.9,
                colors: [Color.lerp(color, Colors.white, 0.55)!, color],
              ),
            ),
          ),
          Container(width: 2, height: size * 0.4, color: Colors.black38),
        ],
      ),
    );
  }
}
