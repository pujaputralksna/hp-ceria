import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import '../../core/settings.dart';
import '../../core/widgets.dart';
import 'video_home_screen.dart';

/// Halaman putar video: pemutar di atas, judul, lalu daftar "berikutnya".
/// Anak tidak bisa mengetuk tautan di dalam pemutar YouTube (semua sentuhan ditangani aplikasi).
class VideoPlayerScreen extends StatefulWidget {
  const VideoPlayerScreen({super.key, required this.playlist, required this.index});
  final List<VideoItem> playlist;
  final int index;

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late int _index = widget.index;
  bool _big = false;

  VideoItem get _item => widget.playlist[_index];

  void _open(int i) => setState(() => _index = i);

  void _next() {
    if (_index + 1 < widget.playlist.length) _open(_index + 1);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final player = _item.isYoutube
        ? _YoutubeView(key: ValueKey('yt$_index'), id: _item.source, onEnded: _next)
        : _LocalView(key: ValueKey('file$_index'), path: _item.source, onEnded: _next);
    final playerHeight = _big ? size.height - MediaQuery.paddingOf(context).vertical : size.width * 9 / 16;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: Colors.black,
              height: playerHeight,
              width: double.infinity,
              child: Stack(
                children: [
                  Center(
                    child: RotatedBox(
                      quarterTurns: _big ? 1 : 0,
                      child: AspectRatio(aspectRatio: 16 / 9, child: player),
                    ),
                  ),
                  const Align(alignment: Alignment.topLeft, child: KidBackButton()),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: IconButton(
                      iconSize: 40,
                      color: Colors.white,
                      icon: Icon(_big ? Icons.fullscreen_exit : Icons.fullscreen),
                      onPressed: () => setState(() => _big = !_big),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _big
                  ? const SizedBox.shrink()
                  : ListView(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(_item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                        ),
                        const Divider(),
                        for (var i = 0; i < widget.playlist.length; i++)
                          if (i != _index) VideoCard(item: widget.playlist[i], compact: true, onTap: () => _open(i)),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Tombol play/pause besar di atas video.
class _TapControls extends StatefulWidget {
  const _TapControls({required this.playing, required this.onToggle});
  final bool playing;
  final VoidCallback onToggle;

  @override
  State<_TapControls> createState() => _TapControlsState();
}

class _TapControlsState extends State<_TapControls> {
  bool _visible = true;
  Timer? _hide;

  void _show() {
    setState(() => _visible = true);
    _hide?.cancel();
    _hide = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => _visible = false);
    });
  }

  @override
  void initState() {
    super.initState();
    _show();
  }

  @override
  void dispose() {
    _hide?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final visible = _visible || !widget.playing;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (visible) {
          widget.onToggle();
        }
        _show();
      },
      child: AnimatedOpacity(
        opacity: visible ? 1 : 0,
        duration: const Duration(milliseconds: 250),
        child: Center(
          child: CircleAvatar(
            radius: 40,
            backgroundColor: Colors.black45,
            child: Icon(widget.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 56),
          ),
        ),
      ),
    );
  }
}

class _YoutubeView extends StatefulWidget {
  const _YoutubeView({super.key, required this.id, required this.onEnded});
  final String id;
  final VoidCallback onEnded;

  @override
  State<_YoutubeView> createState() => _YoutubeViewState();
}

class _YoutubeViewState extends State<_YoutubeView> {
  late final YoutubePlayerController _c = YoutubePlayerController.fromVideoId(
    videoId: widget.id,
    autoPlay: true,
    params: const YoutubePlayerParams(
      showControls: false,
      showFullscreenButton: false,
      showVideoAnnotations: false,
      strictRelatedVideos: true,
      enableCaption: false,
      interfaceLanguage: 'id',
      pointerEvents: PointerEvents.none,
    ),
  );
  StreamSubscription<YoutubePlayerValue>? _sub;
  bool _playing = true;

  @override
  void initState() {
    super.initState();
    _sub = _c.stream.listen((v) {
      final playing = v.playerState == PlayerState.playing || v.playerState == PlayerState.buffering;
      if (playing != _playing && mounted) setState(() => _playing = playing);
      if (v.playerState == PlayerState.ended) widget.onEnded();
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _c.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        YoutubePlayer(controller: _c, aspectRatio: 16 / 9),
        _TapControls(playing: _playing, onToggle: () => _playing ? _c.pauseVideo() : _c.playVideo()),
      ],
    );
  }
}

class _LocalView extends StatefulWidget {
  const _LocalView({super.key, required this.path, required this.onEnded});
  final String path;
  final VoidCallback onEnded;

  @override
  State<_LocalView> createState() => _LocalViewState();
}

class _LocalViewState extends State<_LocalView> {
  late final VideoPlayerController _c = VideoPlayerController.file(File(widget.path));
  bool _ended = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _c.addListener(_onTick);
    _c
        .initialize()
        .then((_) {
          if (mounted) setState(() {});
          _c.play();
        })
        .catchError((Object e) {
          if (mounted) setState(() => _error = 'Video tidak bisa diputar');
        });
  }

  void _onTick() {
    final v = _c.value;
    if (v.isInitialized && !_ended && v.position >= v.duration && v.duration > Duration.zero) {
      _ended = true;
      widget.onEnded();
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _c.removeListener(_onTick);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Center(
        child: Text(_error!, style: const TextStyle(color: Colors.white)),
      );
    }
    if (!_c.value.isInitialized) return const Center(child: CircularProgressIndicator());
    return Stack(
      fit: StackFit.expand,
      children: [
        FittedBox(
          child: SizedBox(width: _c.value.size.width, height: _c.value.size.height, child: VideoPlayer(_c)),
        ),
        _TapControls(playing: _c.value.isPlaying, onToggle: () => _c.value.isPlaying ? _c.pause() : _c.play()),
        Align(
          alignment: Alignment.bottomCenter,
          child: VideoProgressIndicator(
            _c,
            allowScrubbing: false,
            colors: const VideoProgressColors(playedColor: Colors.red),
          ),
        ),
      ],
    );
  }
}
