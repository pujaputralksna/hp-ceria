import 'package:flutter/material.dart';

import '../../core/settings.dart';
import '../../core/theme.dart';
import '../../core/widgets.dart';
import '../../data/songs_data.dart';
import '../songs/song_player_screen.dart';
import 'video_player_screen.dart';

/// Daftar video bergaya aplikasi video populer: logo merah, chip kategori, thumbnail besar.
class VideoHomeScreen extends StatefulWidget {
  const VideoHomeScreen({super.key});

  @override
  State<VideoHomeScreen> createState() => _VideoHomeScreenState();
}

class _VideoHomeScreenState extends State<VideoHomeScreen> {
  String _cat = 'Semua';

  @override
  Widget build(BuildContext context) {
    final all = AppSettings.instance.videos;
    final list = _cat == 'Semua' ? all : all.where((v) => v.category == _cat).toList();
    final showSongs = _cat == 'Semua' || _cat == 'Lagu';
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        toolbarHeight: 64,
        leadingWidth: 76,
        leading: const KidBackButton(color: Colors.black54),
        centerTitle: false,
        title: const FittedBox(fit: BoxFit.scaleDown, child: VideoLogo()),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 56,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              children: [
                for (final c in ['Semua', ...AppSettings.videoCategories])
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(c, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                      selected: _cat == c,
                      showCheckmark: false,
                      selectedColor: Colors.black87,
                      labelStyle: TextStyle(color: _cat == c ? Colors.white : Colors.black87),
                      backgroundColor: const Color(0xFFF2F2F2),
                      side: BorderSide.none,
                      onSelected: (_) => setState(() => _cat = c),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                for (var i = 0; i < list.length; i++)
                  VideoCard(
                    item: list[i],
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => VideoPlayerScreen(playlist: list, index: i),
                      ),
                    ),
                  ),
                if (showSongs)
                  for (var i = 0; i < songs.length; i++) _SongCard(index: i),
                if (list.isEmpty && !showSongs)
                  const Padding(
                    padding: EdgeInsets.all(40),
                    child: Text(
                      '📺\nBelum ada video di sini.\nMinta Ayah atau Bunda menambahkan ya!',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class VideoLogo extends StatelessWidget {
  const VideoLogo({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
          decoration: BoxDecoration(color: AppColors.youtubeRed, borderRadius: BorderRadius.circular(9)),
          child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 26),
        ),
        const SizedBox(width: 6),
        const Text(
          'Video Ceria',
          style: TextStyle(color: Colors.black87, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: -0.5),
        ),
      ],
    );
  }
}

class VideoCard extends StatelessWidget {
  const VideoCard({super.key, required this.item, required this.onTap, this.compact = false});
  final VideoItem item;
  final VoidCallback onTap;
  final bool compact;

  Widget _thumb() {
    final url = item.thumbnailUrl;
    final fallback = Container(
      color: const Color(0xFF263238),
      alignment: Alignment.center,
      child: const Icon(Icons.play_circle_fill, color: Colors.white70, size: 64),
    );
    final img = url != null
        ? Image.network(
            url,
            fit: BoxFit.cover,
            webHtmlElementStrategy: WebHtmlElementStrategy.fallback,
            errorBuilder: (_, _, _) => fallback,
          )
        : fallback;
    return AspectRatio(aspectRatio: 16 / 9, child: img);
  }

  @override
  Widget build(BuildContext context) {
    final avatar = CircleAvatar(
      backgroundColor: const Color(0xFFFFE4F1),
      child: Text(switch (item.category) {
        'Lagu' => '🎵',
        'Belajar' => '📚',
        'Dongeng' => '📖',
        _ => '🌈',
      }),
    );
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: compact ? const EdgeInsets.symmetric(horizontal: 12, vertical: 6) : const EdgeInsets.only(bottom: 16),
        child: compact
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 160,
                    child: ClipRRect(borderRadius: BorderRadius.circular(10), child: _thumb()),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      item.title,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _thumb(),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                    child: Row(
                      children: [
                        avatar,
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            item.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

/// Lagu bawaan aplikasi ikut tampil sebagai "video" — bisa diputar tanpa internet.
class _SongCard extends StatelessWidget {
  const _SongCard({required this.index});
  final int index;

  @override
  Widget build(BuildContext context) {
    final s = songs[index];
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SongPlayerScreen(index: index))),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Color(s.color), Color(s.color).withValues(alpha: 0.6)]),
                ),
                alignment: Alignment.center,
                child: Text(s.emoji, style: const TextStyle(fontSize: 90)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
              child: Row(
                children: [
                  const CircleAvatar(backgroundColor: Color(0xFFFFE4F1), child: Text('🎵')),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                        const Text('Lagu Ceria • tanpa internet', style: TextStyle(color: Colors.black54)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
