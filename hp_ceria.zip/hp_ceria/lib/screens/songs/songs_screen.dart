import 'package:flutter/material.dart';

import '../../core/widgets.dart';
import '../../data/songs_data.dart';
import 'song_player_screen.dart';

class SongsScreen extends StatelessWidget {
  const SongsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Lagu',
      color: const Color(0xFFEC407A),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 0.95,
        children: [
          for (var i = 0; i < songs.length; i++)
            BigTile(
              emoji: songs[i].emoji,
              label: songs[i].title,
              color: Color(songs[i].color),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SongPlayerScreen(index: i))),
            ),
        ],
      ),
    );
  }
}
