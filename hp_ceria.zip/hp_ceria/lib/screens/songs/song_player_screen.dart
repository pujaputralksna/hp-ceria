import 'dart:async';
import 'dart:math';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

import '../../core/settings.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/songs_data.dart';

/// Pemutar lagu dengan lirik karaoke dan karakter yang menari.
class SongPlayerScreen extends StatefulWidget {
  const SongPlayerScreen({super.key, required this.index});
  final int index;

  @override
  State<SongPlayerScreen> createState() => _SongPlayerScreenState();
}

class _SongPlayerScreenState extends State<SongPlayerScreen> with SingleTickerProviderStateMixin {
  final _player = AudioPlayer();
  late int _index = widget.index;
  Duration _pos = Duration.zero;
  bool _playing = false;
  bool _repeat = false;
  final _subs = <StreamSubscription<dynamic>>[];
  late final AnimationController _dance = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))
    ..repeat(reverse: true);

  @override
  void initState() {
    super.initState();
    _subs.add(_player.onPositionChanged.listen((p) => setState(() => _pos = p)));
    _subs.add(_player.onPlayerStateChanged.listen((s) => setState(() => _playing = s == PlayerState.playing)));
    _subs.add(_player.onPlayerComplete.listen((_) => _next(auto: true)));
    _play();
  }

  Future<void> _play() async {
    final song = songs[_index];
    await Speaker.instance.say(song.title, pitch: 1.3);
    if (!mounted) return;
    await _player.stop();
    setState(() => _pos = Duration.zero);
    await _player.play(AssetSource(song.asset));
  }

  void _next({bool auto = false}) {
    if (!mounted) return;
    if (!(auto && _repeat)) _index = (_index + 1) % songs.length;
    _play();
  }

  void _prev() {
    _index = (_index - 1 + songs.length) % songs.length;
    _play();
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _player.dispose();
    _dance.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final song = songs[_index];
    final color = Color(song.color);
    final name = AppSettings.instance.childName;
    final ms = _pos.inMilliseconds;
    var current = -1;
    for (var i = 0; i < song.lines.length; i++) {
      if (song.lines[i].ms <= ms + 150) current = i;
    }
    String lyric(int i) => i >= 0 && i < song.lines.length ? song.lines[i].text.replaceAll('{nama}', name) : '';
    const dancers = ['🐱', '🐰', '🐻', '🦄', '🐥', '🐼'];

    return KidScaffold(
      title: song.title,
      color: color,
      body: Column(
        children: [
          const SizedBox(height: 12),
          // Karakter menari
          AnimatedBuilder(
            animation: _dance,
            builder: (_, _) => Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                for (var i = 0; i < 3; i++)
                  Transform.translate(
                    offset: Offset(0, _playing ? -18 * (i.isEven ? _dance.value : 1 - _dance.value) : 0),
                    child: Transform.rotate(
                      angle: _playing ? (i.isEven ? 1 : -1) * (_dance.value - 0.5) * 0.5 : 0,
                      child: Text(dancers[(_index + i) % dancers.length], style: const TextStyle(fontSize: 64)),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: AnimatedScale(
                scale: _playing ? 1.0 + 0.04 * sin(_dance.value * pi) : 1,
                duration: const Duration(milliseconds: 100),
                child: Text(song.emoji, style: const TextStyle(fontSize: 130)),
              ),
            ),
          ),
          // Lirik
          Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
            child: Column(
              children: [
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: Text(
                    current < 0 ? '🎵 🎵 🎵' : lyric(current),
                    key: ValueKey(current),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: color),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  lyric(current + 1),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, color: Colors.black45),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            child: LinearProgressIndicator(
              value: song.durationMs == 0 ? 0 : (ms / (song.durationMs + 1500)).clamp(0, 1),
              minHeight: 10,
              borderRadius: BorderRadius.circular(5),
              color: color,
              backgroundColor: color.withValues(alpha: 0.2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _Ctl(icon: Icons.skip_previous_rounded, color: color, onTap: _prev),
                _Ctl(
                  icon: _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: color,
                  big: true,
                  onTap: () => _playing ? _player.pause() : _player.resume(),
                ),
                _Ctl(icon: Icons.skip_next_rounded, color: color, onTap: _next),
                _Ctl(
                  icon: Icons.repeat_one_rounded,
                  color: _repeat ? color : Colors.grey,
                  onTap: () => setState(() => _repeat = !_repeat),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Ctl extends StatelessWidget {
  const _Ctl({required this.icon, required this.color, required this.onTap, this.big = false});
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final bool big;

  @override
  Widget build(BuildContext context) {
    return Bouncy(
      onTap: onTap,
      child: CircleAvatar(
        radius: big ? 44 : 30,
        backgroundColor: color,
        child: Icon(icon, color: Colors.white, size: big ? 56 : 36),
      ),
    );
  }
}
