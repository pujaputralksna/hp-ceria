import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/animals.dart';
import 'call_screen.dart';

const _green = Color(0xFF4CAF50);

/// Aplikasi "Telepon": daftar kontak hewan + papan angka yang bisa bicara.
class PhoneScreen extends StatelessWidget {
  const PhoneScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFFE8F5E9),
        appBar: AppBar(
          backgroundColor: _green,
          toolbarHeight: 72,
          leadingWidth: 76,
          leading: const KidBackButton(),
          title: const Text('Telepon'),
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            labelStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            tabs: [
              Tab(text: '👫 Kontak'),
              Tab(text: '🔢 Tombol'),
            ],
          ),
        ),
        body: const TabBarView(children: [_Contacts(), _Keypad()]),
      ),
    );
  }
}

void startCall(BuildContext context, AnimalFriend f) {
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => CallScreen(friend: f)));
}

class _Contacts extends StatelessWidget {
  const _Contacts();

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: animalFriends.length,
      separatorBuilder: (_, _) => const SizedBox(height: 12),
      itemBuilder: (_, i) {
        final f = animalFriends[i];
        return Bouncy(
          onTap: () => startCall(context, f),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 36,
                  backgroundColor: f.color.withValues(alpha: 0.3),
                  child: Text(f.emoji, style: const TextStyle(fontSize: 44)),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(f.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                ),
                const CircleAvatar(
                  radius: 30,
                  backgroundColor: _green,
                  child: Icon(Icons.call, color: Colors.white, size: 34),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

const _digitWords = ['nol', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan'];

class _Keypad extends StatefulWidget {
  const _Keypad();

  @override
  State<_Keypad> createState() => _KeypadState();
}

class _KeypadState extends State<_Keypad> {
  String _number = '';

  @override
  Widget build(BuildContext context) {
    Widget key(int d) => Bouncy(
      onTap: () {
        setState(() => _number = _number.length >= 12 ? '$d' : '$_number$d');
        Speaker.instance.say(_digitWords[d]);
      },
      child: Container(
        width: 84,
        height: 84,
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.primaries[d % Colors.primaries.length].shade300,
          shape: BoxShape.circle,
        ),
        alignment: Alignment.center,
        child: Text(
          '$d',
          style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: Colors.white),
        ),
      ),
    );
    return Column(
      children: [
        const SizedBox(height: 16),
        SizedBox(
          height: 56,
          child: FittedBox(
            child: Text(
              _number.isEmpty ? ' ' : _number,
              style: const TextStyle(fontSize: 44, fontWeight: FontWeight.bold, letterSpacing: 4),
            ),
          ),
        ),
        Expanded(
          child: FittedBox(
            child: Column(
              children: [
                for (final row in const [
                  [1, 2, 3],
                  [4, 5, 6],
                  [7, 8, 9],
                ])
                  Row(mainAxisSize: MainAxisSize.min, children: [for (final d in row) key(d)]),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(width: 100),
                    key(0),
                    IconButton(
                      iconSize: 40,
                      onPressed: () =>
                          setState(() => _number = _number.isEmpty ? '' : _number.substring(0, _number.length - 1)),
                      icon: const Icon(Icons.backspace_outlined),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Bouncy(
                  onTap: () {
                    // Nomor apa pun akan tersambung ke teman hewan acak.
                    final f = animalFriends[Random().nextInt(animalFriends.length)];
                    setState(() => _number = '');
                    startCall(context, f);
                  },
                  child: const CircleAvatar(
                    radius: 44,
                    backgroundColor: _green,
                    child: Icon(Icons.call, color: Colors.white, size: 48),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
