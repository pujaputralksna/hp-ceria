import 'package:flutter/material.dart';

import '../../core/call_session.dart';
import '../../core/listener.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/animals.dart';

/// Layar panggilan telepon dengan teman hewan.
class CallScreen extends StatefulWidget {
  const CallScreen({super.key, required this.friend});
  final AnimalFriend friend;

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  late final CallSession _s = CallSession(widget.friend)..addListener(_onChange);

  @override
  void initState() {
    super.initState();
    _s.start();
  }

  void _onChange() {
    if (!mounted) return;
    if (_s.phase == CallPhase.ended) {
      Future<void>.delayed(const Duration(milliseconds: 800), () {
        if (mounted) Navigator.of(context).maybePop();
      });
    }
    setState(() {});
  }

  @override
  void dispose() {
    _s.removeListener(_onChange);
    _s.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final f = widget.friend;
    final status = switch (_s.phase) {
      CallPhase.ringing => 'Berdering...',
      CallPhase.ended => 'Panggilan selesai',
      _ => _s.durationText,
    };
    return PopScope(
      onPopInvokedWithResult: (_, _) => _s.hangUp(),
      child: Scaffold(
        body: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [f.color, Color.lerp(f.color, Colors.black, 0.45)!],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 32),
                Text(
                  f.name,
                  style: const TextStyle(fontSize: 34, color: Colors.white, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 6),
                Text(status, style: const TextStyle(fontSize: 22, color: Colors.white70)),
                const Spacer(),
                Container(
                  width: 230,
                  height: 230,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withValues(alpha: 0.25),
                    border: Border.all(color: Colors.white54, width: 4),
                  ),
                  alignment: Alignment.center,
                  child: _s.phase == CallPhase.ringing
                      ? WigglingEmoji(f.emoji, size: 130)
                      : WigglingEmoji(f.emoji, size: 130, talking: Speaker.instance.speaking),
                ),
                const SizedBox(height: 24),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: _Caption(session: _s),
                ),
                const Spacer(),
                Bouncy(
                  onTap: () {
                    _s.hangUp();
                  },
                  child: const CircleAvatar(
                    radius: 44,
                    backgroundColor: Colors.red,
                    child: Icon(Icons.call_end, color: Colors.white, size: 48),
                  ),
                ),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Caption extends StatelessWidget {
  const _Caption({required this.session});
  final CallSession session;

  @override
  Widget build(BuildContext context) {
    if (session.phase == CallPhase.listening) {
      return Column(
        children: [
          ValueListenableBuilder<double>(
            valueListenable: VoiceListener.instance.level,
            builder: (_, l, _) => AnimatedContainer(
              duration: const Duration(milliseconds: 100),
              width: 70 + 50 * l,
              height: 70 + 50 * l,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: 0.35)),
              child: const Icon(Icons.mic, color: Colors.white, size: 44),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            session.heard.isEmpty ? 'Ayo bicara... 🎤' : '"${session.heard}"',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, color: Colors.white),
          ),
        ],
      );
    }
    if (session.caption.isEmpty) return const SizedBox(height: 60);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Text(
        session.caption,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
      ),
    );
  }
}
