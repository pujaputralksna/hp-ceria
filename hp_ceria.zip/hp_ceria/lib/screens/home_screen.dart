import 'dart:async';

import 'package:flutter/material.dart';

import '../core/settings.dart';
import '../core/speaker.dart';
import '../core/theme.dart';
import '../core/widgets.dart';
import 'camera/camera_home_screen.dart';
import 'camera/gallery_screen.dart';
import 'games/games_home_screen.dart';
import 'learn/learn_home_screen.dart';
import 'messages/chat_list_screen.dart';
import 'parent/parent_gate.dart';
import 'phone/phone_screen.dart';
import 'songs/songs_screen.dart';
import 'video/video_home_screen.dart';

class _AppIcon {
  const _AppIcon(this.label, this.emoji, this.color, this.speech, this.builder);
  final String label;
  final String emoji;
  final Color color;
  final String speech;
  final WidgetBuilder builder;
}

final _apps = <_AppIcon>[
  _AppIcon('Telepon', '📞', const Color(0xFF4CAF50), 'Telepon', (_) => const PhoneScreen()),
  _AppIcon('Pesan', '💬', const Color(0xFF29B6F6), 'Pesan', (_) => const ChatListScreen()),
  _AppIcon('Kamera', '📷', const Color(0xFF9575CD), 'Kamera', (_) => const CameraHomeScreen()),
  _AppIcon('Video', '▶️', AppColors.youtubeRed, 'Video', (_) => const VideoHomeScreen()),
  _AppIcon('Lagu', '🎵', const Color(0xFFEC407A), 'Lagu', (_) => const SongsScreen()),
  _AppIcon('Belajar', '📚', const Color(0xFFFFA726), 'Ayo belajar', (_) => const LearnHomeScreen()),
  _AppIcon('Main', '🎮', const Color(0xFF26A69A), 'Ayo main', (_) => const GamesHomeScreen()),
  _AppIcon('Galeri', '🖼️', const Color(0xFF7E57C2), 'Galeri foto', (_) => const GalleryScreen()),
];

/// Layar beranda yang meniru tampilan HP sungguhan.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Timer _clock;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _clock = Timer.periodic(const Duration(seconds: 10), (_) => setState(() => _now = DateTime.now()));
  }

  @override
  void dispose() {
    _clock.cancel();
    super.dispose();
  }

  String get _greeting {
    final h = _now.hour;
    if (h < 11) return 'Selamat pagi';
    if (h < 15) return 'Selamat siang';
    if (h < 18) return 'Selamat sore';
    return 'Selamat malam';
  }

  @override
  Widget build(BuildContext context) {
    final name = AppSettings.instance.childName;
    final time = '${_now.hour.toString().padLeft(2, '0')}:${_now.minute.toString().padLeft(2, '0')}';
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFC1DD), Color(0xFFD9C6FF), Color(0xFFBDE7FF)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // "Status bar" mainan
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 8, 0),
                child: Row(
                  children: [
                    Text(time, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const Spacer(),
                    const Icon(Icons.signal_cellular_alt, size: 20),
                    const SizedBox(width: 4),
                    const Icon(Icons.battery_full, size: 20),
                    const SizedBox(width: 8),
                    // Pintu orang tua: TEKAN LAMA 3 detik
                    _ParentLockButton(onOpen: () => openParentArea(context)),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                time,
                style: const TextStyle(
                  fontSize: 64,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  shadows: [Shadow(blurRadius: 8, color: Colors.black26)],
                ),
              ),
              GestureDetector(
                onTap: () => Speaker.instance.say('$_greeting, $name!'),
                child: Text(
                  '$_greeting, $name! 👋',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppColors.text),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.count(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  crossAxisCount: 3,
                  mainAxisSpacing: 18,
                  crossAxisSpacing: 18,
                  childAspectRatio: 0.82,
                  children: [for (final a in _apps) _AppButton(app: a)],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AppButton extends StatelessWidget {
  const _AppButton({required this.app});
  final _AppIcon app;

  @override
  Widget build(BuildContext context) {
    return Bouncy(
      onTap: () {
        Speaker.instance.say(app.speech);
        Navigator.of(context).push(MaterialPageRoute(builder: app.builder));
      },
      child: Column(
        children: [
          Expanded(
            child: AspectRatio(
              aspectRatio: 1,
              child: Container(
                decoration: BoxDecoration(
                  color: app.color,
                  borderRadius: BorderRadius.circular(26),
                  boxShadow: [
                    BoxShadow(color: app.color.withValues(alpha: 0.5), blurRadius: 10, offset: const Offset(0, 5)),
                  ],
                ),
                alignment: Alignment.center,
                child: FittedBox(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(app.emoji, style: const TextStyle(fontSize: 56)),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(app.label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

/// Tombol gembok kecil. Harus ditekan lama 3 detik agar tidak sengaja dibuka anak.
class _ParentLockButton extends StatefulWidget {
  const _ParentLockButton({required this.onOpen});
  final VoidCallback onOpen;

  @override
  State<_ParentLockButton> createState() => _ParentLockButtonState();
}

class _ParentLockButtonState extends State<_ParentLockButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 3))
    ..addStatusListener((s) {
      if (s == AnimationStatus.completed) {
        _c.reset();
        widget.onOpen();
      }
    });

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _c.forward(from: 0),
      onTapUp: (_) => _c.reset(),
      onTapCancel: () => _c.reset(),
      child: SizedBox(
        width: 40,
        height: 40,
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, _) => Stack(
            alignment: Alignment.center,
            children: [
              CircularProgressIndicator(value: _c.value, strokeWidth: 3, color: Colors.white),
              const Icon(Icons.lock_outline, size: 20, color: Colors.black45),
            ],
          ),
        ),
      ),
    );
  }
}
