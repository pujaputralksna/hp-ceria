import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/listener.dart';
import '../../core/settings.dart';
import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/animals.dart';
import 'chat_list_screen.dart';

class ChatMessage {
  ChatMessage(this.text, {required this.fromMe});
  final String text;
  final bool fromMe;
}

/// Riwayat pesan disimpan di memori selama aplikasi terbuka.
class ChatStore {
  static final _data = <String, List<ChatMessage>>{};
  static List<ChatMessage> of(String id) => _data.putIfAbsent(id, () => []);
}

/// Stiker yang bisa dikirim balita dengan satu sentuhan.
const _stickers = <(String, String)>[
  ('👋', 'Halo!'),
  ('💖', 'Aku sayang kamu 💖'),
  ('😊', 'Aku senang hari ini 😊'),
  ('🍎', 'Aku sudah makan 🍎'),
  ('🎵', 'Ayo nyanyi 🎵'),
  ('⚽', 'Ayo main ⚽'),
  ('😴', 'Aku mengantuk 😴'),
  ('🙋‍♀️', 'Dadah!'),
];

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.friend});
  final AnimalFriend friend;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final FriendBrain _brain = FriendBrain(widget.friend);
  late final List<ChatMessage> _msgs = ChatStore.of(widget.friend.id);
  final _scroll = ScrollController();
  bool _typing = false;
  bool _listening = false;

  String get _name => AppSettings.instance.childName;

  @override
  void initState() {
    super.initState();
    if (_msgs.isEmpty) {
      _botSay(_brain.fill(widget.friend.intro, _name), delayMs: 600);
    }
  }

  @override
  void dispose() {
    Speaker.instance.stop();
    VoiceListener.instance.stop();
    super.dispose();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent + 120,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _botSay(String text, {int delayMs = 1200}) async {
    setState(() => _typing = true);
    _scrollDown();
    await Future<void>.delayed(Duration(milliseconds: delayMs + Random().nextInt(600)));
    if (!mounted) return;
    setState(() {
      _typing = false;
      _msgs.add(ChatMessage(text, fromMe: false));
    });
    _scrollDown();
    await Sfx.play('pesan');
    await Speaker.instance.say(text, pitch: widget.friend.pitch);
  }

  Future<void> _send(String text) async {
    if (_typing) return;
    setState(() => _msgs.add(ChatMessage(text, fromMe: true)));
    _scrollDown();
    var reply = _brain.reply(text, _name);
    if (Random().nextBool()) reply = '$reply ${_brain.nextQuestion()}';
    await _botSay(reply);
  }

  Future<void> _voice() async {
    if (_listening || _typing) return;
    await Speaker.instance.stop();
    setState(() => _listening = true);
    final t = await VoiceListener.instance.listen(maxSeconds: 6);
    if (!mounted) return;
    setState(() => _listening = false);
    await _send(t.isEmpty ? '🎤 (pesan suara)' : '🎤 $t');
  }

  @override
  Widget build(BuildContext context) {
    final f = widget.friend;
    return KidScaffold(
      title: f.name,
      color: chatBlue,
      background: const Color(0xFFE3F2FD),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Text(f.emoji, style: const TextStyle(fontSize: 40)),
        ),
      ],
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.all(12),
              itemCount: _msgs.length + (_typing ? 1 : 0),
              itemBuilder: (_, i) {
                if (i == _msgs.length) return _Bubble(text: '• • •', fromMe: false, emoji: f.emoji);
                final m = _msgs[i];
                return GestureDetector(
                  onTap: () => Speaker.instance.say(m.text, pitch: m.fromMe ? 1.25 : f.pitch),
                  child: _Bubble(text: m.text, fromMe: m.fromMe, emoji: f.emoji),
                );
              },
            ),
          ),
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
            child: Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 64,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        for (final (emoji, text) in _stickers)
                          Bouncy(
                            onTap: () => _send(text),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 6),
                              child: Text(emoji, style: const TextStyle(fontSize: 46)),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                Bouncy(
                  onTap: _voice,
                  child: CircleAvatar(
                    radius: 32,
                    backgroundColor: _listening ? Colors.red : chatBlue,
                    child: Icon(_listening ? Icons.hearing : Icons.mic, color: Colors.white, size: 36),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.text, required this.fromMe, required this.emoji});
  final String text;
  final bool fromMe;
  final String emoji;

  @override
  Widget build(BuildContext context) {
    final bubble = Flexible(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: fromMe ? const Color(0xFFFF8CC6) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(22),
            topRight: const Radius.circular(22),
            bottomLeft: Radius.circular(fromMe ? 22 : 4),
            bottomRight: Radius.circular(fromMe ? 4 : 22),
          ),
        ),
        child: Text(
          text,
          style: TextStyle(fontSize: 21, color: fromMe ? Colors.white : Colors.black87, fontWeight: FontWeight.w600),
        ),
      ),
    );
    return Row(
      mainAxisAlignment: fromMe ? MainAxisAlignment.end : MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        if (!fromMe)
          Padding(
            padding: const EdgeInsets.only(right: 6, bottom: 6),
            child: Text(emoji, style: const TextStyle(fontSize: 30)),
          ),
        bubble,
        if (fromMe) const SizedBox(width: 8),
      ],
    );
  }
}
