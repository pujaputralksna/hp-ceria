import 'package:flutter/material.dart';

import '../../core/widgets.dart';
import '../../data/animals.dart';
import 'chat_screen.dart';

const chatBlue = Color(0xFF29B6F6);

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key});

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Pesan',
      color: chatBlue,
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: animalFriends.length,
        separatorBuilder: (_, _) => const SizedBox(height: 10),
        itemBuilder: (_, i) {
          final f = animalFriends[i];
          final history = ChatStore.of(f.id);
          final last = history.isEmpty ? f.status : history.last.text;
          final unread = history.isEmpty;
          return Bouncy(
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(friend: f)));
              setState(() {});
            },
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 32,
                    backgroundColor: f.color.withValues(alpha: 0.3),
                    child: Text(f.emoji, style: const TextStyle(fontSize: 38)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(f.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                        Text(last, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
                      ],
                    ),
                  ),
                  if (unread)
                    const CircleAvatar(
                      radius: 14,
                      backgroundColor: Colors.red,
                      child: Text(
                        '1',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
