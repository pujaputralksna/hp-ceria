import 'package:flutter/material.dart';

import '../../core/settings.dart';
import '../../core/theme.dart';
import '../../main.dart';
import 'pin_pad.dart';

/// Ditampilkan sekali saat aplikasi pertama kali dibuka: nama anak + PIN orang tua.
class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _name = TextEditingController();
  int _step = 0;
  String? _firstPin;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lavender,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: switch (_step) {
              0 => Column(
                children: [
                  const Text('🎀📱', style: TextStyle(fontSize: 72)),
                  const Text(
                    'Selamat datang di HP Ceria',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text('Pengaturan awal untuk Ayah / Bunda.', textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  TextField(
                    controller: _name,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      labelText: 'Nama panggilan anak',
                      hintText: 'contoh: Aisyah',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () async {
                      await AppSettings.instance.setChildName(_name.text);
                      setState(() => _step = 1);
                    },
                    child: const Text('Lanjut'),
                  ),
                ],
              ),
              1 => PinPad(
                title: 'Buat PIN Orang Tua (4 angka)',
                subtitle: 'PIN ini dipakai untuk keluar dari Mode Anak.\nJangan beri tahu si kecil ya!',
                onComplete: (pin) async {
                  setState(() {
                    _firstPin = pin;
                    _step = 2;
                  });
                  return true;
                },
              ),
              _ => PinPad(
                title: 'Ulangi PIN',
                onComplete: (pin) async {
                  if (pin != _firstPin) {
                    setState(() => _step = 1);
                    return false;
                  }
                  await AppSettings.instance.setParentPin(pin);
                  if (!context.mounted) return true;
                  await showDialog<void>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Mode Anak akan aktif'),
                      content: const Text(
                        'Setelah ini layar akan dikunci (disematkan) agar si kecil tidak bisa keluar.\n\n'
                        'Bila Android bertanya "Sematkan aplikasi?", pilih YA / MENGERTI.\n\n'
                        'Untuk masuk ke Pengaturan Orang Tua: tekan lama ikon gembok 🔒 di pojok kanan atas '
                        'selama 3 detik, lalu masukkan PIN.',
                      ),
                      actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Mengerti'))],
                    ),
                  );
                  if (context.mounted) {
                    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const KidsShell()));
                  }
                  return true;
                },
              ),
            },
          ),
        ),
      ),
    );
  }
}
