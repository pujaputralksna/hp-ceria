import 'package:flutter/material.dart';

import '../../core/theme.dart';

/// Papan angka PIN 4 digit.
class PinPad extends StatefulWidget {
  const PinPad({super.key, required this.title, required this.onComplete, this.subtitle});

  final String title;
  final String? subtitle;

  /// Kembalikan false bila PIN salah (tampilan akan bergetar & dikosongkan).
  final Future<bool> Function(String pin) onComplete;

  @override
  State<PinPad> createState() => _PinPadState();
}

class _PinPadState extends State<PinPad> {
  String _pin = '';
  bool _error = false;

  Future<void> _press(String d) async {
    if (_pin.length >= 4) return;
    setState(() {
      _pin += d;
      _error = false;
    });
    if (_pin.length == 4) {
      final ok = await widget.onComplete(_pin);
      if (!mounted) return;
      setState(() {
        _error = !ok;
        _pin = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget key(String label, {VoidCallback? onTap, IconData? icon}) => Padding(
      padding: const EdgeInsets.all(6),
      child: SizedBox(
        width: 76,
        height: 76,
        child: FilledButton.tonal(
          style: FilledButton.styleFrom(shape: const CircleBorder()),
          onPressed: onTap ?? () => _press(label),
          child: icon != null ? Icon(icon, size: 28) : Text(label, style: const TextStyle(fontSize: 28)),
        ),
      ),
    );
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          widget.title,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        if (widget.subtitle != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              widget.subtitle!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
          ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < 4; i++)
              Container(
                margin: const EdgeInsets.all(8),
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _pin.length ? AppColors.purple : Colors.transparent,
                  border: Border.all(color: _error ? Colors.red : AppColors.purple, width: 2),
                ),
              ),
          ],
        ),
        if (_error) const Text('PIN salah', style: TextStyle(color: Colors.red)),
        const SizedBox(height: 12),
        for (final row in const [
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
        ])
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (final d in row) key(d)]),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(width: 88),
            key('0'),
            key(
              '',
              icon: Icons.backspace_outlined,
              onTap: () {
                if (_pin.isNotEmpty) setState(() => _pin = _pin.substring(0, _pin.length - 1));
              },
            ),
          ],
        ),
      ],
    );
  }
}
