import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../core/kiosk.dart';
import '../../core/settings.dart';
import '../../main.dart';
import 'pin_pad.dart';
import 'video_manager_screen.dart';

/// Pengaturan khusus orang tua (dibuka dengan PIN).
class ParentScreen extends StatefulWidget {
  const ParentScreen({super.key});

  @override
  State<ParentScreen> createState() => _ParentScreenState();
}

class _ParentScreenState extends State<ParentScreen> {
  final s = AppSettings.instance;
  bool _deviceOwner = false;

  @override
  void initState() {
    super.initState();
    Kiosk.isDeviceOwner().then((v) => setState(() => _deviceOwner = v));
  }

  Future<void> _editName() async {
    final c = TextEditingController(text: s.childName);
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nama panggilan anak'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Simpan')),
        ],
      ),
    );
    if (v != null) {
      await s.setChildName(v);
      setState(() {});
    }
  }

  Future<void> _changePin() async {
    String? first;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: StatefulBuilder(
            builder: (ctx, setSheet) => PinPad(
              key: ValueKey(first),
              title: first == null ? 'PIN baru' : 'Ulangi PIN baru',
              onComplete: (pin) async {
                if (first == null) {
                  setSheet(() => first = pin);
                  return true;
                }
                if (pin != first) return false;
                await s.setParentPin(pin);
                if (ctx.mounted) Navigator.pop(ctx);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN berhasil diganti')));
                }
                return true;
              },
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _exitKidsMode() async {
    await s.setKidsModeEnabled(false);
    await Kiosk.stop();
    if (kIsWeb) {
      // Tab browser tidak bisa ditutup oleh aplikasi; tampilkan layar "Mode Anak berhenti".
      webKidsActive.value = false;
      if (mounted) {
        Navigator.of(context)
            .pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const _WebStoppedScreen()), (_) => false);
      }
      return;
    }
    await Kiosk.exitApp();
  }

  Future<void> _removeOwner() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Matikan Mode Kiosk Penuh?'),
        content: const Text(
          'Status "Device Owner" akan dilepas. Setelah ini HP Ceria kembali memakai mode Sematkan Layar biasa '
          'dan bisa di-uninstall seperti aplikasi lain. Untuk mengaktifkan lagi, ulangi perintah ADB di panduan.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Matikan')),
        ],
      ),
    );
    if (ok == true) {
      await Kiosk.removeDeviceOwner();
      final v = await Kiosk.isDeviceOwner();
      setState(() => _deviceOwner = v);
    }
  }

  @override
  Widget build(BuildContext context) {
    final used = s.usedSecondsToday ~/ 60;
    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan Orang Tua'), backgroundColor: const Color(0xFF6A5ACD)),
      body: ListView(
        children: [
          if (kIsWeb)
            const ListTile(
              leading: Icon(Icons.web, color: Colors.deepPurple),
              title: Text('Mode Browser (layar penuh)'),
              subtitle: Text(
                'Browser tidak bisa dikunci penuh. Untuk hasil terbaik jalankan Chrome dalam mode kiosk '
                '(lihat PANDUAN_WEB.md).',
              ),
            )
          else
            ListTile(
              leading: Icon(_deviceOwner ? Icons.verified_user : Icons.push_pin, color: Colors.deepPurple),
              title: Text(_deviceOwner ? 'Mode Kiosk Penuh aktif' : 'Mode Sematkan Layar aktif'),
              subtitle: Text(
                _deviceOwner
                    ? 'Tombol Home, Recent, dan notifikasi dikunci penuh.'
                    : 'Untuk penguncian lebih kuat, ikuti langkah "Mode Kiosk Penuh" di panduan.',
              ),
            ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.child_care),
            title: const Text('Nama anak'),
            subtitle: Text(s.childName),
            onTap: _editName,
          ),
          ListTile(leading: const Icon(Icons.pin), title: const Text('Ganti PIN orang tua'), onTap: _changePin),
          ListTile(
            leading: const Icon(Icons.timer_outlined),
            title: const Text('Batas waktu main per hari'),
            subtitle: Text('Terpakai hari ini: $used menit'),
            trailing: DropdownButton<int>(
              value: s.dailyLimitMinutes,
              items: const [
                0,
                15,
                30,
                45,
                60,
                90,
                120,
              ].map((m) => DropdownMenuItem(value: m, child: Text(m == 0 ? 'Tanpa batas' : '$m menit'))).toList(),
              onChanged: (v) async {
                await s.setDailyLimitMinutes(v ?? 0);
                setState(() {});
              },
            ),
          ),
          ListTile(
            leading: const Icon(Icons.restart_alt),
            title: const Text('Reset waktu main hari ini'),
            onTap: () async {
              await s.resetUsageToday();
              setState(() {});
            },
          ),
          ListTile(
            leading: const Icon(Icons.video_library_outlined),
            title: const Text('Kelola daftar video'),
            subtitle: Text('${s.videos.length} video'),
            onTap: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const VideoManagerScreen()));
              setState(() {});
            },
          ),
          if (!kIsWeb)
            ListTile(
              leading: const Icon(Icons.security),
              title: const Text('Buka pengaturan Keamanan Android'),
              subtitle: const Text('Aktifkan "Sematkan aplikasi" & "Minta PIN sebelum melepas sematan".'),
              onTap: Kiosk.openSecuritySettings,
            ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('Keluar dari Mode Anak', style: TextStyle(color: Colors.red)),
            subtitle: Text(
              kIsWeb
                  ? 'Keluar dari layar penuh. Tab bisa ditutup dengan aman.'
                  : 'HP kembali normal. Buka HP Ceria lagi untuk mengaktifkan Mode Anak.',
            ),
            onTap: _exitKidsMode,
          ),
          if (_deviceOwner)
            ListTile(
              leading: const Icon(Icons.no_encryption_gmailerrorred, color: Colors.orange),
              title: const Text('Matikan Mode Kiosk Penuh (lepas Device Owner)'),
              subtitle: const Text('Lakukan ini sebelum meng-uninstall aplikasi.'),
              onTap: _removeOwner,
            ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _WebStoppedScreen extends StatelessWidget {
  const _WebStoppedScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDE4FF),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('👋', style: TextStyle(fontSize: 80)),
            const Text('Mode Anak dihentikan', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Tab ini sekarang boleh ditutup.'),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: () =>
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const KidsShell())),
              icon: const Icon(Icons.play_arrow),
              label: const Text('Mulai Mode Anak lagi'),
            ),
          ],
        ),
      ),
    );
  }
}
