import 'package:flutter/material.dart';

import '../../core/settings.dart';
import 'parent_screen.dart';
import 'pin_pad.dart';

int _wrongAttempts = 0;
DateTime? _lockedUntil;

/// Meminta PIN orang tua. Mengembalikan true bila benar.
Future<bool> askParentPin(BuildContext context, {String title = 'Masukkan PIN Orang Tua'}) async {
  if (_lockedUntil != null && DateTime.now().isBefore(_lockedUntil!)) {
    final s = _lockedUntil!.difference(DateTime.now()).inSeconds;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Terlalu banyak salah. Coba lagi $s detik.')));
    return false;
  }
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 24),
        child: PinPad(
          title: title,
          subtitle: 'Khusus Ayah / Bunda',
          onComplete: (pin) async {
            if (pin == AppSettings.instance.parentPin) {
              _wrongAttempts = 0;
              Navigator.of(ctx).pop(true);
              return true;
            }
            _wrongAttempts++;
            if (_wrongAttempts >= 5) {
              _wrongAttempts = 0;
              _lockedUntil = DateTime.now().add(const Duration(seconds: 60));
              Navigator.of(ctx).pop(false);
            }
            return false;
          },
        ),
      ),
    ),
  );
  return ok ?? false;
}

Future<void> openParentArea(BuildContext context) async {
  if (await askParentPin(context) && context.mounted) {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ParentScreen()));
  }
}
