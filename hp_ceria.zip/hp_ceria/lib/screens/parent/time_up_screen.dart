import 'package:flutter/material.dart';

import '../../core/settings.dart';
import 'parent_gate.dart';

/// Muncul ketika batas waktu main harian habis. Hanya orang tua yang bisa menutupnya.
class TimeUpScreen extends StatelessWidget {
  const TimeUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFF2E2A5C),
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('🌙😴', style: TextStyle(fontSize: 100)),
                Text(
                  'Waktunya istirahat, ${AppSettings.instance.childName}!',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text('Main lagi nanti ya 💖', style: TextStyle(fontSize: 20, color: Colors.white70)),
                const SizedBox(height: 40),
                TextButton.icon(
                  onPressed: () async {
                    if (await askParentPin(context, title: 'PIN untuk menambah waktu') && context.mounted) {
                      await AppSettings.instance.resetUsageToday();
                      if (context.mounted) Navigator.of(context).pop();
                    }
                  },
                  icon: const Icon(Icons.lock_outline, color: Colors.white38),
                  label: const Text('Orang tua', style: TextStyle(color: Colors.white38)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
