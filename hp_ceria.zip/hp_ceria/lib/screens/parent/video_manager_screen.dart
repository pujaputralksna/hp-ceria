import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../core/settings.dart';
import '../../main.dart';

/// Orang tua menambah / menghapus video yang boleh ditonton anak.
class VideoManagerScreen extends StatefulWidget {
  const VideoManagerScreen({super.key});

  @override
  State<VideoManagerScreen> createState() => _VideoManagerScreenState();
}

class _VideoManagerScreenState extends State<VideoManagerScreen> {
  final s = AppSettings.instance;
  late List<VideoItem> _videos = s.videos;

  Future<void> _save() async {
    await s.saveVideos(_videos);
    setState(() => _videos = s.videos);
  }

  Future<void> _addYoutube() async {
    final link = TextEditingController();
    final title = TextEditingController();
    var category = AppSettings.videoCategories.first;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Tambah video YouTube'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Buka YouTube → pilih video → Bagikan → Salin link, lalu tempel di sini.',
                  style: TextStyle(fontSize: 13, color: Colors.black54),
                ),
                TextField(
                  controller: link,
                  decoration: const InputDecoration(labelText: 'Link YouTube'),
                ),
                TextField(
                  controller: title,
                  decoration: const InputDecoration(labelText: 'Judul (bebas)'),
                ),
                const SizedBox(height: 8),
                DropdownButton<String>(
                  isExpanded: true,
                  value: category,
                  items: AppSettings.videoCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: (v) => setD(() => category = v!),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Tambah')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final id = parseYoutubeId(link.text);
    if (id == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link YouTube tidak dikenali')));
      }
      return;
    }
    _videos.add(
      VideoItem(
        title: title.text.trim().isEmpty ? 'Video ${_videos.length + 1}' : title.text.trim(),
        source: id,
        isYoutube: true,
        category: category,
      ),
    );
    await _save();
  }

  Future<void> _addLocal() async {
    // Pemilih file adalah aplikasi lain, jadi kunci Mode Anak dilepas sebentar.
    final files = await KidsLockPause.run(() => FilePicker.pickFiles(type: FileType.video));
    if (files.isEmpty) return;
    for (final f in files) {
      if (f.path == null) continue;
      _videos.add(
        VideoItem(
          title: f.name.replaceAll(RegExp(r'\.[^.]+$'), ''),
          source: f.path!,
          isYoutube: false,
          category: 'Kartun',
        ),
      );
    }
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kelola Video'), backgroundColor: const Color(0xFF6A5ACD)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet<void>(
          context: context,
          builder: (ctx) => SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.smart_display, color: Colors.red),
                  title: const Text('Dari link YouTube'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _addYoutube();
                  },
                ),
                if (!kIsWeb)
                  ListTile(
                    leading: const Icon(Icons.folder_open),
                    title: const Text('Dari file video di HP (bisa ditonton offline)'),
                    onTap: () {
                      Navigator.pop(ctx);
                      _addLocal();
                    },
                  ),
                const ListTile(
                  leading: Icon(Icons.lightbulb_outline),
                  title: Text('Ide pencarian di YouTube'),
                  subtitle: Text(
                    '"lagu anak indonesia balita", "Cocomelon Bahasa Indonesia", "Super Simple Songs", '
                    '"Pinkfong Bahasa Indonesia", "Little Baby Bum", "dongeng anak". Tonton dulu sebelum ditambahkan.',
                  ),
                ),
              ],
            ),
          ),
        ),
        icon: const Icon(Icons.add),
        label: const Text('Tambah video'),
      ),
      body: _videos.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Belum ada video.\nTekan "Tambah video" untuk memasukkan link YouTube atau file video.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ReorderableListView.builder(
              padding: const EdgeInsets.only(bottom: 96),
              itemCount: _videos.length,
              onReorderItem: (a, b) async {
                _videos.insert(b, _videos.removeAt(a));
                await _save();
              },
              itemBuilder: (_, i) {
                final v = _videos[i];
                return ListTile(
                  key: ValueKey('${v.source}$i'),
                  leading: v.thumbnailUrl != null
                      ? Image.network(
                          v.thumbnailUrl!,
                          width: 80,
                          fit: BoxFit.cover,
                          webHtmlElementStrategy: WebHtmlElementStrategy.fallback,
                          errorBuilder: (_, _, _) => const Icon(Icons.smart_display),
                        )
                      : const Icon(Icons.movie, size: 40),
                  title: Text(v.title),
                  subtitle: Text('${v.category} • ${v.isYoutube ? 'YouTube' : 'File di HP'}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      _videos.removeAt(i);
                      await _save();
                    },
                  ),
                );
              },
            ),
    );
  }
}
