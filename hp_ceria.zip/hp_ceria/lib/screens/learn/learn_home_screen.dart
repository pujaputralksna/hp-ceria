import 'package:flutter/material.dart';

import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/learning_data.dart';
import 'flashcard_screen.dart';

class LearnHomeScreen extends StatelessWidget {
  const LearnHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Belajar',
      color: const Color(0xFFFFA726),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 1.05,
        children: [
          for (final c in learnCategories)
            BigTile(
              emoji: c.emoji,
              label: c.title,
              color: c.color,
              onTap: () {
                Speaker.instance.say(c.title);
                Navigator.push(context, MaterialPageRoute(builder: (_) => FlashcardScreen(category: c)));
              },
            ),
        ],
      ),
    );
  }
}
