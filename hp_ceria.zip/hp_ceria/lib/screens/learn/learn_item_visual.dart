import 'dart:math';

import 'package:flutter/material.dart';

import '../../data/learning_data.dart';

/// Gambar untuk satu kartu belajar (emoji / warna / bentuk / angka).
class LearnItemVisual extends StatelessWidget {
  const LearnItemVisual({super.key, required this.item, this.size = 200, this.showLabelInside = true});
  final LearnItem item;
  final double size;
  final bool showLabelInside;

  @override
  Widget build(BuildContext context) {
    if (item.shape != null) {
      return SizedBox(
        width: size,
        height: size,
        child: CustomPaint(painter: ShapePainter(item.shape!, Colors.primaries[item.shape!.index * 2 % 18])),
      );
    }
    if (item.swatch != null) {
      return Stack(
        alignment: Alignment.bottomRight,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: item.swatch,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.black12, width: 4),
            ),
          ),
          if (item.emoji != null) Text(item.emoji!, style: TextStyle(fontSize: size * 0.35)),
        ],
      );
    }
    if (item.count != null) {
      return SizedBox(
        width: size * 1.3,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showLabelInside)
              Text(
                item.name,
                style: TextStyle(fontSize: size * 0.45, fontWeight: FontWeight.w900, color: Colors.deepOrange),
              ),
            Wrap(
              alignment: WrapAlignment.center,
              children: [
                for (var i = 0; i < item.count!; i++)
                  Text(item.emoji!, style: TextStyle(fontSize: size * (item.count! > 5 ? 0.18 : 0.24))),
              ],
            ),
          ],
        ),
      );
    }
    final isLetter = item.name.length == 1 && RegExp('[A-Z]').hasMatch(item.name);
    if (isLetter && !showLabelInside) {
      return Text(
        item.name,
        style: TextStyle(fontSize: size * 0.8, fontWeight: FontWeight.w900, color: Colors.teal),
      );
    }
    if (isLetter) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '${item.name}${item.name.toLowerCase()}',
            style: TextStyle(fontSize: size * 0.5, fontWeight: FontWeight.w900, color: Colors.teal),
          ),
          Text(item.emoji ?? '', style: TextStyle(fontSize: size * 0.4)),
        ],
      );
    }
    return Text(item.emoji ?? '❓', style: TextStyle(fontSize: size * 0.75));
  }
}

class ShapePainter extends CustomPainter {
  ShapePainter(this.kind, this.color);
  final ShapeKind kind;
  final Color color;

  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..color = color;
    final c = s.center(Offset.zero);
    final r = s.shortestSide / 2 * 0.9;
    final path = Path();
    switch (kind) {
      case ShapeKind.lingkaran:
        path.addOval(Rect.fromCircle(center: c, radius: r));
      case ShapeKind.oval:
        path.addOval(Rect.fromCenter(center: c, width: r * 1.4, height: r * 2));
      case ShapeKind.persegi:
        path.addRRect(RRect.fromRectAndRadius(Rect.fromCircle(center: c, radius: r * 0.85), const Radius.circular(8)));
      case ShapeKind.persegiPanjang:
        path.addRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: c, width: r * 1.2, height: r * 1.9),
            const Radius.circular(8),
          ),
        );
      case ShapeKind.segitiga:
        path
          ..moveTo(c.dx, c.dy - r)
          ..lineTo(c.dx + r, c.dy + r * 0.8)
          ..lineTo(c.dx - r, c.dy + r * 0.8)
          ..close();
      case ShapeKind.belahKetupat:
        path
          ..moveTo(c.dx, c.dy - r)
          ..lineTo(c.dx + r * 0.7, c.dy)
          ..lineTo(c.dx, c.dy + r)
          ..lineTo(c.dx - r * 0.7, c.dy)
          ..close();
      case ShapeKind.bintang:
        for (var i = 0; i < 10; i++) {
          final rad = i.isEven ? r : r * 0.45;
          final a = -pi / 2 + i * pi / 5;
          final pt = c + Offset(cos(a) * rad, sin(a) * rad);
          i == 0 ? path.moveTo(pt.dx, pt.dy) : path.lineTo(pt.dx, pt.dy);
        }
        path.close();
      case ShapeKind.hati:
        path
          ..moveTo(c.dx, c.dy + r * 0.85)
          ..cubicTo(c.dx - r * 1.4, c.dy - r * 0.1, c.dx - r * 0.6, c.dy - r * 1.1, c.dx, c.dy - r * 0.45)
          ..cubicTo(c.dx + r * 0.6, c.dy - r * 1.1, c.dx + r * 1.4, c.dy - r * 0.1, c.dx, c.dy + r * 0.85)
          ..close();
    }
    canvas.drawShadow(path, Colors.black, 6, false);
    canvas.drawPath(path, p);
  }

  @override
  bool shouldRepaint(ShapePainter old) => old.kind != kind || old.color != color;
}
