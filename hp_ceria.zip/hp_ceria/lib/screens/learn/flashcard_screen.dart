import 'package:flutter/material.dart';

import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/learning_data.dart';
import 'learn_item_visual.dart';
import 'quiz_screen.dart';

/// Kartu belajar yang bisa digeser. Sentuh kartu untuk mendengar suaranya.
class FlashcardScreen extends StatefulWidget {
  const FlashcardScreen({super.key, required this.category});
  final LearnCategory category;

  @override
  State<FlashcardScreen> createState() => _FlashcardScreenState();
}

class _FlashcardScreenState extends State<FlashcardScreen> {
  final _page = PageController(viewportFraction: 0.88);
  int _i = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _speak());
  }

  @override
  void dispose() {
    _page.dispose();
    Speaker.instance.stop();
    super.dispose();
  }

  void _speak() => Speaker.instance.say(widget.category.items[_i].speech);

  void _go(int d) {
    final n = (_i + d).clamp(0, widget.category.items.length - 1);
    _page.animateToPage(n, duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.category;
    return KidScaffold(
      title: c.title,
      color: c.color,
      actions: [
        if (c.items.length >= 3)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: c.color),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizScreen(category: c))),
              icon: const Text('🎯', style: TextStyle(fontSize: 22)),
              label: const Text('Tebak', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            ),
          ),
      ],
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _page,
              itemCount: c.items.length,
              onPageChanged: (i) {
                setState(() => _i = i);
                _speak();
              },
              itemBuilder: (_, i) {
                final item = c.items[i];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 20),
                  child: Bouncy(
                    onTap: () => Speaker.instance.say(item.speech),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(36),
                        border: Border.all(color: c.color, width: 6),
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: FittedBox(child: LearnItemVisual(item: item)),
                          ),
                          const SizedBox(height: 12),
                          FittedBox(
                            child: Text(
                              item.name,
                              style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: c.color),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 24, left: 24, right: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _Arrow(icon: Icons.arrow_back_rounded, color: c.color, enabled: _i > 0, onTap: () => _go(-1)),
                Text(
                  '${_i + 1} / ${c.items.length}',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                _Arrow(
                  icon: Icons.arrow_forward_rounded,
                  color: c.color,
                  enabled: _i < c.items.length - 1,
                  onTap: () => _go(1),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Arrow extends StatelessWidget {
  const _Arrow({required this.icon, required this.color, required this.enabled, required this.onTap});
  final IconData icon;
  final Color color;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.3,
      child: Bouncy(
        onTap: enabled ? onTap : () {},
        child: CircleAvatar(
          radius: 36,
          backgroundColor: color,
          child: Icon(icon, color: Colors.white, size: 44),
        ),
      ),
    );
  }
}
