import 'dart:math';

import 'package:flutter/material.dart';

import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/learning_data.dart';
import 'learn_item_visual.dart';

/// Kuis sederhana: "Mana kucing?" — pilih satu dari tiga gambar.
class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, required this.category});
  final LearnCategory category;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final _rand = Random();
  late List<LearnItem> _options;
  late LearnItem _answer;
  int _stars = 0;
  LearnItem? _wrong;
  bool _celebrate = false;

  @override
  void initState() {
    super.initState();
    _newRound();
  }

  void _newRound() {
    final items = widget.category.items.where((i) => i.inQuiz).toList()..shuffle(_rand);
    _options = items.take(3).toList();
    _answer = _options[_rand.nextInt(_options.length)];
    _wrong = null;
    _celebrate = false;
    setState(() {});
    _ask();
  }

  void _ask() => Speaker.instance.say('Mana ${_answer.name.toLowerCase()}?');

  Future<void> _pick(LearnItem item) async {
    if (_celebrate) return;
    if (item == _answer) {
      setState(() {
        _celebrate = true;
        _stars++;
      });
      await Sfx.play('benar');
      await Speaker.instance.say(['Pintar!', 'Hebat!', 'Betul sekali!', 'Wah, kamu pintar!'][_rand.nextInt(4)]);
      await Future<void>.delayed(const Duration(milliseconds: 600));
      if (mounted) _newRound();
    } else {
      setState(() => _wrong = item);
      await Sfx.play('coba');
      await Speaker.instance.say('Itu ${item.name.toLowerCase()}. Coba lagi ya!');
      _ask();
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.category;
    return KidScaffold(
      title: 'Tebak ${c.title}',
      color: c.color,
      body: Column(
        children: [
          const SizedBox(height: 12),
          Text('⭐' * min(_stars, 10), style: const TextStyle(fontSize: 28)),
          Bouncy(
            onTap: _ask,
            child: Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(color: c.color, borderRadius: BorderRadius.circular(30)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.volume_up_rounded, color: Colors.white, size: 36),
                  const SizedBox(width: 8),
                  Flexible(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        'Mana ${_answer.name}?',
                        style: const TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: Column(
              children: [
                for (final o in _options)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 8),
                      child: Bouncy(
                        onTap: () => _pick(o),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          decoration: BoxDecoration(
                            color: _celebrate && o == _answer
                                ? Colors.lightGreenAccent
                                : (o == _wrong ? Colors.red.shade100 : Colors.white),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: c.color, width: 4),
                          ),
                          alignment: Alignment.center,
                          padding: const EdgeInsets.all(8),
                          child: FittedBox(child: LearnItemVisual(item: o, size: 150, showLabelInside: false)),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (_celebrate) const Text('🎉🎉🎉', style: TextStyle(fontSize: 40)),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
