import 'dart:math';

import 'package:flutter/material.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

/// Posisi wajah yang sudah diubah ke koordinat layar / foto.
class FaceGeom {
  FaceGeom(this.box, this.nose);
  final Rect box;
  final Offset nose;

  double get w => box.width;
  double get h => box.height;
  Offset get center => box.center;
}

typedef FilterPainterFn = void Function(Canvas c, FaceGeom g);

class FaceFilter {
  const FaceFilter(this.id, this.name, this.icon, this.paint);
  final String id;
  final String name;
  final String icon;
  final FilterPainterFn? paint;
}

void drawEmoji(Canvas c, String emoji, Offset center, double size) {
  final tp = TextPainter(
    text: TextSpan(
      text: emoji,
      style: TextStyle(fontSize: size),
    ),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
}

void _nose(Canvas c, FaceGeom g, Color color, double scale) {
  c.drawOval(
    Rect.fromCenter(center: g.nose, width: g.w * 0.16 * scale, height: g.w * 0.11 * scale),
    Paint()..color = color,
  );
}

void _whiskers(Canvas c, FaceGeom g) {
  final p = Paint()
    ..color = Colors.black87
    ..strokeWidth = max(2, g.w * 0.012)
    ..strokeCap = StrokeCap.round;
  for (final side in [-1.0, 1.0]) {
    for (final dy in [-0.06, 0.0, 0.06]) {
      final start = g.nose + Offset(side * g.w * 0.1, g.h * dy * 0.5);
      final end = g.nose + Offset(side * g.w * 0.42, g.h * dy * 1.6);
      c.drawLine(start, end, p);
    }
  }
}

void _paintCat(Canvas c, FaceGeom g) {
  final top = g.box.top;
  for (final side in [-1.0, 1.0]) {
    final base = Offset(g.center.dx + side * g.w * 0.3, top + g.h * 0.05);
    final outer = Path()
      ..moveTo(base.dx - g.w * 0.2, base.dy)
      ..lineTo(base.dx + side * g.w * 0.08, top - g.h * 0.32)
      ..lineTo(base.dx + g.w * 0.2, base.dy)
      ..close();
    final inner = Path()
      ..moveTo(base.dx - g.w * 0.11, base.dy - g.h * 0.02)
      ..lineTo(base.dx + side * g.w * 0.07, top - g.h * 0.2)
      ..lineTo(base.dx + g.w * 0.11, base.dy - g.h * 0.02)
      ..close();
    c.drawPath(outer, Paint()..color = const Color(0xFFFFA040));
    c.drawPath(inner, Paint()..color = const Color(0xFFFFB6D1));
  }
  _whiskers(c, g);
  _nose(c, g, const Color(0xFFFF6FA5), 1);
}

void _paintBunny(Canvas c, FaceGeom g) {
  final top = g.box.top;
  for (final side in [-1.0, 1.0]) {
    final center = Offset(g.center.dx + side * g.w * 0.2, top - g.h * 0.38);
    c.save();
    c.translate(center.dx, center.dy);
    c.rotate(side * 0.18);
    c.drawOval(
      Rect.fromCenter(center: Offset.zero, width: g.w * 0.26, height: g.h * 0.8),
      Paint()..color = Colors.white,
    );
    c.drawOval(
      Rect.fromCenter(center: Offset.zero, width: g.w * 0.13, height: g.h * 0.6),
      Paint()..color = const Color(0xFFFFB6D1),
    );
    c.restore();
  }
  _nose(c, g, const Color(0xFFFF6FA5), 0.9);
  final tooth = Paint()..color = Colors.white;
  final tw = g.w * 0.06;
  final ty = g.nose.dy + g.h * 0.12;
  c.drawRRect(
    RRect.fromRectAndRadius(Rect.fromLTWH(g.nose.dx - tw, ty, tw * 0.95, tw * 1.4), Radius.circular(tw * 0.2)),
    tooth,
  );
  c.drawRRect(
    RRect.fromRectAndRadius(Rect.fromLTWH(g.nose.dx + tw * 0.05, ty, tw * 0.95, tw * 1.4), Radius.circular(tw * 0.2)),
    tooth,
  );
}

void _paintBear(Canvas c, FaceGeom g) {
  final top = g.box.top;
  for (final side in [-1.0, 1.0]) {
    final center = Offset(g.center.dx + side * g.w * 0.38, top + g.h * 0.02);
    c.drawCircle(center, g.w * 0.18, Paint()..color = const Color(0xFF8D5B3A));
    c.drawCircle(center, g.w * 0.1, Paint()..color = const Color(0xFFE0B48A));
  }
  _nose(c, g, const Color(0xFF3B2416), 1.1);
}

void _paintPrincess(Canvas c, FaceGeom g) {
  drawEmoji(c, '👑', Offset(g.center.dx, g.box.top - g.h * 0.12), g.w * 0.6);
  drawEmoji(c, '✨', Offset(g.box.left - g.w * 0.05, g.box.top + g.h * 0.1), g.w * 0.22);
  drawEmoji(c, '✨', Offset(g.box.right + g.w * 0.05, g.box.top + g.h * 0.25), g.w * 0.18);
  final blush = Paint()..color = const Color(0x66FF6FA5);
  c.drawOval(
    Rect.fromCenter(center: g.nose + Offset(-g.w * 0.26, g.h * 0.05), width: g.w * 0.2, height: g.w * 0.12),
    blush,
  );
  c.drawOval(
    Rect.fromCenter(center: g.nose + Offset(g.w * 0.26, g.h * 0.05), width: g.w * 0.2, height: g.w * 0.12),
    blush,
  );
}

void _paintFlowers(Canvas c, FaceGeom g) {
  const flowers = ['🌸', '🌼', '🌺', '🌷', '🌸', '🌼', '🌺'];
  for (var i = 0; i < flowers.length; i++) {
    final t = i / (flowers.length - 1); // 0..1
    final angle = pi + t * pi; // setengah lingkaran di atas kepala
    final p = Offset(g.center.dx + cos(angle) * g.w * 0.55, g.box.top + g.h * 0.12 + sin(angle) * g.h * 0.3);
    drawEmoji(c, flowers[i], p, g.w * 0.22);
  }
  drawEmoji(c, '🦋', Offset(g.box.right + g.w * 0.05, g.box.top - g.h * 0.1), g.w * 0.25);
}

void _paintPanda(Canvas c, FaceGeom g) {
  drawEmoji(c, '🐼', g.center, g.w * 1.25);
}

const faceFilters = <FaceFilter>[
  FaceFilter('none', 'Biasa', '🙂', null),
  FaceFilter('kucing', 'Kucing', '🐱', _paintCat),
  FaceFilter('kelinci', 'Kelinci', '🐰', _paintBunny),
  FaceFilter('beruang', 'Beruang', '🐻', _paintBear),
  FaceFilter('putri', 'Putri', '👑', _paintPrincess),
  FaceFilter('bunga', 'Bunga', '🌸', _paintFlowers),
  FaceFilter('panda', 'Panda', '🐼', _paintPanda),
];

FaceFilter filterById(String id) => faceFilters.firstWhere((f) => f.id == id, orElse: () => faceFilters.first);

/// Mengubah [Face] (koordinat gambar) ke [FaceGeom] (koordinat tujuan).
FaceGeom geomFromFace(Face f, {required double scale, required bool mirror, required double imageWidth}) {
  Offset tr(Offset p) => Offset((mirror ? imageWidth - p.dx : p.dx) * scale, p.dy * scale);
  final b = f.boundingBox;
  final a = tr(b.topLeft);
  final z = tr(b.bottomRight);
  final box = Rect.fromPoints(a, z);
  final noseLm = f.landmarks[FaceLandmarkType.noseBase]?.position;
  final nose = noseLm != null
      ? tr(Offset(noseLm.x.toDouble(), noseLm.y.toDouble()))
      : Offset(box.center.dx, box.top + box.height * 0.6);
  return FaceGeom(box, nose);
}

class FaceFilterPainter extends CustomPainter {
  FaceFilterPainter({required this.faces, required this.filter, required this.imageSize, required this.mirror});

  final List<Face> faces;
  final FaceFilter filter;

  /// Ukuran gambar kamera dalam posisi tegak (portrait).
  final Size imageSize;
  final bool mirror;

  @override
  void paint(Canvas canvas, Size size) {
    final fn = filter.paint;
    if (fn == null || imageSize.width == 0) return;
    final scale = size.width / imageSize.width;
    for (final f in faces) {
      fn(canvas, geomFromFace(f, scale: scale, mirror: mirror, imageWidth: imageSize.width));
    }
  }

  @override
  bool shouldRepaint(FaceFilterPainter old) => old.faces != faces || old.filter != filter;
}

/// Browser tidak punya pendeteksi wajah, jadi wajah diarahkan ke oval panduan di tengah layar.
FaceGeom guideGeom(Size s) {
  final w = min(s.width * 0.5, s.height * 0.36);
  final box = Rect.fromCenter(center: Offset(s.width / 2, s.height * 0.5), width: w, height: w * 1.3);
  return FaceGeom(box, Offset(box.center.dx, box.top + box.height * 0.6));
}

class GuideFilterPainter extends CustomPainter {
  GuideFilterPainter({required this.filter, this.showGuide = true});
  final FaceFilter filter;
  final bool showGuide;

  @override
  void paint(Canvas canvas, Size size) {
    final g = guideGeom(size);
    if (showGuide) {
      canvas.drawOval(
        g.box.inflate(6),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4
          ..color = Colors.white70,
      );
    }
    filter.paint?.call(canvas, g);
  }

  @override
  bool shouldRepaint(GuideFilterPainter old) => old.filter != filter || old.showGuide != showGuide;
}
