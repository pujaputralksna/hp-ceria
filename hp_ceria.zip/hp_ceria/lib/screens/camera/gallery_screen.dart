import 'package:flutter/material.dart';

import '../../core/widgets.dart';
import '../parent/parent_gate.dart';
import 'photo_store.dart';

/// Galeri foto hasil Kamera Filter. Menghapus foto butuh PIN orang tua.
class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  List<Photo> _photos = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await PhotoStore.all();
    if (mounted) setState(() => _photos = p);
  }

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Galeri',
      color: const Color(0xFF7E57C2),
      body: _photos.isEmpty
          ? const Center(
              child: Text(
                '📷\nBelum ada foto.\nAyo foto pakai filter hewan!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.75,
              ),
              itemCount: _photos.length,
              itemBuilder: (_, i) => Bouncy(
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => _PhotoView(photo: _photos[i])));
                  _load();
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.memory(_photos[i].bytes, fit: BoxFit.cover, cacheWidth: 400),
                ),
              ),
            ),
    );
  }
}

class _PhotoView extends StatelessWidget {
  const _PhotoView({required this.photo});
  final Photo photo;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          InteractiveViewer(child: Image.memory(photo.bytes, fit: BoxFit.contain)),
          const SafeArea(
            child: Align(alignment: Alignment.topLeft, child: KidBackButton()),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.white54, size: 32),
                onPressed: () async {
                  if (await askParentPin(context, title: 'PIN untuk menghapus foto')) {
                    await PhotoStore.delete(photo);
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
