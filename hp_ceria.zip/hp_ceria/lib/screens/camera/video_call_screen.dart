import 'package:flutter/material.dart';

import '../../core/call_session.dart';
import '../../core/listener.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';
import '../../data/animals.dart';
import 'face_camera_view.dart';
import 'face_filters.dart';

/// Filter wajah anak yang cocok dengan teman hewan yang ditelepon.
const _matchingFilter = {
  'kucing': 'kucing',
  'kelinci': 'kelinci',
  'anjing': 'beruang',
  'panda': 'beruang',
  'singa': 'beruang',
  'unicorn': 'putri',
  'bebek': 'bunga',
  'gajah': 'bunga',
};

/// Video call: hewan tampil besar, wajah anak (dengan filter) tampil kecil di pojok.
class VideoCallScreen extends StatefulWidget {
  const VideoCallScreen({super.key, required this.friend});
  final AnimalFriend friend;

  @override
  State<VideoCallScreen> createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> with SingleTickerProviderStateMixin {
  late final CallSession _s = CallSession(widget.friend)..addListener(_onChange);
  late final AnimationController _bg = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();

  @override
  void initState() {
    super.initState();
    _s.start(turns: 5);
  }

  void _onChange() {
    if (!mounted) return;
    if (_s.phase == CallPhase.ended) {
      Future<void>.delayed(const Duration(milliseconds: 800), () {
        if (mounted) Navigator.of(context).maybePop();
      });
    }
    setState(() {});
  }

  @override
  void dispose() {
    _s.removeListener(_onChange);
    _s.dispose();
    _bg.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final f = widget.friend;
    final ringing = _s.phase == CallPhase.ringing;
    return PopScope(
      onPopInvokedWithResult: (_, _) => _s.hangUp(),
      child: Scaffold(
        body: Stack(
          fit: StackFit.expand,
          children: [
            // Latar "kamar" si hewan dengan gelembung yang melayang
            AnimatedBuilder(
              animation: _bg,
              builder: (_, _) => CustomPaint(painter: _BubblesPainter(_bg.value, f.color)),
            ),
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  WigglingEmoji(f.emoji, size: 200, talking: ringing ? null : Speaker.instance.speaking),
                  const SizedBox(height: 16),
                  if (!ringing && _s.caption.isNotEmpty && _s.phase != CallPhase.listening)
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 24),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                      child: Text(
                        _s.caption,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                      ),
                    ),
                  if (_s.phase == CallPhase.listening)
                    ValueListenableBuilder<double>(
                      valueListenable: VoiceListener.instance.level,
                      builder: (_, l, _) => Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(color: Colors.white70, borderRadius: BorderRadius.circular(30)),
                        child: Text('🎤 ${'🔊' * (1 + (l * 4).round())}', style: const TextStyle(fontSize: 26)),
                      ),
                    ),
                ],
              ),
            ),
            // Nama & durasi
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      f.name,
                      style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white),
                    ),
                    Text(
                      ringing ? 'Memanggil video...' : _s.durationText,
                      style: const TextStyle(fontSize: 20, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
            // Kamera anak (kecil, pojok kanan atas)
            SafeArea(
              child: Align(
                alignment: Alignment.topRight,
                child: Container(
                  margin: const EdgeInsets.all(12),
                  width: 120,
                  height: 170,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white, width: 3),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: FaceCameraView(filter: filterById(_matchingFilter[f.id] ?? 'putri')),
                  ),
                ),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 32),
                  child: Bouncy(
                    onTap: _s.hangUp,
                    child: const CircleAvatar(
                      radius: 44,
                      backgroundColor: Colors.red,
                      child: Icon(Icons.call_end, color: Colors.white, size: 48),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BubblesPainter extends CustomPainter {
  _BubblesPainter(this.t, this.color);
  final double t;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color.lerp(color, Colors.white, 0.3)!, Color.lerp(color, Colors.black, 0.25)!],
        ).createShader(Offset.zero & size),
    );
    final p = Paint()..color = Colors.white.withValues(alpha: 0.18);
    for (var i = 0; i < 14; i++) {
      final x = (i * 97 % 100) / 100 * size.width;
      final y = size.height - ((t + i / 14) % 1) * (size.height + 80);
      canvas.drawCircle(Offset(x, y), 14.0 + (i % 4) * 10, p);
    }
  }

  @override
  bool shouldRepaint(_BubblesPainter old) => old.t != t;
}
