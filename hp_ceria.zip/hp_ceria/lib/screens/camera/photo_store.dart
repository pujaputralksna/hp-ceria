import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Photo {
  Photo(this.id, this.bytes);
  final String id;
  final Uint8List bytes;
}

/// Foto disimpan di folder pribadi aplikasi (Android) atau penyimpanan browser (web).
class PhotoStore {
  /// Penyimpanan browser terbatas (±5 MB), jadi hanya foto terbaru yang disimpan.
  static const _webMax = 6;
  static const _webKey = 'webPhotos';

  static Future<Directory> _dir() async {
    final d = Directory('${(await getApplicationDocumentsDirectory()).path}/foto');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  static Future<void> save(Uint8List png) async {
    final id = 'foto_${DateTime.now().millisecondsSinceEpoch}';
    if (kIsWeb) {
      final p = await SharedPreferences.getInstance();
      final list = [base64Encode(png), ...?p.getStringList(_webKey)];
      // Bila penuh, buang foto paling lama sampai muat.
      for (var n = list.length.clamp(1, _webMax); n >= 1; n--) {
        try {
          await p.setStringList(_webKey, list.take(n).toList());
          return;
        } catch (_) {}
      }
      return;
    }
    final d = await _dir();
    await File('${d.path}/$id.png').writeAsBytes(png);
  }

  static Future<List<Photo>> all() async {
    if (kIsWeb) {
      final p = await SharedPreferences.getInstance();
      final list = p.getStringList(_webKey) ?? [];
      return [for (var i = 0; i < list.length; i++) Photo('$i', base64Decode(list[i]))];
    }
    final d = await _dir();
    final files = d.listSync().whereType<File>().where((f) => f.path.endsWith('.png')).toList()
      ..sort((a, b) => b.path.compareTo(a.path));
    return [for (final f in files) Photo(f.path, await f.readAsBytes())];
  }

  static Future<void> delete(Photo photo) async {
    if (kIsWeb) {
      final p = await SharedPreferences.getInstance();
      final list = p.getStringList(_webKey) ?? [];
      final i = int.parse(photo.id);
      if (i < list.length) list.removeAt(i);
      await p.setStringList(_webKey, list);
      return;
    }
    await File(photo.id).delete();
  }
}
