import 'package:flutter/material.dart';

import '../../core/sfx.dart';
import '../../core/speaker.dart';
import '../../core/widgets.dart';
import 'face_camera_view.dart';
import 'face_filters.dart';
import 'gallery_screen.dart';
import 'photo_store.dart';

class FilterCameraScreen extends StatefulWidget {
  const FilterCameraScreen({super.key});

  @override
  State<FilterCameraScreen> createState() => _FilterCameraScreenState();
}

class _FilterCameraScreenState extends State<FilterCameraScreen> {
  final _cam = GlobalKey<FaceCameraViewState>();
  FaceFilter _filter = faceFilters[1];
  bool _front = true;
  bool _flash = false;

  Future<void> _shoot() async {
    Sfx.play('cekrek');
    setState(() => _flash = true);
    Future<void>.delayed(const Duration(milliseconds: 150), () {
      if (mounted) setState(() => _flash = false);
    });
    final png = await _cam.currentState?.snapshot();
    if (png == null) return;
    await PhotoStore.save(png);
    Speaker.instance.say('Cekrek! Fotonya bagus sekali!');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          FaceCameraView(key: _cam, filter: _filter, front: _front),
          if (_flash) const ColoredBox(color: Colors.white),
          const SafeArea(
            child: Align(alignment: Alignment.topLeft, child: KidBackButton()),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 92,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      children: [
                        for (final f in faceFilters)
                          Bouncy(
                            onTap: () {
                              setState(() => _filter = f);
                              Speaker.instance.say(f.name);
                            },
                            child: Container(
                              width: 76,
                              margin: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withValues(alpha: f == _filter ? 0.95 : 0.5),
                                border: Border.all(
                                  color: f == _filter ? Colors.pinkAccent : Colors.transparent,
                                  width: 4,
                                ),
                              ),
                              alignment: Alignment.center,
                              child: Text(f.icon, style: const TextStyle(fontSize: 40)),
                            ),
                          ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _RoundButton(
                          icon: Icons.photo_library,
                          onTap: () =>
                              Navigator.push(context, MaterialPageRoute(builder: (_) => const GalleryScreen())),
                        ),
                        Bouncy(
                          onTap: _shoot,
                          child: Container(
                            width: 92,
                            height: 92,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                              border: Border.all(color: Colors.pinkAccent, width: 6),
                            ),
                            child: const Icon(Icons.camera_alt, size: 44, color: Colors.pinkAccent),
                          ),
                        ),
                        _RoundButton(icon: Icons.cameraswitch, onTap: () => setState(() => _front = !_front)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Bouncy(
      onTap: onTap,
      child: CircleAvatar(
        radius: 32,
        backgroundColor: Colors.white54,
        child: Icon(icon, size: 34, color: Colors.white),
      ),
    );
  }
}
