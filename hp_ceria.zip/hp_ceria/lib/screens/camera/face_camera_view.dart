import 'dart:async';
import 'dart:ui' as ui;

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

import 'face_filters.dart';

/// Tampilan kamera + pendeteksi wajah + filter hewan secara langsung.
class FaceCameraView extends StatefulWidget {
  const FaceCameraView({super.key, required this.filter, this.front = true, this.onController});

  final FaceFilter filter;
  final bool front;

  /// Memberi akses ke controller (mis. untuk mengambil foto).
  final void Function(CameraController? c)? onController;

  @override
  State<FaceCameraView> createState() => FaceCameraViewState();
}

class FaceCameraViewState extends State<FaceCameraView> with WidgetsBindingObserver {
  CameraController? _controller;
  final _detector = FaceDetector(
    options: FaceDetectorOptions(enableLandmarks: true, performanceMode: FaceDetectorMode.fast, minFaceSize: 0.15),
  );
  bool _busy = false;
  CameraImage? _lastFrame;
  List<Face> _faces = const [];
  Size _imageSize = Size.zero;
  Size _viewSize = Size.zero;
  String? _error;

  CameraController? get controller => _controller;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _start();
  }

  @override
  void didUpdateWidget(FaceCameraView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.front != widget.front) _restart();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      _stop();
    } else if (state == AppLifecycleState.resumed && _controller == null) {
      _start();
    }
  }

  Future<void> _restart() async {
    await _stop();
    await _start();
  }

  Future<void> _start() async {
    try {
      final cams = await availableCameras();
      if (cams.isEmpty) throw CameraException('none', 'Kamera tidak ditemukan');
      final want = widget.front ? CameraLensDirection.front : CameraLensDirection.back;
      final desc = cams.firstWhere((c) => c.lensDirection == want, orElse: () => cams.first);
      final c = kIsWeb
          ? CameraController(desc, ResolutionPreset.high, enableAudio: false)
          : CameraController(
              desc,
              ResolutionPreset.medium,
              enableAudio: false,
              imageFormatGroup: ImageFormatGroup.nv21,
            );
      await c.initialize();
      if (!mounted) {
        await c.dispose();
        return;
      }
      _controller = c;
      // Browser: tanpa stream gambar & pendeteksi wajah (tidak didukung).
      if (!kIsWeb) await c.startImageStream((img) => _process(img, desc));
      widget.onController?.call(c);
      setState(() => _error = null);
    } catch (e) {
      debugPrint('Kamera gagal: $e');
      if (mounted) setState(() => _error = 'Kamera belum diizinkan atau tidak tersedia.');
    }
  }

  Future<void> _stop() async {
    final c = _controller;
    _controller = null;
    widget.onController?.call(null);
    if (c != null) {
      try {
        if (c.value.isStreamingImages) await c.stopImageStream();
      } catch (_) {}
      await c.dispose();
    }
  }

  /// Mengambil foto dari frame kamera terakhir, lengkap dengan filter, dalam format PNG.
  Future<Uint8List?> snapshot() async {
    if (kIsWeb) return _webSnapshot();
    final c = _controller;
    final img = _lastFrame;
    if (c == null || img == null) return null;
    final rot = c.description.sensorOrientation;
    final mirror = c.description.lensDirection == CameraLensDirection.front;
    final job = _Nv21Job(Uint8List.fromList(img.planes.first.bytes), img.width, img.height, rot, mirror);
    final rgba = await compute(_nv21ToRgba, job);
    final w = (rot == 90 || rot == 270) ? img.height : img.width;
    final h = (rot == 90 || rot == 270) ? img.width : img.height;
    final done = Completer<ui.Image>();
    ui.decodeImageFromPixels(rgba, w, h, ui.PixelFormat.rgba8888, done.complete);
    final photo = await done.future;
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final size = Size(w.toDouble(), h.toDouble());
    canvas.drawImage(photo, Offset.zero, Paint());
    FaceFilterPainter(faces: _faces, filter: widget.filter, imageSize: size, mirror: mirror).paint(canvas, size);
    final out = await recorder.endRecording().toImage(w, h);
    final png = await out.toByteData(format: ui.ImageByteFormat.png);
    return png?.buffer.asUint8List();
  }

  /// Browser: ambil foto, potong sesuai area yang terlihat, lalu gambar filter di oval panduan.
  Future<Uint8List?> _webSnapshot() async {
    final c = _controller;
    if (c == null || _viewSize.isEmpty) return null;
    final shot = await c.takePicture();
    final codec = await ui.instantiateImageCodec(await shot.readAsBytes());
    final photo = (await codec.getNextFrame()).image;
    // Pratinjau memakai "cover": hitung bagian tengah foto yang terlihat di layar.
    final src = Size(photo.width.toDouble(), photo.height.toDouble());
    final viewAspect = _viewSize.width / _viewSize.height;
    final crop = src.width / src.height > viewAspect
        ? Rect.fromCenter(center: src.center(Offset.zero), width: src.height * viewAspect, height: src.height)
        : Rect.fromCenter(center: src.center(Offset.zero), width: src.width, height: src.width / viewAspect);
    final out = Size(crop.width.roundToDouble(), crop.height.roundToDouble());
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.drawImageRect(photo, crop, Offset.zero & out, Paint()..filterQuality = FilterQuality.high);
    GuideFilterPainter(filter: widget.filter, showGuide: false).paint(canvas, out);
    final img = await recorder.endRecording().toImage(out.width.toInt(), out.height.toInt());
    final png = await img.toByteData(format: ui.ImageByteFormat.png);
    return png?.buffer.asUint8List();
  }

  Future<void> _process(CameraImage img, CameraDescription desc) async {
    _lastFrame = img;
    if (_busy || widget.filter.paint == null) return;
    _busy = true;
    try {
      final rotation = InputImageRotationValue.fromRawValue(desc.sensorOrientation) ?? InputImageRotation.rotation0deg;
      final format = InputImageFormatValue.fromRawValue(img.format.raw as int) ?? InputImageFormat.nv21;
      final input = InputImage.fromBytes(
        bytes: img.planes.first.bytes,
        metadata: InputImageMetadata(
          size: Size(img.width.toDouble(), img.height.toDouble()),
          rotation: rotation,
          format: format,
          bytesPerRow: img.planes.first.bytesPerRow,
        ),
      );
      final faces = await _detector.processImage(input);
      final upright = (rotation == InputImageRotation.rotation90deg || rotation == InputImageRotation.rotation270deg)
          ? Size(img.height.toDouble(), img.width.toDouble())
          : Size(img.width.toDouble(), img.height.toDouble());
      if (mounted) {
        setState(() {
          _faces = faces;
          _imageSize = upright;
        });
      }
    } catch (e) {
      debugPrint('Deteksi wajah gagal: $e');
    } finally {
      _busy = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stop();
    _detector.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _controller;
    if (_error != null) {
      return Container(
        color: Colors.black87,
        alignment: Alignment.center,
        padding: const EdgeInsets.all(12),
        child: Text(
          '📷\n$_error',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white),
        ),
      );
    }
    if (c == null || !c.value.isInitialized) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (kIsWeb) {
      return LayoutBuilder(
        builder: (context, box) {
          _viewSize = box.biggest;
          return Stack(
            fit: StackFit.expand,
            children: [
              // Elemen video browser sudah "cover" dan dicerminkan untuk kamera depan / webcam.
              c.buildPreview(),
              CustomPaint(
                painter: GuideFilterPainter(filter: widget.filter, showGuide: box.maxWidth > 200),
              ),
            ],
          );
        },
      );
    }
    // previewSize dilaporkan dalam posisi landscape; dibalik agar tegak.
    final ps = c.value.previewSize ?? const Size(640, 480);
    final upright = Size(ps.shortestSide, ps.longestSide);
    final imageSize = _imageSize == Size.zero ? upright : _imageSize;
    return ClipRect(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: upright.width,
          height: upright.height,
          child: Stack(
            fit: StackFit.expand,
            children: [
              CameraPreview(c),
              CustomPaint(
                painter: FaceFilterPainter(
                  faces: _faces,
                  filter: widget.filter,
                  imageSize: imageSize,
                  mirror:
                      c.description.lensDirection == CameraLensDirection.front &&
                      defaultTargetPlatform == TargetPlatform.android,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Nv21Job {
  _Nv21Job(this.bytes, this.width, this.height, this.rotation, this.mirror);
  final Uint8List bytes;
  final int width;
  final int height;
  final int rotation;
  final bool mirror;
}

/// Mengubah frame NV21 menjadi RGBA yang sudah diputar tegak (dan dicerminkan untuk kamera depan).
Uint8List _nv21ToRgba(_Nv21Job j) {
  final sw = j.width, sh = j.height;
  final swap = j.rotation == 90 || j.rotation == 270;
  final ow = swap ? sh : sw, oh = swap ? sw : sh;
  final out = Uint8List(ow * oh * 4);
  final frame = sw * sh;
  var o = 0;
  for (var oy = 0; oy < oh; oy++) {
    for (var x = 0; x < ow; x++) {
      final ox = j.mirror ? ow - 1 - x : x;
      int sx, sy;
      switch (j.rotation) {
        case 90:
          sx = oy;
          sy = sh - 1 - ox;
        case 180:
          sx = sw - 1 - ox;
          sy = sh - 1 - oy;
        case 270:
          sx = sw - 1 - oy;
          sy = ox;
        default:
          sx = ox;
          sy = oy;
      }
      final y = j.bytes[sy * sw + sx];
      final uv = frame + (sy >> 1) * sw + (sx & ~1);
      final v = uv < j.bytes.length ? j.bytes[uv] - 128 : 0;
      final u = uv + 1 < j.bytes.length ? j.bytes[uv + 1] - 128 : 0;
      out[o++] = (y + 1.402 * v).round().clamp(0, 255);
      out[o++] = (y - 0.344 * u - 0.714 * v).round().clamp(0, 255);
      out[o++] = (y + 1.772 * u).round().clamp(0, 255);
      out[o++] = 255;
    }
  }
  return out;
}
