import 'package:flutter/material.dart';

import '../../core/widgets.dart';
import '../../data/animals.dart';
import 'filter_camera_screen.dart';
import 'gallery_screen.dart';
import 'video_call_screen.dart';

const cameraPurple = Color(0xFF9575CD);

class CameraHomeScreen extends StatelessWidget {
  const CameraHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return KidScaffold(
      title: 'Kamera',
      color: cameraPurple,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SizedBox(
            height: 170,
            child: BigTile(
              emoji: '🤳🐾',
              label: 'Kamera Filter Hewan',
              color: const Color(0xFFFF8CC6),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FilterCameraScreen())),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 120,
            child: BigTile(
              emoji: '🖼️',
              label: 'Lihat Foto',
              color: const Color(0xFF7E57C2),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GalleryScreen())),
            ),
          ),
          const SizedBox(height: 24),
          const Text('📹 Video Call', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 3,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: [
              for (final f in animalFriends)
                BigTile(
                  emoji: f.emoji,
                  label: f.name.split(' ').first,
                  color: f.color,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoCallScreen(friend: f))),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
