import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Satu video di menu "Video". [source] berisi ID YouTube atau path file di HP.
class VideoItem {
  VideoItem({required this.title, required this.source, required this.isYoutube, this.category = 'Semua'});

  final String title;
  final String source;
  final bool isYoutube;
  final String category;

  Map<String, dynamic> toJson() => {'title': title, 'source': source, 'isYoutube': isYoutube, 'category': category};

  factory VideoItem.fromJson(Map<String, dynamic> j) => VideoItem(
    title: j['title'] as String,
    source: j['source'] as String,
    isYoutube: j['isYoutube'] as bool,
    category: (j['category'] as String?) ?? 'Semua',
  );

  String? get thumbnailUrl => isYoutube ? 'https://img.youtube.com/vi/$source/hqdefault.jpg' : null;
}

/// Pengaturan yang diatur orang tua, disimpan di HP.
class AppSettings extends ChangeNotifier {
  AppSettings._();
  static final AppSettings instance = AppSettings._();

  static const videoCategories = ['Lagu', 'Belajar', 'Kartun', 'Dongeng'];

  late SharedPreferences _p;

  String get childName => _p.getString('childName') ?? 'Adik';
  String get parentPin => _p.getString('parentPin') ?? '';
  bool get isSetupDone => parentPin.length == 4;
  int get dailyLimitMinutes => _p.getInt('dailyLimitMinutes') ?? 0;
  bool get kidsModeEnabled => _p.getBool('kidsModeEnabled') ?? true;

  List<VideoItem> get videos {
    final raw = _p.getString('videos');
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((e) => VideoItem.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
  }

  Future<void> setChildName(String v) async {
    await _p.setString('childName', v.trim().isEmpty ? 'Adik' : v.trim());
    notifyListeners();
  }

  Future<void> setParentPin(String v) async {
    await _p.setString('parentPin', v);
    notifyListeners();
  }

  Future<void> setDailyLimitMinutes(int v) async {
    await _p.setInt('dailyLimitMinutes', v);
    notifyListeners();
  }

  Future<void> setKidsModeEnabled(bool v) async {
    await _p.setBool('kidsModeEnabled', v);
    notifyListeners();
  }

  Future<void> saveVideos(List<VideoItem> list) async {
    await _p.setString('videos', jsonEncode(list.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  // ---- Pencatat waktu main harian ----
  String get _todayKey {
    final n = DateTime.now();
    return 'usage_${n.year}_${n.month}_${n.day}';
  }

  int get usedSecondsToday => _p.getInt(_todayKey) ?? 0;

  Future<void> addUsageSeconds(int s) => _p.setInt(_todayKey, usedSecondsToday + s);

  Future<void> resetUsageToday() async {
    await _p.setInt(_todayKey, 0);
    notifyListeners();
  }

  bool get isTimeUp => dailyLimitMinutes > 0 && usedSecondsToday >= dailyLimitMinutes * 60;
}

/// Mengambil ID video dari link YouTube (youtu.be/..., watch?v=..., shorts/...).
String? parseYoutubeId(String input) {
  final s = input.trim();
  final direct = RegExp(r'^[A-Za-z0-9_-]{11}$');
  if (direct.hasMatch(s)) return s;
  final patterns = [
    RegExp(r'youtu\.be/([A-Za-z0-9_-]{11})'),
    RegExp(r'[?&]v=([A-Za-z0-9_-]{11})'),
    RegExp(r'youtube\.com/(?:shorts|embed|live)/([A-Za-z0-9_-]{11})'),
  ];
  for (final p in patterns) {
    final m = p.firstMatch(s);
    if (m != null) return m.group(1);
  }
  return null;
}
