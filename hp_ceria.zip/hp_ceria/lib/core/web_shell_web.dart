import 'dart:js_interop';

import 'package:web/web.dart' as web;

bool get isFullscreen => web.document.fullscreenElement != null;

Future<void> enterFullscreen() async {
  try {
    await web.document.documentElement?.requestFullscreen().toDart;
  } catch (_) {}
}

Future<void> exitFullscreen() async {
  try {
    if (isFullscreen) await web.document.exitFullscreen().toDart;
  } catch (_) {}
}

void onFullscreenChange(void Function(bool fullscreen) callback) {
  web.document.addEventListener('fullscreenchange', ((web.Event _) => callback(isFullscreen)).toJS);
}

bool _warn = false;
bool _listening = false;

/// Saat aktif, Chrome bertanya "Tinggalkan situs?" bila tab akan ditutup / dimuat ulang.
void setLeaveWarning(bool enabled) {
  _warn = enabled;
  if (_listening) return;
  _listening = true;
  web.window.addEventListener(
    'beforeunload',
    ((web.Event e) {
      if (!_warn) return;
      e.preventDefault();
      (e as web.BeforeUnloadEvent).returnValue = '';
    }).toJS,
  );
}
