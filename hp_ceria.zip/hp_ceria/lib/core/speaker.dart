import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// Suara pembaca (Text-to-Speech) berbahasa Indonesia.
class Speaker {
  Speaker._();
  static final Speaker instance = Speaker._();

  final FlutterTts _tts = FlutterTts();
  bool _ready = false;

  /// true selama suara sedang berbicara (dipakai untuk animasi mulut karakter).
  final ValueNotifier<bool> speaking = ValueNotifier(false);

  Future<void> init() async {
    if (_ready) return;
    try {
      await _tts.setLanguage('id-ID');
      await _tts.setSpeechRate(0.42);
      await _tts.setPitch(1.25);
      await _tts.awaitSpeakCompletion(true);
      _tts.setStartHandler(() => speaking.value = true);
      _tts.setCompletionHandler(() => speaking.value = false);
      _tts.setCancelHandler(() => speaking.value = false);
      _tts.setErrorHandler((_) => speaking.value = false);
    } catch (e) {
      debugPrint('TTS tidak tersedia: $e');
    }
    _ready = true;
  }

  /// Mengucapkan [text]. [pitch] tinggi = suara lucu (mis. tikus), rendah = suara besar (mis. gajah).
  Future<void> say(String text, {double pitch = 1.25, double rate = 0.42}) async {
    await init();
    try {
      await _tts.stop();
      await _tts.setPitch(pitch);
      await _tts.setSpeechRate(rate);
      speaking.value = true;
      // Pengaman: sebagian browser kadang tidak memberi sinyal "selesai bicara".
      final limit = Duration(milliseconds: 2500 + text.length * 110);
      await _tts.speak(text).timeout(limit, onTimeout: () => null);
    } catch (e) {
      debugPrint('TTS gagal: $e');
    } finally {
      speaking.value = false;
    }
  }

  Future<void> stop() async {
    speaking.value = false;
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
