import 'dart:async';

import 'package:flutter/foundation.dart';

import '../data/animals.dart';
import 'listener.dart';
import 'settings.dart';
import 'sfx.dart';
import 'speaker.dart';

enum CallPhase { ringing, talking, listening, ended }

/// Alur percakapan telepon / video call dengan teman hewan.
class CallSession extends ChangeNotifier {
  CallSession(this.friend) : brain = FriendBrain(friend);

  final AnimalFriend friend;
  final FriendBrain brain;

  CallPhase phase = CallPhase.ringing;
  String caption = '';
  String heard = '';
  int seconds = 0;
  Timer? _timer;
  bool _cancelled = false;

  String get _name => AppSettings.instance.childName;

  Future<void> _say(String text) async {
    if (_cancelled) return;
    phase = CallPhase.talking;
    caption = brain.fill(text, _name);
    notifyListeners();
    await Speaker.instance.say(caption, pitch: friend.pitch);
  }

  Future<String> _listen() async {
    if (_cancelled) return '';
    phase = CallPhase.listening;
    heard = '';
    notifyListeners();
    final t = await VoiceListener.instance.listen(maxSeconds: 7);
    heard = t;
    notifyListeners();
    return t;
  }

  Future<void> start({int turns = 4, bool ring = true}) async {
    if (ring) {
      await Sfx.play('ring', loop: true);
      await Future<void>.delayed(const Duration(milliseconds: 3200));
      await Sfx.stop('ring');
    }
    if (_cancelled) return;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      seconds++;
      notifyListeners();
    });
    await _say(friend.intro);
    for (var i = 0; i < turns && !_cancelled; i++) {
      await _say(brain.nextQuestion());
      final h = await _listen();
      if (_cancelled) return;
      await _say(brain.reply(h, _name));
      if (h.toLowerCase().contains('dadah') || h.toLowerCase().contains('bye')) break;
    }
    await _say('Sudah dulu ya, $_name. Telepon aku lagi nanti! Dadah! ${friend.sound}');
    if (!_cancelled) hangUp();
  }

  void hangUp() {
    if (phase == CallPhase.ended) return;
    _cancelled = true;
    _timer?.cancel();
    phase = CallPhase.ended;
    Sfx.stop('ring');
    Speaker.instance.stop();
    VoiceListener.instance.stop();
    notifyListeners();
  }

  String get durationText =>
      '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

  @override
  void dispose() {
    hangUp();
    super.dispose();
  }
}
