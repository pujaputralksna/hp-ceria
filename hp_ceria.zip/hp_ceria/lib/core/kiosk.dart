import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'web_shell.dart' as web_shell;

/// Jembatan ke kode Android (MainActivity.kt) untuk mengunci / membuka Mode Anak.
/// Di browser: layar penuh + peringatan saat tab ditutup (kunci penuh tidak mungkin dari browser).
class Kiosk {
  static const _ch = MethodChannel('hp_ceria/kiosk');

  static Future<T?> _call<T>(String method) async {
    if (kIsWeb) return null;
    try {
      return await _ch.invokeMethod<T>(method);
    } catch (e) {
      debugPrint('Kiosk.$method gagal: $e');
      return null;
    }
  }

  static DateTime _lastStart = DateTime(2000);

  /// Hasil: "full", "pinned", "already", atau null bila gagal / baru saja diminta.
  static Future<String?> start() async {
    if (kIsWeb) {
      // Layar penuh hanya boleh diminta setelah sentuhan; lihat WebStartOverlay di main.dart.
      web_shell.setLeaveWarning(true);
      return null;
    }
    // Dialog "Sematkan aplikasi?" membuat aplikasi pause-resume; jangan minta berulang-ulang.
    if (DateTime.now().difference(_lastStart) < const Duration(seconds: 5)) return null;
    _lastStart = DateTime.now();
    return _call<String>('startKidsMode');
  }

  static Future<void> stop() async {
    _lastStart = DateTime(2000);
    if (kIsWeb) {
      web_shell.setLeaveWarning(false);
      await web_shell.exitFullscreen();
      return;
    }
    await _call('stopKidsMode');
  }

  static Future<bool> isLocked() async => await _call<bool>('isLocked') ?? false;
  static Future<bool> isDeviceOwner() async => await _call<bool>('isDeviceOwner') ?? false;
  static Future<void> removeDeviceOwner() => _call('removeDeviceOwner');
  static Future<void> openHomeSettings() => _call('openHomeSettings');
  static Future<void> openSecuritySettings() => _call('openSecuritySettings');
  static Future<void> exitApp() => _call('exitApp');
}
