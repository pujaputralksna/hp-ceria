import 'package:flutter/material.dart';

/// Palet warna lembut bernuansa merah muda & ungu.
class AppColors {
  static const pink = Color(0xFFFF7EB6);
  static const pinkLight = Color(0xFFFFE4F1);
  static const purple = Color(0xFFA77BF3);
  static const lavender = Color(0xFFEDE4FF);
  static const mint = Color(0xFF7EE0C3);
  static const sky = Color(0xFF7CC8FF);
  static const sun = Color(0xFFFFD166);
  static const peach = Color(0xFFFFB38A);
  static const text = Color(0xFF4A3B5C);
  static const youtubeRed = Color(0xFFFF0033);
}

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: AppColors.pink, brightness: Brightness.light),
    scaffoldBackgroundColor: AppColors.pinkLight,
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(bodyColor: AppColors.text, displayColor: AppColors.text),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.pink,
      foregroundColor: Colors.white,
      centerTitle: true,
      titleTextStyle: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white),
    ),
  );
}
