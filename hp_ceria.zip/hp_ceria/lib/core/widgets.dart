import 'package:flutter/material.dart';

import 'theme.dart';

/// Kerangka layar anak: judul besar + tombol kembali bulat yang mudah ditekan.
class KidScaffold extends StatelessWidget {
  const KidScaffold({
    super.key,
    required this.title,
    required this.body,
    this.color = AppColors.pink,
    this.background,
    this.actions,
  });

  final String title;
  final Widget body;
  final Color color;
  final Color? background;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background ?? Color.lerp(color, Colors.white, 0.85),
      appBar: AppBar(
        backgroundColor: color,
        toolbarHeight: 72,
        leadingWidth: 76,
        leading: const KidBackButton(),
        title: Text(title),
        actions: actions,
      ),
      body: SafeArea(top: false, child: body),
    );
  }
}

class KidBackButton extends StatelessWidget {
  const KidBackButton({super.key, this.color = Colors.white});
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Material(
        color: color.withValues(alpha: 0.3),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: () => Navigator.of(context).maybePop(),
          child: Icon(Icons.arrow_back_rounded, size: 36, color: color),
        ),
      ),
    );
  }
}

/// Tombol yang "membal" saat disentuh — terasa menyenangkan untuk balita.
class Bouncy extends StatefulWidget {
  const Bouncy({super.key, required this.child, required this.onTap});
  final Widget child;
  final VoidCallback onTap;

  @override
  State<Bouncy> createState() => _BouncyState();
}

class _BouncyState extends State<Bouncy> {
  double _scale = 1;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _scale = 0.9),
      onTapCancel: () => setState(() => _scale = 1),
      onTapUp: (_) {
        setState(() => _scale = 1);
        widget.onTap();
      },
      child: AnimatedScale(scale: _scale, duration: const Duration(milliseconds: 120), child: widget.child),
    );
  }
}

/// Kartu besar berisi emoji + label.
class BigTile extends StatelessWidget {
  const BigTile({super.key, required this.emoji, required this.label, required this.color, required this.onTap});

  final String emoji;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Bouncy(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(28),
          boxShadow: [BoxShadow(color: color.withValues(alpha: 0.45), blurRadius: 12, offset: const Offset(0, 6))],
        ),
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: FittedBox(child: Text(emoji, style: const TextStyle(fontSize: 80))),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 2,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

/// Emoji yang bergoyang/membal terus-menerus.
class WigglingEmoji extends StatefulWidget {
  const WigglingEmoji(this.emoji, {super.key, this.size = 120, this.talking});
  final String emoji;
  final double size;

  /// Bila diberikan, emoji membesar-mengecil cepat saat nilainya true (seolah sedang bicara).
  final ValueNotifier<bool>? talking;

  @override
  State<WigglingEmoji> createState() => _WigglingEmojiState();
}

class _WigglingEmojiState extends State<WigglingEmoji> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
    ..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final talking = widget.talking ?? ValueNotifier(false);
    return ValueListenableBuilder<bool>(
      valueListenable: talking,
      builder: (context, isTalking, _) => AnimatedBuilder(
        animation: _c,
        builder: (context, child) {
          final t = Curves.easeInOut.transform(_c.value);
          final talkScale = isTalking ? 1 + 0.08 * (((_c.value * 6) % 1) < 0.5 ? 1 : 0) : 1.0;
          return Transform.rotate(
            angle: (t - 0.5) * 0.18,
            child: Transform.translate(
              offset: Offset(0, -10 * t),
              child: Transform.scale(scale: talkScale, child: child),
            ),
          );
        },
        child: Text(widget.emoji, style: TextStyle(fontSize: widget.size)),
      ),
    );
  }
}
