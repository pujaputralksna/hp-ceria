bool get isFullscreen => true;

Future<void> enterFullscreen() async {}

Future<void> exitFullscreen() async {}

void onFullscreenChange(void Function(bool fullscreen) callback) {}

void setLeaveWarning(bool enabled) {}
