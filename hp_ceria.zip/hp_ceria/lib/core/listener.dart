import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// Mendengarkan ucapan anak (Speech-to-Text). Bila tidak tersedia, cukup menunggu sebentar.
class VoiceListener {
  VoiceListener._();
  static final VoiceListener instance = VoiceListener._();

  final SpeechToText _stt = SpeechToText();
  bool? _available;
  String? _localeId;

  /// Level suara 0..1 untuk animasi mikrofon.
  final ValueNotifier<double> level = ValueNotifier(0);

  Future<bool> init() async {
    if (_available != null) return _available!;
    try {
      _available = await _stt.initialize(onError: (e) => debugPrint('STT error: $e'));
      if (_available! && kIsWeb) {
        _localeId = 'id-ID'; // Chrome memakai format BCP-47
      } else if (_available!) {
        final locales = await _stt.locales();
        _localeId = locales
            .map((l) => l.localeId)
            .firstWhere((id) => id.toLowerCase().startsWith('id'), orElse: () => 'id_ID');
      }
    } catch (e) {
      debugPrint('STT tidak tersedia: $e');
      _available = false;
    }
    return _available!;
  }

  /// Mendengarkan hingga [maxSeconds] detik. Mengembalikan teks yang terdengar ('' bila tidak ada).
  Future<String> listen({int maxSeconds = 6}) async {
    if (!await init()) {
      await Future<void>.delayed(Duration(seconds: maxSeconds ~/ 2));
      return '';
    }
    final done = Completer<String>();
    var text = '';
    try {
      await _stt.listen(
        onResult: (r) {
          text = r.recognizedWords;
          if (r.finalResult && !done.isCompleted) done.complete(text);
        },
        onSoundLevelChange: (l) => level.value = ((l + 2) / 12).clamp(0, 1).toDouble(),
        listenOptions: SpeechListenOptions(
          localeId: _localeId,
          listenFor: Duration(seconds: maxSeconds),
          pauseFor: const Duration(seconds: 3),
          partialResults: true,
          cancelOnError: true,
          listenMode: ListenMode.dictation,
        ),
      );
    } catch (e) {
      debugPrint('STT listen gagal: $e');
    }
    final result = await done.future.timeout(Duration(seconds: maxSeconds + 1), onTimeout: () => text);
    await stop();
    return result;
  }

  Future<void> stop() async {
    level.value = 0;
    try {
      if (_stt.isListening) await _stt.stop();
    } catch (_) {}
  }
}
