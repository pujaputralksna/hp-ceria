// Fitur khusus browser (layar penuh, peringatan saat menutup tab).
// Di Android file ini memakai versi kosong (stub).
export 'web_shell_stub.dart' if (dart.library.js_interop) 'web_shell_web.dart';
