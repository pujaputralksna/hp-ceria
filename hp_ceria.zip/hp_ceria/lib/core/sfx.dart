import 'package:audioplayers/audioplayers.dart';

/// Efek suara pendek (dering, pop, benar, tepuk tangan).
class Sfx {
  static final _players = <String, AudioPlayer>{};

  static Future<void> play(String name, {bool loop = false}) async {
    try {
      final p = _players.putIfAbsent(name, () => AudioPlayer());
      await p.stop();
      await p.setReleaseMode(loop ? ReleaseMode.loop : ReleaseMode.stop);
      await p.play(AssetSource('sfx/$name.mp3'));
    } catch (_) {}
  }

  static Future<void> stop(String name) async {
    try {
      await _players[name]?.stop();
    } catch (_) {}
  }
}
