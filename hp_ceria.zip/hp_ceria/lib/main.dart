import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/kiosk.dart';
import 'core/settings.dart';
import 'core/speaker.dart';
import 'core/theme.dart';
import 'core/web_shell.dart' as web_shell;
import 'screens/home_screen.dart';
import 'screens/parent/setup_screen.dart';
import 'screens/parent/time_up_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await AppSettings.instance.load();
  await Speaker.instance.init();
  runApp(const HpCeriaApp());
}

final navigatorKey = GlobalKey<NavigatorState>();

/// Browser: true selama Mode Anak berjalan (layar "Ketuk untuk mulai" ditampilkan bila keluar dari layar penuh).
final webKidsActive = ValueNotifier<bool>(false);
final _webFullscreen = ValueNotifier<bool>(web_shell.isFullscreen);

class HpCeriaApp extends StatelessWidget {
  const HpCeriaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HP Ceria',
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      theme: buildTheme(),
      builder: kIsWeb ? (context, child) => WebFrame(child: child!) : null,
      home: AppSettings.instance.isSetupDone ? const KidsShell() : const SetupScreen(),
    );
  }
}

/// Membungkus seluruh "HP anak": mengunci layar, menyembunyikan tombol sistem,
/// dan menghitung batas waktu bermain harian.
class KidsShell extends StatefulWidget {
  const KidsShell({super.key});

  @override
  State<KidsShell> createState() => _KidsShellState();
}

class _KidsShellState extends State<KidsShell> with WidgetsBindingObserver {
  Timer? _usageTimer;
  bool _timeUpShown = false;

  /// Bila true, Mode Anak sedang dilepas sementara oleh orang tua (mis. memilih file video).
  static bool pausedByParent = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppSettings.instance.setKidsModeEnabled(true);
    webKidsActive.value = true;
    _lock();
    _usageTimer = Timer.periodic(const Duration(seconds: 30), (_) => _tickUsage());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _usageTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _lock();
  }

  Future<void> _lock() async {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    if (pausedByParent || !AppSettings.instance.kidsModeEnabled) return;
    await Kiosk.start();
  }

  Future<void> _tickUsage() async {
    // Hanya dihitung saat layar menyala dan aplikasi sedang dipakai.
    if (WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) return;
    final s = AppSettings.instance;
    await s.addUsageSeconds(30);
    if (s.isTimeUp && !_timeUpShown) {
      _timeUpShown = true;
      await Speaker.instance.say('Waktunya istirahat dulu ya, ${s.childName}. Main lagi nanti!');
      await navigatorKey.currentState?.push(MaterialPageRoute(builder: (_) => const TimeUpScreen()));
      _timeUpShown = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    // Tombol "kembali" sistem tidak bisa menutup aplikasi dari layar beranda.
    return const PopScope(canPop: false, child: HomeScreen());
  }
}

/// Dipakai area orang tua untuk melepas kunci sementara (mis. saat memilih file).
class KidsLockPause {
  static Future<T> run<T>(Future<T> Function() action) async {
    _KidsShellState.pausedByParent = true;
    await Kiosk.stop();
    try {
      return await action();
    } finally {
      _KidsShellState.pausedByParent = false;
      await Kiosk.start();
      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }
}

/// Tampilan di browser: aplikasi dibingkai seperti HP bila layar lebar,
/// plus layar "Ketuk untuk mulai" saat tidak dalam layar penuh.
class WebFrame extends StatefulWidget {
  const WebFrame({super.key, required this.child});
  final Widget child;

  @override
  State<WebFrame> createState() => _WebFrameState();
}

class _WebFrameState extends State<WebFrame> {
  @override
  void initState() {
    super.initState();
    web_shell.onFullscreenChange((v) => _webFullscreen.value = v);
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final screen = mq.size;
    Widget app = widget.child;
    if (screen.width > screen.height * 0.75 && screen.width > 520) {
      // Layar laptop: tampilkan aplikasi dalam bingkai HP di tengah.
      final h = screen.height - 24;
      final w = (h * 0.5).clamp(320.0, 480.0);
      app = ColoredBox(
        color: const Color(0xFF2E2A5C),
        child: Center(
          child: Container(
            width: w + 20,
            height: h,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(42)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: MediaQuery(
                data: mq.copyWith(size: Size(w, h - 20), padding: EdgeInsets.zero, viewPadding: EdgeInsets.zero),
                child: app,
              ),
            ),
          ),
        ),
      );
    }
    return Stack(
      children: [
        Positioned.fill(child: app),
        AnimatedBuilder(
          animation: Listenable.merge([webKidsActive, _webFullscreen]),
          builder: (context, _) => webKidsActive.value && !_webFullscreen.value
              ? const Positioned.fill(child: _WebStartOverlay())
              : const SizedBox.shrink(),
        ),
      ],
    );
  }
}

class _WebStartOverlay extends StatelessWidget {
  const _WebStartOverlay();

  @override
  Widget build(BuildContext context) {
    return ExcludeFocus(
      child: Material(
        color: const Color(0xF22E2A5C),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () async {
            await web_shell.enterFullscreen();
            _webFullscreen.value = web_shell.isFullscreen;
            await Speaker.instance.say('Halo ${AppSettings.instance.childName}! Ayo main!');
          },
          child: const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('🎀📱', style: TextStyle(fontSize: 90)),
                SizedBox(height: 12),
                Text(
                  'HP Ceria',
                  style: TextStyle(fontSize: 40, color: Colors.white, fontWeight: FontWeight.w900),
                ),
                SizedBox(height: 24),
                CircleAvatar(
                  radius: 56,
                  backgroundColor: Color(0xFFFF7EB6),
                  child: Icon(Icons.play_arrow_rounded, size: 80, color: Colors.white),
                ),
                SizedBox(height: 16),
                Text('Ketuk untuk mulai', style: TextStyle(fontSize: 24, color: Colors.white)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
