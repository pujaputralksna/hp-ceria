# Panduan HP Ceria Versi Web (Chrome di Windows)

Versi web memakai **kode yang sama** dengan versi Android. Semua alat yang dibutuhkan **sudah terpasang** di laptop Anda (Flutter, VS Code, Chrome, Laragon), jadi tidak perlu instalasi baru.

Ada dua cara memakainya:
- **Cara A:** coba langsung dari VS Code. Cocok untuk mencoba atau mengubah kode.
- **Cara B:** pasang di Laragon. Cocok untuk dipakai anak sehari-hari, dan bisa dijadikan "aplikasi" di desktop.

---

## Cara A — Jalankan dari VS Code (paling cepat)

1. Ekstrak `hp_ceria.zip` ke `D:\Puja\hp_ceria`, lalu buka foldernya di VS Code (**File → Open Folder**).
2. Buka Terminal (`` Ctrl+` ``), lalu jalankan:
   ```powershell
   flutter pub get
   flutter run -d chrome
   ```
   Atau di VS Code: buka tab **Run and Debug** (`Ctrl+Shift+D`), pilih **"HP Ceria di Chrome"**, lalu tekan **F5**.
3. Chrome terbuka otomatis. Pertama kali akan muncul pengaturan awal: nama anak dan PIN orang tua.

> Mode ini untuk pengembangan, jadi agak lambat. Untuk pemakaian sehari-hari gunakan Cara B.

---

## Cara B — Pasang di Laragon (untuk pemakaian sehari-hari)

Laragon yang sudah ada di `D:\Puja\laragon` dipakai sebagai server web lokal.

### 1. Nyalakan Laragon
Buka `D:\Puja\laragon\laragon.exe`, lalu klik **Start All**. Tunggu sampai Apache berwarna hijau.

### 2. Build dan salin otomatis
Di Terminal VS Code (folder proyek):
```powershell
powershell -ExecutionPolicy Bypass -File tools\pasang_laragon.ps1
```
Skrip ini menjalankan perintah berikut, yang juga bisa Anda jalankan secara manual:
```powershell
flutter build web --release --no-web-resources-cdn --base-href /hpceria/
xcopy /E /I /Y build\web D:\Puja\laragon\www\hpceria
```

### 3. Buka di Chrome
Buka **http://localhost/hpceria/**

> ⚠️ Harus memakai alamat **localhost**. Chrome hanya mengizinkan kamera dan mikrofon di `localhost` atau `https://`. Membuka file `index.html` langsung (alamat `file:///...`) **tidak akan berfungsi**.

### 4. Jadikan "aplikasi" di desktop (disarankan)
1. Di Chrome, saat membuka http://localhost/hpceria/, klik ikon **⊕ Install** di ujung kanan kolom alamat. Atau lewat menu **⋮ → Transmisikan, simpan, dan bagikan → Instal halaman sebagai aplikasi…**.
2. Klik **Instal**. HP Ceria muncul di Start Menu dan desktop dengan ikon sendiri, dan terbuka tanpa kolom alamat atau tab.

### 5. Mode "kiosk" Chrome (penguncian paling kuat di Windows)
Buat shortcut khusus untuk anak:
1. Klik kanan desktop → **New → Shortcut**.
2. Isi lokasi:
   ```
   "C:\Program Files\Google\Chrome\Application\chrome.exe" --kiosk http://localhost/hpceria/ --user-data-dir=D:\Puja\chrome-anak
   ```
3. Beri nama **HP Ceria Anak**, lalu klik Finish.

Shortcut ini membuka Chrome **layar penuh tanpa tombol, tab, atau kolom alamat**. Profil `chrome-anak` terpisah dari profil Chrome Anda, jadi riwayat dan akun Anda tidak bisa diakses anak.
Untuk keluar dari mode kiosk: **Alt+F4**.

> Izin kamera dan mikrofon pada profil `chrome-anak` diminta sekali di awal. Saat pertama kali membuka shortcut, buka menu Kamera dan Telepon, lalu klik **Izinkan**.

---

## Perbedaan versi web dan Android

| Fitur | Android | Chrome (Windows) |
|---|---|---|
| Telepon, Pesan, Lagu, Belajar, Main | ✅ | ✅ sama |
| Suara hewan (TTS) | Suara Google Indonesia | Suara "Google Bahasa Indonesia" di Chrome (butuh internet) atau suara Windows (lihat di bawah) |
| Hewan mendengar anak | ✅ | ✅ (Chrome, butuh internet) |
| Filter wajah | Mengikuti wajah secara otomatis | **Bingkai oval**: anak memposisikan wajah di dalam oval, lalu telinga/mahkota muncul di sekitarnya |
| Video YouTube | ✅ | ✅ |
| Video dari file di HP | ✅ | ❌ (hanya link YouTube) |
| Foto di Galeri | Tanpa batas | Maksimal 6 foto terbaru (batas penyimpanan browser) |
| Kunci layar | Sematkan aplikasi / Kiosk penuh | **Layar penuh**. Kalau anak menekan Esc, muncul layar "Ketuk untuk mulai". Chrome juga bertanya dulu sebelum tab ditutup |
| Tampilan di laptop | — | Tampil dalam **bingkai HP** di tengah layar |

### Pertama kali dibuka
Muncul layar **"Ketuk untuk mulai"**. Ini wajib, karena Chrome hanya mengizinkan layar penuh dan suara setelah ada klik atau sentuhan.

### Pengaturan Orang Tua
Sama seperti di Android: **tekan dan tahan ikon 🔒 selama 3 detik** (tahan klik mouse), lalu masukkan PIN.
Pilih **Keluar dari Mode Anak** untuk keluar dari layar penuh. Setelah itu tab boleh ditutup.

---

## Suara Bahasa Indonesia di Chrome

- **Dengan internet:** Chrome otomatis memakai suara **"Google Bahasa Indonesia"**. Tidak perlu pengaturan apa pun.
- **Tanpa internet (opsional):** pasang suara Windows.
  1. **Settings → Time & language → Speech → Manage voices → Add voices**.
  2. Pilih **Indonesian (Indonesia)**, lalu instal.
  3. Tutup lalu buka lagi Chrome.

Pengenalan ucapan anak (hewan "mendengar") di Chrome **selalu butuh internet**.

---

## Kalau ada masalah

| Masalah | Solusi |
|---|---|
| Layar putih / tidak muncul | Pastikan membuka `http://localhost/hpceria/` (dengan `/` di akhir) dan Laragon sudah **Start All**. Tekan `Ctrl+Shift+R` untuk memuat ulang penuh |
| Muncul 404 | Folder `D:\Puja\laragon\www\hpceria` belum ada. Ulangi langkah B.2 |
| Kamera "belum diizinkan" | Klik ikon 🔒 di kiri kolom alamat → **Kamera: Izinkan**, lalu muat ulang |
| Tidak ada suara | Klik dulu "Ketuk untuk mulai". Periksa volume Windows dan pastikan tab Chrome tidak di-*mute* |
| Hewan tidak mendengar | Izinkan **Mikrofon** (sama seperti kamera) dan pastikan ada internet |
| Emoji tampil kotak-kotak | Pertama kali dibuka butuh internet untuk mengunduh font emoji. Setelah itu tersimpan di cache |
| Setelah mengubah kode, tampilan tidak berubah | Jalankan ulang `tools\pasang_laragon.ps1`, lalu `Ctrl+Shift+R` di Chrome |

---

## Batasan yang perlu diketahui
- **Browser tidak bisa mengunci Windows sepenuhnya.** Tombol **Windows**, **Alt+Tab**, **Alt+F4**, dan **Ctrl+Alt+Del** tetap berfungsi, dan itu tidak bisa dicegah oleh halaman web. Untuk balita 2–3 tahun, layar penuh + mode kiosk biasanya sudah cukup. Untuk perlindungan lebih:
  - buat **akun Windows terpisah untuk anak**: Settings → Accounts → Family,
  - aktifkan **Microsoft Family Safety** untuk membatasi aplikasi dan waktu layar.
- Filter wajah di web **tidak mengikuti gerakan wajah**, karena pendeteksi wajah Google ML Kit hanya tersedia di Android/iOS.
- Data (nama, PIN, video, foto) tersimpan di browser/profil Chrome tersebut. Kalau data browsing dihapus, pengaturan awal akan muncul lagi.
