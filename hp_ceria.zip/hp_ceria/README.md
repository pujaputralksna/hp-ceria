# HP Ceria 🎀📱

"Handphone khusus anak" (Mode Anak) untuk balita 2–3 tahun, dibuat dengan Flutter.

- 📞 **Telepon**: menelepon teman hewan yang bicara (suara Bahasa Indonesia) dan mendengarkan jawaban anak.
- 💬 **Pesan**: chat dengan bot hewan memakai stiker dan pesan suara; balasan dibacakan.
- 📷 **Kamera**: filter wajah hewan (kucing, kelinci, beruang, putri, bunga, panda) dan video call dengan hewan.
- ▶️ **Video**: tampilan mirip YouTube; daftar video dipilih orang tua (link YouTube atau file di HP).
- 🎵 **Lagu**: 8 lagu anak dengan lirik karaoke, bisa diputar tanpa internet.
- 📚 **Belajar**: 11 kategori kartu (hewan, warna, bentuk, angka, huruf, buah, kendaraan, tubuhku, keluarga, perasaan, kebiasaan baik) dan kuis "Mana ...?".
- 🎮 **Main**: pecah balon, beri makan hewan, cari pasangan, suara siapa, melukis, dandan boneka.
- 🔒 **Mode Anak**: layar dikunci; untuk keluar perlu PIN orang tua. Ada batas waktu main harian.

Langkah lengkap dari instalasi sampai aplikasi berjalan di HP ada di **[PANDUAN.md](PANDUAN.md)**.

Versi **web (Chrome di Windows)** dari kode yang sama: lihat **[PANDUAN_WEB.md](PANDUAN_WEB.md)**.
