import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hp_ceria/core/settings.dart';
import 'package:hp_ceria/data/learning_data.dart';
import 'package:hp_ceria/screens/games/balloon_game.dart';
import 'package:hp_ceria/screens/games/dress_up_game.dart';
import 'package:hp_ceria/screens/games/feed_animal_game.dart';
import 'package:hp_ceria/screens/games/games_home_screen.dart';
import 'package:hp_ceria/screens/games/memory_game.dart';
import 'package:hp_ceria/screens/games/paint_game.dart';
import 'package:hp_ceria/screens/games/sound_guess_game.dart';
import 'package:hp_ceria/screens/home_screen.dart';
import 'package:hp_ceria/screens/learn/flashcard_screen.dart';
import 'package:hp_ceria/screens/learn/learn_home_screen.dart';
import 'package:hp_ceria/screens/learn/quiz_screen.dart';
import 'package:hp_ceria/screens/messages/chat_list_screen.dart';
import 'package:hp_ceria/screens/parent/parent_screen.dart';
import 'package:hp_ceria/screens/parent/setup_screen.dart';
import 'package:hp_ceria/screens/parent/video_manager_screen.dart';
import 'package:hp_ceria/screens/phone/phone_screen.dart';
import 'package:hp_ceria/screens/songs/songs_screen.dart';
import 'package:hp_ceria/screens/video/video_home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> show(WidgetTester t, Widget w, {Size size = const Size(400, 860)}) async {
  t.view.physicalSize = size;
  t.view.devicePixelRatio = 1;
  await t.pumpWidget(MaterialApp(home: w));
  await t.pump(const Duration(milliseconds: 500));
  await t.pump(const Duration(milliseconds: 500));
  await t.pumpWidget(const SizedBox()); // buang layar agar timer dibersihkan
  await t.pump(const Duration(seconds: 5));
}

void main() {
  setUp(() async {
    SharedPreferences.setMockInitialValues({'childName': 'Aisyah', 'parentPin': '1234'});
    await AppSettings.instance.load();
    await AppSettings.instance.saveVideos([
      VideoItem(title: 'Contoh video YouTube', source: 'aaaaaaaaaaa', isYoutube: true, category: 'Lagu'),
    ]);
  });

  for (final size in [const Size(360, 640), const Size(412, 915)]) {
    group('layar ${size.width.toInt()}x${size.height.toInt()}', () {
      testWidgets('setup', (t) => show(t, const SetupScreen(), size: size));
      testWidgets('beranda', (t) => show(t, const HomeScreen(), size: size));
      testWidgets('telepon', (t) => show(t, const PhoneScreen(), size: size));
      testWidgets('pesan', (t) => show(t, const ChatListScreen(), size: size));
      testWidgets('video', (t) => show(t, const VideoHomeScreen(), size: size));
      testWidgets('lagu', (t) => show(t, const SongsScreen(), size: size));
      testWidgets('belajar', (t) => show(t, const LearnHomeScreen(), size: size));
      for (final c in learnCategories) {
        testWidgets('kartu ${c.title}', (t) => show(t, FlashcardScreen(category: c), size: size));
        testWidgets('kuis ${c.title}', (t) => show(t, QuizScreen(category: c), size: size));
      }
      testWidgets('main', (t) => show(t, const GamesHomeScreen(), size: size));
      testWidgets('balon', (t) => show(t, const BalloonGame(), size: size));
      testWidgets('pasangan', (t) => show(t, const MemoryGame(), size: size));
      testWidgets('suara', (t) => show(t, const SoundGuessGame(), size: size));
      testWidgets('lukis', (t) => show(t, const PaintGame(), size: size));
      testWidgets('dandan', (t) => show(t, const DressUpGame(), size: size));
      testWidgets('makan', (t) => show(t, const FeedAnimalGame(), size: size));
      testWidgets('orang tua', (t) => show(t, const ParentScreen(), size: size));
      testWidgets('kelola video', (t) => show(t, const VideoManagerScreen(), size: size));
    });
  }

  test('parseYoutubeId', () {
    expect(parseYoutubeId('https://youtu.be/dQw4w9WgXcQ?si=abc'), 'dQw4w9WgXcQ');
    expect(parseYoutubeId('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=10'), 'dQw4w9WgXcQ');
    expect(parseYoutubeId('https://youtube.com/shorts/dQw4w9WgXcQ'), 'dQw4w9WgXcQ');
    expect(parseYoutubeId('bukan link'), isNull);
  });
}
