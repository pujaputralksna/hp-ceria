import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hp_ceria/core/settings.dart';
import 'package:hp_ceria/data/animals.dart';
import 'package:hp_ceria/screens/messages/chat_screen.dart';
import 'package:hp_ceria/screens/phone/call_screen.dart';
import 'package:hp_ceria/screens/songs/song_player_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async {
    SharedPreferences.setMockInitialValues({'childName': 'Aisyah', 'parentPin': '1234'});
    await AppSettings.instance.load();
  });

  Future<void> show(WidgetTester t, Widget w) async {
    t.view.physicalSize = const Size(360, 640);
    t.view.devicePixelRatio = 1;
    await t.pumpWidget(MaterialApp(home: w));
    for (var i = 0; i < 20; i++) {
      await t.pump(const Duration(milliseconds: 500));
    }
    await t.pumpWidget(const SizedBox());
    await t.pump(const Duration(seconds: 30));
  }

  testWidgets('chat', (t) => show(t, ChatScreen(friend: animalFriends.first)));
  testWidgets('telepon berlangsung', (t) => show(t, CallScreen(friend: animalFriends[4])));
  testWidgets('pemutar lagu', (t) => show(t, const SongPlayerScreen(index: 5)));

  test('otak teman hewan', () {
    final b = FriendBrain(animalFriends.first);
    expect(b.reply('halo mimi', 'Aisyah'), contains('Aisyah'));
    expect(b.reply('aku sayang kamu', 'Aisyah'), contains('sayang'));
    expect(b.reply('', 'Aisyah'), isNotEmpty);
  });
}
